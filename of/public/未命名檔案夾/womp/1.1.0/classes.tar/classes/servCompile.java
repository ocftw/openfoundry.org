import java.io.*;
import java.net.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;



class Host
{
	int gId;
	String nId;
	int nodeNum;
	

}

public class servCompile extends HttpServlet implements Runnable
{
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
     
    boolean stop = false;
    static int port = 11000;
     
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
    	
    	String name, value, code, fName, node, processor,action,host, subValue;
  	 	int count,i,NodeNum,ProcNum, index=0, id;

	    Thread control = new Thread(this);
	    		
      // get the code which are inserted into the textarea by user
      code = request.getParameter("Editor");
       
       // get the number of requested nodes
       node = request.getParameter("Node");
       NodeNum = Integer.parseInt(node,10);
       
       // get the number of requested processor per node
       processor = request.getParameter("Processor");
       ProcNum = Integer.parseInt(processor,10);
  
  
       // write the code into file : it will save in /home/xaviera/public_html/cat_dsm.c
  	/*   FileWriter fwCode = new FileWriter("/home/xaviera/public_html/cat_dsm.c");
  	   fwCode.write(code);
	   fwCode.flush(); 
	 */  
	 
	   // write the requested node into file : it will save in /home/xaviera/public_html/node
	/*   FileWriter fwNode = new FileWriter("/home/xaviera/public_html/node");
       fwNode.write(node);
	   fwNode.flush(); 
	 */
       // write the requested processor into file : it will save in /home/xaviera/public_html/cpu
	 /*  FileWriter fwCpu = new FileWriter("/home/xaviera/public_html/cpu");
       fwCpu.write(processor);
	   fwCpu.flush(); 
	 */
		
	   Runtime r1 = Runtime.getRuntime(), r2 = Runtime.getRuntime();
	   Process p1 = null,p2 = null;
	
		
	   Enumeration para = request.getParameterNames();
	 //  FileWriter fwAction = new FileWriter("/home/xaviera/public_html/action");
	 //  FileWriter fwflag = new FileWriter("/home/xaviera/public_html/flag");
	   FileWriter fwAction = new FileWriter("/opt/tomcat/webapps/examples/servlets/action");
	   FileWriter fwflag = new FileWriter("/opt/tomcat/webapps/examples/servlets/flag");
	   String yes = "y\n";
	   

 	 while (para.hasMoreElements()) 
     {
	
			//----------------  Compilation ------------------------------------
			if( (request.getParameter("Compile")) != null)  
			{
				// set a unique number for this operation
				if(port == 20000)
				{
					port = 11000;
				}
				else
				{
					port++;
				}
						
				final int unique = port;
			
			
			 	// record the action,Compile, into file (action)
			 	action = request.getParameter("Compile");
      			fwAction.write(action);
	  			fwAction.flush(); 
	  			
	  			count = 0;
	  			
	  			// set response
	  			PrintWriter out = response.getWriter();
	  			response.setContentType("text/html;charset=UTF-8");
	  			out.println("<html>");
      		  	out.println("<head>");
        		out.println("<title>Result</title>");
        		out.println("</head>");
      	     	out.println("<body style=\"background-color: rgb(255, 255, 204);\">");      	     	
                out.println("</body>");
       			out.println("</html>");
		
				try
				{
					if(count == 0)
					{
						count++;
	
						
						
						// create a dirctory for this operation
						// mkdir ~/public_html/11001
					//	String mkdir[] = {"mkdir", "/home/xaviera/public_html/"+ unique};
						String mkdir[] = {"mkdir", "/opt/tomcat/webapps/examples/servlets/"+ unique};
						p1 = r1.exec(mkdir);
						p1.waitFor();
	   				
	   					// write the code into file : it will save in /home/xaviera/public_html/11001/11001.c
  	   				//	FileWriter fwCode = new FileWriter("/home/xaviera/public_html/"+ unique+ "/" +unique+".c");
  	   				    //save in /opt/tomcat/webapps/examples/servlets/11001/11001.c
  	 				  	FileWriter fwCode = new FileWriter("/opt/tomcat/webapps/examples/servlets/"+ unique+ "/" +unique+".c");
  	 				  	fwCode.write(code);
	   					fwCode.flush(); 
						
						
						// write the unique number (port) into file: it will save in /home/xaviera/public_html/11001/id
				  	  // FileWriter fwID = new FileWriter("/home/xaviera/public_html/"+ unique+"/id");
  	 				   FileWriter fwID = new FileWriter("/opt/tomcat/webapps/examples/servlets/"+ unique+ "/id");
				  	   fwID.write( String.valueOf(unique) );
					   fwID.flush(); 
						
						// copy the compDSM.sh to this directory
						// cp /home/xaviera/public_html/compDSM.sh /home/xaviera/public_html/11001/compDSM.sh
					//	String cp[] = {"cp", "/home/xaviera/public_html/compDSM.sh", 
					//						"/home/xaviera/public_html/"+ unique+"/compDSM.sh"};
						String cp[] = {"cp", "/home/xaviera/public_html/compDSM.sh", 
											"/opt/tomcat/webapps/examples/servlets/"+ unique+"/compDSM.sh"};						
						p1 = r1.exec(cp);
						p1.waitFor();  
						
						// execute compilation : ./compDSM.sh 11001
					//	String compile[] = {"/bin/sh", 
					//						"/home/xaviera/public_html/"+ unique +"/compDSM.sh", 
					//						String.valueOf(unique)};	
						String compile[] = {"/bin/sh", 
											"/opt/tomcat/webapps/examples/servlets/"+ unique +"/compDSM.sh", 
											String.valueOf(unique)};
						p1 = r1.exec(compile);
						p1.waitFor();

					}
				}
				catch (Exception e)
				{
					out.println(e);
				}
				
				//read the output file : /home/xaviera/public_html/11001/msgComp
			//	FileReader frComOut = new FileReader("/home/xaviera/public_html/"+ unique+"/msgComp");
				FileReader frComOut = new FileReader("/opt/tomcat/webapps/examples/servlets/"+ unique+"/msgComp");
		   		while( (i = frComOut.read()) != (-1))   //print message	
	   			{
	   				if(i == 10)
	   					out.println("<P> </P>");
	   				if(i == 32)
	   					out.println("&nbsp;");
	   				out.println((char)i);
	   			}
	
				out.println("<P>" + "Compilation finish !" + "</P>");
				
	  			break;	
				
			} // end of case compile
			
			
			
			
			
			//----------------  Execution ------------------------------------
			if( (request.getParameter("Run")) != null)  
			{
			
				// set a unique number for this operation
				if(port == 20000)
				{
					port = 11000;
				}
				else
				{
					port++;
				}
						
				final int unique = port;
			
			
				// record the action, Run, into file (action)
		        action = request.getParameter("Run");
      			fwAction.write(action);
	  			fwAction.flush(); 
	  			
				count = 0;
				// set response
				PrintWriter out = response.getWriter();
	  			response.setContentType("text/html;charset=UTF-8");
	  			out.println("<html>");
      		  	out.println("<head>");
        		out.println("<title>Result</title>");
        		out.println("</head>");
      	     	out.println("<body style=\"background-color: rgb(255, 255, 204);\">");
				
				try  
				{	
					// compile this program before execution
					
					
					// create a dirctory for this operation
					// mkdir ~/public_html/11001
			//		String mkdir[] = {"mkdir", "/home/xaviera/public_html/"+ unique};
					String mkdir[] = {"mkdir", "/opt/tomcat/webapps/examples/servlets/"+ unique};
					p1 = r1.exec(mkdir);
					p1.waitFor();
	   				
	   				// write the code into file : it will save in /home/xaxviera/public_html/11001/11001.c
  	   			//	FileWriter fwCode = new FileWriter("/home/xaviera/public_html/"+ unique+ "/" +unique+".c");
  	   				FileWriter fwCode = new FileWriter("/opt/tomcat/webapps/examples/servlets/"+ unique+ "/" +unique+".c");
  	 				fwCode.write(code);
	   				fwCode.flush(); 
						
					 // write the requested node into file : it will save in /home/xaviera/public_html/11001/node
	   			//	 FileWriter fwNode = new FileWriter("/home/xaviera/public_html/"+ unique+"/node");
	   				 FileWriter fwNode = new FileWriter("/opt/tomcat/webapps/examples/servlets/"+ unique+"/node");
			         fwNode.write(node);
			    	 fwNode.flush(); 
	 
			         // write the requested processor into file : it will save in /home/xaviera/public_html/11001/cpu
				 //  FileWriter fwCpu = new FileWriter("/home/xaviera/public_html/"+ unique+"/cpu");
				     FileWriter fwCpu = new FileWriter("/opt/tomcat/webapps/examples/servlets/"+ unique+"/cpu");
			         fwCpu.write(processor);
			     	 fwCpu.flush(); 
						
						
						// write the unique number (port) into file: it will save in /home/xaviera/public_html/11001/id
				  	// FileWriter fwID = new FileWriter("/home/xaviera/public_html/"+ unique+"/id");
				  	   FileWriter fwID = new FileWriter("/opt/tomcat/webapps/examples/servlets/"+ unique+"/id");
				  	   fwID.write( String.valueOf(unique) );
					   fwID.flush(); 
						
						// copy the compDSM.sh to this directory
						// cp /home/xaviera/public_html/compDSM.sh /home/xaviera/public_html/11001/compDSM.sh
					//	String cp[] = {"cp", "/home/xaviera/public_html/compDSM.sh", 
					//						"/home/xaviera/public_html/"+ unique+"/compDSM.sh"};
						String cp[] = {"cp", "/home/xaviera/public_html/compDSM.sh", 
											"/opt/tomcat/webapps/examples/servlets/"+ unique+"/compDSM.sh"};
						p1 = r1.exec(cp);
						p1.waitFor();  
						
						// execute compilation : ./compDSM.sh 11001
					//	String compile[] = {"/bin/sh", 
					//						"/home/xaviera/public_html/"+ unique +"/compDSM.sh", 
					//						String.valueOf(unique)};	
						String compile[] = {"/bin/sh", 
											"/opt/tomcat/webapps/examples/servlets/"+ unique +"/compDSM.sh", 
											String.valueOf(unique)};			
						p1 = r1.exec(compile);
						p1.waitFor();
						
					//--------------
					
					// cp /home/xaviera/public_html/runDSM_auto.sh
					//						/home/xaviera/public_html/11001/runDSM_auto.sh
				//	String cpExeAuto[] = {"cp", "/home/xaviera/public_html/runDSM_auto.sh", 
				//							"/home/xaviera/public_html/"+ unique+"/runDSM_auto.sh"};
					String cpExeAuto[] = {"cp", "/home/xaviera/public_html/runDSM_auto.sh", 
											"/opt/tomcat/webapps/examples/servlets/"+ unique+"/runDSM_auto.sh"};						
					p1 = r1.exec(cpExeAuto);
					p1.waitFor();
					Thread.sleep(3000);
					
					// execute this job : ./runDSM_auto.sh 11001
				//	String execAuto[] = {"/bin/sh", 
				//					"/home/xaviera/public_html/"+ unique +"/runDSM_auto.sh", 
				//					String.valueOf(unique)};
					String execAuto[] = {"/bin/sh", 
									"/opt/tomcat/webapps/examples/servlets/"+ unique +"/runDSM_auto.sh", 
									String.valueOf(unique)};
					p1 = r1.exec(execAuto);
					p1.waitFor();
					
					// move the output and the statistic info. to their directory: ./getOutput.sh 11001
				//	String getOutput[] = {"/bin/sh", 	
				//				"/home/xaviera/public_html/getOutput.sh", 
				//					String.valueOf(unique)};	
					String getOutput[] = {"/bin/sh", 	
								"/opt/tomcat/webapps/examples/servlets/getOutput.sh", 
									String.valueOf(unique)};
					p1 = r1.exec(getOutput);
					p1.waitFor();	
			  
			  		// save the name of all output: ./saveName.sh
					Thread.sleep(3000);
				//	String saveName[] = {"/bin/sh", 
				//				"/home/xaviera/public_html/saveName.sh",
				//				String.valueOf(unique)};
					String saveName[] = {"/bin/sh", 
								"/opt/tomcat/webapps/examples/servlets/saveName.sh",
								String.valueOf(unique)};
					p2 = r2.exec(saveName);
					p2.waitFor();
		
	        		out.println("</body>");
    	   			out.println("</html>");
    	   			
    	   			
    	   		//	p1.waitFor();
    	   			Thread.sleep(4000);
    	   			//----(0315)
    	   			PrintWriter out2 = response.getWriter();
	  				response.setContentType("text/html;charset=UTF-8");
	  				out2.println("<html>");
      			  	out2.println("<head>");
        			out2.println("<title>Result</title>");
        			out2.println("</head>");
      	     		out2.println("<body style=\"background-color: rgb(255, 255, 204);\">");
  
      	     	//	out.println("<applet code=TextOutput.class archive=\"http://hpds39.ee.ncku.edu.tw:8080/examples/servlets/TextOutput.jar\" width=330 height=500 ></applet>");
      	     		out.println("<applet code=TextOutput.class archive=\"http://140.127.114.38:8080/examples/servlets/TextOutput.jar\"  width=335 height=500>" +
			      	     		"<param name=id value="+unique+">" +	
      	     					"</applet>");
      	     	
      	     	//	out.println("<applet code=TextOutput.class archive=\"http://grid.ee.kuas.edu.tw:8080/servlets-examples/TextOutput.jar\"  width=335 height=500>" +
			     // 	     		"<param name=id value="+unique+">" +	
      	     	//				"</applet>");
      	     	
      	     	
//					out.println("<applet code=DrawOutput.class archive=\"http://hpds39.ee.ncku.edu.tw:8080/examples/servlets/DrawOutput.jar\" width=335 height=500 ALIGN=RIGHT ></applet>");
//   	  	 		out.println("<applet code=TimeOutput.class archive=\"http://grid.ee.kuas.edu.tw:8080/servlets-examples/TimeOutput.jar\" width=335 height=500 ALIGN=RIGHT>" +
//      	     					"<param name=id value="+unique+">"+
 //      	     					"</applet>");
      	     					
    	   			out2.println("</body>");
    	   			out2.println("</html>");
    	   			
	              
	              	stop = false;
	              	control.start();

				
				}
				catch (Exception e)
				{
					out.println(e);
				}

	   			break;
				
			} // end of case run
		  
	   		
	   } // end of while

    }  //end of processRequest


    //------------------------------------------------------------------------    
    public void run ()
    {
    
    /*	Runtime run = Runtime.getRuntime();
    	Process pro = null;
    	
    	try
    	{
    		for( ; ; )
	        {
	            Thread.sleep(700);
	            pro = run.exec("/home/xaviera/public_html/saveName.sh");
	            
	            if(stop == true)
		            break;
	        }
    	}
    	catch (Exception e)
    	{
    		System.out.println("Interrupted !");
    	}
    	
    */
    
    }
    
    
    
    
    
    //------------------------------------------------------------------------
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
