#include <QtGui/QApplication>
#include <stdio.h>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    if(argc != 2){
        printf("./KernelViewer [Symbol_Table]\n");
        return 0;
    }

    QApplication app(argc, argv);
    Q_INIT_RESOURCE(analyzer);
    MainWindow *mainapp = new MainWindow(argv[1]);
    mainapp->show();   

    return app.exec();
}
