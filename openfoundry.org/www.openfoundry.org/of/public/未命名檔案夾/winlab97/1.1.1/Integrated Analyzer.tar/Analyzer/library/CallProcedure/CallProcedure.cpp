#include "CallProcedure.h"
#include <iostream>
using namespace std;

CallProcedure::CallProcedure(QWidget * parent)
{
    this->parent = parent;
}

void CallProcedure::showPopupMenu(const QModelIndex & index)
{    
    QModelIndex index0 = logmatcher->proxyModel->index(index.row(), 0);
    pkt_idx = logmatcher->proxyModel->data(index0).toInt() - 1;

    QString str = "Show Call Procedure of packet ";
    str.append(QString::number(pkt_idx + 1));
    QMenu * contextMenu = new QMenu(parent);

    Q_CHECK_PTR (contextMenu);
    contextMenu->addAction(str, this , SLOT(openNewWindow()));
    contextMenu->popup(QCursor::pos());
    contextMenu->exec();
    delete contextMenu;
    contextMenu = 0;
}

void CallProcedure::openNewWindow()
{
    QFrame * popup1 = new QFrame(parent, Qt::Popup | Qt::Dialog );
    proc_tab = new CallProcTab;
    QVBoxLayout * mainlayout = new QVBoxLayout;

    mainlayout->addWidget(proc_tab);
    popup1->setLayout(mainlayout);
    popup1->resize(760,700);

    //cout << logmatcher->isWired() << endl;
    if (logmatcher->isWired()) {
        u_char * pkt_ptr = logmatcher->getPkt(pkt_idx);
        struct ether_header *eptr;
        eptr = (struct ether_header *) pkt_ptr;

        if (ntohs(eptr->ether_type) != ETHERTYPE_IP){
            QMessageBox::warning(parent, tr("Analyzer"),
                                 tr("This Packet is not an IP packet."), QMessageBox::Close);
            return;
        } else {
            QString str = "Call Procedure of Packet No.";
            str.append(QString::number(pkt_idx + 1));
            popup1->setWindowTitle(str);

            if(showCallProcedure() == true) {
                popup1->show();
            } else {
                QMessageBox::warning(parent, tr("Analyzer"),
                                     tr("Identify packet call procedure failed."), QMessageBox::Close);
                return;
            }
        }
    } else {
        u_char * pkt_ptr = logmatcher->getPkt(pkt_idx);
        struct ieee80211_radiotap_header * rptr = (struct ieee80211_radiotap_header *)(pkt_ptr);
        int radio_header_len = rptr->it_len;

        struct ieee80211_mac_header *eptr = (struct ieee80211_mac_header *)(pkt_ptr + radio_header_len);
        struct frame_control *control = (struct frame_control *) eptr->fc;

        if (control->protocol == 0 && control->type == 2)
        {
            QString str = "Call Procedure of Packet No.";
            str.append(QString::number(pkt_idx + 1));
            popup1->setWindowTitle(str);

            if(showCallProcedure() == true) {
                popup1->show();
            } else {
                QMessageBox::warning(parent, tr("Analyzer"),
                                     tr("Identify packet call procedure failed."), QMessageBox::Close);
                return;
            }
        } else {
            QMessageBox::warning(parent, tr("Analyzer"),
                                 tr("This Packet is not an IP packet."), QMessageBox::Close);
            return;
        }
    }
}

bool CallProcedure::showCallProcedure()
{
    //return showAllCall();
    // get information first!!
    KernelLog * kl_ptr;
    u_char * pkt_ptr;
    struct my_ip * ip_hdr;
    u_int id;
    bool ip_type = 0, arp_type = 0;
    QMultiHash< Key, QPair<quint64, quint32> > * s2k_ptr = logmatcher->getSniffer2Kernel();
    QList< QPair<quint64, quint32> > * arp_ls = logmatcher->getARPls();

    if (logmatcher->isWired()) {
        pkt_ptr = logmatcher->getPkt(pkt_idx);
        ip_hdr = (struct my_ip *)(pkt_ptr + sizeof(struct ether_header));
        id = ntohs(ip_hdr->ip_id);
    } else {
        pkt_ptr = logmatcher->getPkt(pkt_idx);
        struct ieee80211_radiotap_header * rptr = (struct ieee80211_radiotap_header *)(pkt_ptr);
        int radio_header_len = rptr->it_len;

        struct ieee80211_mac_header *eptr = (struct ieee80211_mac_header *)(pkt_ptr + radio_header_len);
        struct frame_control *control = (struct frame_control *) eptr->fc;
        struct llc_header * paket_llc;

        switch (control->subtype)
        {
        case 0:
            paket_llc = (struct llc_header *)
                        (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE);
            if (ntohs(paket_llc->ether_type) == ETHERTYPE_IP)
            {
                ip_type = 1;
                // org = 0 is a right encapsulated IP packet
                if (paket_llc->org[0] != 0 || paket_llc->org[1] != 0 || paket_llc->org[2] != 0) {
                    return false;
                }

                ip_hdr = (struct my_ip *)
                         (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE + LLC_HEADER_SIZE);
                id = ntohs(ip_hdr->ip_id);

            }

            break;

        case 8:
            // a QoS data + CF-Ack or a QoS (IP) packet!!!!!!!!!!!!!!!!
            paket_llc = (struct llc_header *)
                        (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE);
            if (ntohs(paket_llc->ether_type) == ETHERTYPE_IP)
            {
                ip_type = 1;
                ip_hdr = (struct my_ip *)
                         (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE + LLC_HEADER_SIZE);
                id = ntohs(ip_hdr->ip_id);
            } else if (ntohs(paket_llc->ether_type) == ETHERTYPE_ARP)
                arp_type = 1;

            break;

        default:
            return false;
            break;
        }
    }

    if (ip_type == true) {
        Key key( id, ip_hdr->ip_p, QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)) );
        //cout << "[call procedure] " << key << endl;
        QList< QPair<quint64, quint32> > rec_idx = s2k_ptr->values(key);

        //used to find a packet call procedure range
        quint64 start, end;
        QPair< QString, quint32 > callProcKey;

        if (!rec_idx.isEmpty()) {
            start = 0;
            quint32 pkt_id;
            if (id != 0)
                pkt_id = rec_idx.at(0).second;
            else {
                struct timeval * pkt_time = logmatcher->getPktTime(pkt_idx);
                qreal pkt_time_real = (qreal)pkt_time->tv_sec + (qreal)pkt_time->tv_usec / 1000000;
                qreal min = 100.0;
                quint64 min_idx = 0;
                for (int i = 0; i < rec_idx.size(); i++) {
                    kl_ptr = logmatcher->getKernelLog(rec_idx.at(i).first);
                    qreal diff = pkt_time_real - kl_ptr->getTimeF();
                    //cout << i << " " << rec_idx.at(i).first + 1 << " " << fabs(diff) << endl;
                    if (fabs(diff) < min) {
                        min = fabs(diff);
                        min_idx = i;
                    }
                }

                pkt_id = rec_idx.at(min_idx).second;
                cout << "min: " << min_idx << " " << rec_idx.at(min_idx).first + 1 << " " << min << endl;
            }
            callProcKey = qMakePair(QString("skb_release_data"), pkt_id);
            // first, we try to find out the first record
            // that have the packet ID and the start point
            for (quint64 i = 0; i < logmatcher->getKernelLogSize(); i++)
            {
                kl_ptr = logmatcher->getKernelLog(i);
                if(kl_ptr->hasThePkt(pkt_id)){
                    start = i;//start point
                    break;
                }
            }

            // second, we calculate the range
            end = calculateEnd(start, callProcKey, pkt_id);
            if(end == 0) {
                QMessageBox::warning(parent, tr("Analyzer"),
                                     tr("No end is found"), QMessageBox::Close);
                return false;
            }

            //Third, we try to find out if this range contain the IP header key
            //, if not, then we go to the next round
            while(checkKeyInProc(start, end, pkt_id, key) != true)
            {
                start = end + 1;
                end = calculateEnd(start, callProcKey, pkt_id);
                if(end == 0) {
                    QMessageBox::warning(parent, tr("Analyzer"),
                                         tr("No end is found"), QMessageBox::Close);
                    return false;
                }
            }

            showPktAnalysis(start, end, pkt_id);
            return true;
        } else {
            QMessageBox::warning(parent, tr("Analyzer"),
                                 tr("This Packet is not matched"), QMessageBox::Close);
            return false;
        }
    } else if (arp_type == true) {
        struct timeval * pkt_time = logmatcher->getPktTime(pkt_idx);
        qreal pkt_time_real = (qreal)pkt_time->tv_sec + (qreal)pkt_time->tv_usec / 1000000;
        qreal min = 100.0;
        quint64 min_idx = 0;
        for (int i = 0; i < arp_ls->size(); i++) {
            kl_ptr = logmatcher->getKernelLog(arp_ls->at(i).first);
            qreal diff = pkt_time_real - kl_ptr->getTimeF();
            if (fabs(diff) < min) {
                min = fabs(diff);
                min_idx = i;
            }
        }

        //cout << arp_ls->at(min_idx).first << endl;
        quint32 pkt_id = arp_ls->at(min_idx).second;

        //used to find a packet call procedure range
        quint64 start, end;
        QPair< QString, quint32 > callProcKey;
        callProcKey = qMakePair(QString("skb_release_data"), pkt_id);
        // first, we try to find out the first record
        // that have the packet ID and the start point
        for (quint64 i = 0; i < logmatcher->getKernelLogSize(); i++)
        {
            kl_ptr = logmatcher->getKernelLog(i);
            if(kl_ptr->hasThePkt(pkt_id)){
                start = i;//start point
                break;
            }
        }

        // second, we calculate the range
        end = calculateEnd(start, callProcKey, pkt_id);
        if(end == 0) {
            QMessageBox::warning(parent, tr("Analyzer"),
                                 tr("No end is found"), QMessageBox::Close);
            return false;
        }

        //Third, we try to find out if this range contain the IP header key
        //, if not, then we go to the next round
        while(checkARPInProc(start, end, pkt_id, arp_ls->at(min_idx).first) != true)
        {
            start = end + 1;
            end = calculateEnd(start, callProcKey, pkt_id);
            if(end == 0) {
                QMessageBox::warning(parent, tr("Analyzer"),
                                     tr("No end is found"), QMessageBox::Close);
                return false;
            }
        }

        showPktAnalysis(start, end, pkt_id);
        return true;
    }

    return false;
}

quint64 CallProcedure::calculateEnd(quint64 start, QPair<QString, quint32> callProcKey, quint32 pkt_id)
{
    KernelLog * kl_ptr;
    for(quint64 i = start + 1; i < logmatcher->getKernelLogSize(); i++)
    {
        kl_ptr = logmatcher->getKernelLog(i);
        if(kl_ptr->hasThePkt(pkt_id)){
            if (callProcKey == qMakePair(kl_ptr->getFunction(), pkt_id)) {
                return i;
            }
        }
    }
    return 0;
}

bool CallProcedure::checkKeyInProc(quint64 start, quint64 end, quint32 pkt_id, Key key)
{
    Key null_key(0, 0, "null", "null");
    KernelLog * kl_ptr;
    for (quint64 i = start; i <= end; i++)
    {
        kl_ptr = logmatcher->getKernelLog(i);
        if (kl_ptr->hasThePkt(pkt_id))
        {
            if (kl_ptr->isIPrecord())
            {
                Key matching_key = kl_ptr->getKey(pkt_id);
                if (matching_key == null_key){
                    qDebug() << "[callprocedure]checkKeyInProc: klog #" << i + 1
                            << "is an IP record, but pkt id" << kl_ptr->getPktID(pkt_id) << "do not have IP info.";
                    //return false;
                }
                else {
                    if (matching_key == key) return true;
                    else return false;
                }
            }
        }
    }

    return false;
}

bool CallProcedure::checkARPInProc(quint64 start, quint64 end, quint32 pkt_id, quint64 rcd_idx)
{
    KernelLog * kl_ptr;
    for (quint64 i = start; i <= end; i++)
    {
        kl_ptr = logmatcher->getKernelLog(i);
        if (kl_ptr->hasThePkt(pkt_id) && i == rcd_idx)
            return true;
    }

    return false;
}

void CallProcedure::showPktAnalysis(quint64 start, quint64 end, quint32 pkt_id)
{
    QList< quint64 > callIdx;
    QString str;
    quint64 find;
    KernelLog * tmp;
    KernelLog * kl_ptr;
    qreal leave_time = 0;
    quint64 leave_idx = 0;

    for (quint64 i = start; i <= end; i++)
    {
        kl_ptr = logmatcher->getKernelLog(i);
        if(kl_ptr->hasThePkt(pkt_id)){
            //making packet call procedure
            callIdx << i;
            if (kl_ptr->getType() == 0x01) {
                find = timeAnalyzer->findExitPoint(i);
                tmp = logmatcher->getKernelLog(find);
                str = "[Entry@" + kl_ptr->getTime() + "]  " + kl_ptr->getCaller() + " --> " + kl_ptr->getFunction()
                      + "   [Exit@" + tmp->getTime() + "]";
                proc_tab->getProcString(str);

                if (leave_time == 0) {
                    leave_time = tmp->getTimeF();
                    leave_idx = i;
                } else if (tmp->getTimeF() > leave_time) {
                    leave_time = tmp->getTimeF();
                    leave_idx = i;
                }
            } else {
                find = timeAnalyzer->findEntryPoint(i);
                tmp = logmatcher->getKernelLog(find);
                str = "[Entry@" + tmp->getTime() + "]  " + kl_ptr->getCaller() + " --> " + kl_ptr->getFunction()
                      + "   [Exit@" + kl_ptr->getTime() + "]";
                proc_tab->getProcString(str);

                if (leave_time == 0) {
                    leave_time = kl_ptr->getTimeF();
                    leave_idx = i;
                } else if (kl_ptr->getTimeF() > leave_time) {
                    leave_time = kl_ptr->getTimeF();
                    leave_idx = i;
                }
            }

            //making packet callgraph
            str = kl_ptr->getCaller();
            QStringList list = str.split("+");
            proc_tab->getGraphHash(list.at(0), kl_ptr->getFunction());
            proc_tab->makingGraph(list.at(0), kl_ptr->getFunction());
        }
    }

    //proc_tab->getRoots();
    proc_tab->drawCallGraph();

    quint64 first = callIdx.at(0);
    //quint64 final = callIdx.at(callIdx.size() - 1);
    qreal procTime = timeAnalyzer->pktProcessingTime(first, leave_idx);
    char proc_time[50];
    sprintf(proc_time, "\n Total Processing time: %.06lf second.", procTime);
    QString proctime_str(proc_time);
    proc_tab->getGraphString(proctime_str);
    proc_tab->getProcString(proctime_str);
}

bool CallProcedure::showAllCall()
{
    KernelLog *kl_ptr;
    u_char *pkt_ptr = logmatcher->getPkt(pkt_idx);
    QMultiHash< Key, QPair<quint64, quint32> > *s2k_ptr = logmatcher->getSniffer2Kernel();
    QString str;

    struct my_ip *ip_hdr = (struct my_ip *)(pkt_ptr + sizeof(struct ether_header));
    u_int id = ntohs(ip_hdr->ip_id);
    Key key( id, ip_hdr->ip_p, QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)) );
    QList< QPair<quint64, quint32> > rec_idx = s2k_ptr->values(key);
    quint32 pkt_id = rec_idx.at(0).second;

    if(!rec_idx.isEmpty()){
       for (quint64 i = 0; i < logmatcher->getKernelLogSize(); i++) {
            kl_ptr = logmatcher->getKernelLog(i);
            if(kl_ptr->hasThePkt(pkt_id)){
                str = QString::number(i + 1) + ": " +
                     kl_ptr->getCaller() + "(" + QString::number(kl_ptr->getType()) + ")" + " --> " + kl_ptr->getFunction();
                cout << str.toStdString() << endl;
                if(kl_ptr->isIPrecord()){
                    cout << "       ";
                    kl_ptr->printkey(pkt_id);
                }
            }
        }
       return true;
    } else {
        QMessageBox::warning(parent, tr("Analyzer"),
                                     tr("This Packet is not matched"), QMessageBox::Close);
        return false;
    }
}
