#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCore>
#include <QtGui>
#include <QScrollBar>
#include <stdlib.h>
#include "readSymTable.h"
#include "renderarea.h"
//#include "EventLog.h"
#include "LogMatcher.h"
#include "CallProcedure.h"
#include "TimeAnalysis.h"
#include "zoomwidget.h"

#include <iostream>
using namespace std;

QT_BEGIN_NAMESPACE
class QAction;
class QActionGroup;
class QLabel;
class QMenu;
QT_END_NAMESPACE

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(char *sym_table);
    ~MainWindow();

protected:
    //void contextMenuEvent(QContextMenuEvent *event);

private:
    Ui::MainWindow * ui;

    void createTips();
    void createLabelAndFilter();
    void createConn();
    void createSnifferDock();
    void createKernelDock();
    void createKernelTimeDock();
    void createEventDock();    
    QString Read_Log();
    void ReadBoth();
    void ReadSniffer();

    //filter members for table!
    QLabel * filterPatternLabel;
    QLineEdit * filterPatternLineEdit;
    QComboBox * filterSyntaxComboBox;

    QComboBox * kernelFilterSyntaxComboBox;
    QLineEdit * kernelFilterPatternLineEdit;
    QPushButton * kernelFilterGoSearchButton;

    QComboBox * kernelTimePatternComboBox;
    QLineEdit * kernelTimePatternLineEdit;
    QPushButton * kernelTimeFilterGoSearchButton;

    QDockWidget * dockwindow;

    //members for renders
    RenderArea * render;
    QScrollBar * renderScroll;

    //data members for sniffer log and kernel behavior log
    LogMatcher * log;
    TimeAnalysis * timeAnalyzer;
    CallProcedure * callAnalyzer;

    //members for handover analysis
    ZoomWidget * hoAnalyzer;

protected slots:
    void Read_Event_Log();
    void Read_Kernel_Log();
    void Read_Sniffer_Log();
    void Read_FuncProcTime_Log();
    void showAllPacket() { log->add_sniffer_data(); }
    void showKernelPacket() { log->add_pkt2kernel_data(); }
    void showKernelFuncTime();
    void showHoAnalysis();
    void aboutMe();
};

#endif // MAINWINDOW_H
