#ifndef READSYMTABLE_H
#define READSYMTABLE_H

#include <QtCore>
#include <QHash>
#include <stdio.h>
#include <fstream>
#include <iostream>
using namespace std;

extern QHash< QString, QString > addr2sym;

void getSymTable(char *);
QString addr2symFunc(QString);   //Using Pipe method --> Too Slow!
void readSymTable();             //Read the System map file
QString lookupSym(quint32); //Using Hash Method
void compareAddr(quint32);

#endif // READSYMTABLE_H
