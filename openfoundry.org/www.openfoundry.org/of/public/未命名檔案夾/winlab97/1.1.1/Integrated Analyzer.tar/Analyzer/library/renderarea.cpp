#include <QtGui>
#include "renderarea.h"

//! [0]
RenderArea::RenderArea(QWidget *parent)
    : QWidget(parent)
{
    startIdx = 0;
    endIdx = 10;
    QFont newFont = font();
    newFont.setPixelSize(12);
    setFont(newFont);

    QFontMetrics fontMetrics(newFont);
    xBoundingRect = fontMetrics.boundingRect(tr("x"));
    yBoundingRect = fontMetrics.boundingRect(tr("y"));
}
//! [0]

//! [3]
QSize RenderArea::minimumSizeHint() const
{
    return QSize(182, 182);
}
//! [3]

//! [4]
QSize RenderArea::sizeHint() const
{
    return QSize(232, 232);
}
//! [4]

void RenderArea::setValue(int s_idx)
{
    startIdx = s_idx;
    endIdx = startIdx + 10;
    if (endIdx > pktSize) endIdx = pktSize;
    update();
}

void RenderArea::paintEvent(QPaintEvent *event)
{
    //cout << "paintEvent: ";
    QPainter painter(this);
    if (timeAnalyzer->pktSize() > 0) {
        //cout << "painting..." << endl;
        painter.setRenderHint(QPainter::Antialiasing);
        painter.fillRect(event->rect(), QBrush(Qt::white));

        painter.translate(66, 66);

        painter.save();
        painter.restore();

        //timeAnalyzer->calTimeRange();
        //painter.scale(125, 125);
        drawCoordinates(painter);
    } else {
        //cout << "do nothing" << endl;
    }
}

//! [9]
void RenderArea::drawCoordinates(QPainter &painter)
{
    QPoint start(0, 0);
    QPoint end(0, RANGE + 5);
    QPoint arrow1(2, RANGE - 2);
    QPoint arrow2(-2, RANGE - 2);

    painter.setPen(Qt::red);
    painter.drawLine(start, end);
    painter.drawLine(arrow1, end);
    painter.drawLine(arrow2, end);
    painter.drawText(0 - xBoundingRect.width() / 2,
                     RANGE + 10 + xBoundingRect.height() / 2, tr("TimeLine"));

    //drawCalibration(painter, tlineRange);
    drawPktPosition(painter);
}
//! [9]

void RenderArea::drawCalibration(QPainter &painter, int &range)
{
    int interval = range / 10;
    for (int i = 1; i <= 10; i++)
    {
        if (interval * i == range) return;
        painter.drawLine(interval * i, 80, interval * i, 78);
        painter.drawLine(interval * i, 80, interval * i, 82);
    }
}

void RenderArea::drawPktPosition(QPainter &painter)
{
    int interval = RANGE / 10;
    qreal timestamp;
    char ts[20];
    QPoint start;
    QPoint end;

    painter.setPen(Qt::darkGreen);
    painter.setPen(Qt::DashLine);

    QLineF *lineBuf = new QLineF[endIdx - startIdx];
    for (int i = 0; i < endIdx - startIdx; i++){
        timestamp = timeAnalyzer->getPktTime(startIdx + i);
        sprintf(ts, "%f", timestamp);

        start.rx() = 0;
        start.ry() = interval * i;
        painter.drawText(start.rx() - 55 - xBoundingRect.width() / 2,
                         start.ry() + xBoundingRect.height() / 2, tr(ts) );

        if (i % 2 == 0) end.rx() = 20;
        else end.rx() = 40;
        end.ry() = interval * i;
        drawRectPkt(painter, end, startIdx + i);
        painter.drawLine(start, end);
        //lineBuf[i] = QLineF(start, end);
    }
    //painter.drawLines(lineBuf, e_idx - s_idx);
    delete []lineBuf;
}

//! [10]
void RenderArea::drawRectPkt(QPainter &painter, QPoint &end, int idx)
{
    char index[20];
    sprintf(index, "packet No.%d", idx + 1);
    painter.setPen(Qt::darkGreen);
    painter.setPen(Qt::DashLine);
    painter.setBrush(Qt::NoBrush);

    painter.drawText(end.rx() + 15 - xBoundingRect.width() / 2,
                     end.ry() + xBoundingRect.height() / 2, tr(index) );
    painter.drawRect(end.rx() + 5, end.ry() - 5, 90, 15);
}
//! [10]
