#include "zoomwidget.h"

ZoomWidget::ZoomWidget(QWidget *parent)
    : QGraphicsView(parent)
{
    int size = style()->pixelMetric(QStyle::PM_ToolBarIconSize);
    QSize iconSize(size, size);

    QToolButton * zoomOutIcon = new QToolButton;
    zoomOutIcon->setAutoRepeat(false);
    zoomOutIcon->setIcon(QPixmap(":/images/zoomout.png"));
    zoomOutIcon->setIconSize(iconSize);
    QToolButton * zoomInIcon = new QToolButton;
    zoomInIcon->setAutoRepeat(false);
    zoomInIcon->setIcon(QPixmap(":/images/zoomin.png"));
    zoomInIcon->setIconSize(iconSize);

    // when change view, the text will not change only if we update the whole window
    connect(zoomOutIcon, SIGNAL(clicked()), this, SLOT(myUpdate()));
    connect(zoomInIcon, SIGNAL(clicked()), this, SLOT(myUpdate()));

    QGraphicsProxyWidget * buttonProxyOut = new QGraphicsProxyWidget;
    buttonProxyOut->setWidget(zoomOutIcon);
    QGraphicsProxyWidget * buttonProxyIn = new QGraphicsProxyWidget;
    buttonProxyIn->setWidget(zoomInIcon);

    QGraphicsWidget * widget = new QGraphicsWidget;
    QGraphicsLinearLayout * layout = new QGraphicsLinearLayout(Qt::Vertical, widget);
    layout->addItem(buttonProxyOut);
    layout->addItem(buttonProxyIn);
    widget->setLayout(layout);

    pixItem * mn = new pixItem(QPixmap(":/images/MN.png"));
    pixItem * ap1 = new pixItem(QPixmap(":/images/Ap1.png"));
    pixItem * ap2 = new pixItem(QPixmap(":/images/Ap2.png"));
    pixItem * line1 = new pixItem(QPixmap(":/images/line.png"));
    pixItem * line2 = new pixItem(QPixmap(":/images/line.png"));
    pixItem * line3 = new pixItem(QPixmap(":/images/line.png"));
    pixItem * retry = new pixItem(QPixmap(":/images/retry.png"));
    pixItem * linkdown_fig = new pixItem(QPixmap(":/images/linkdown_fig.png"));
    pixItem * probereq_fail = new pixItem(QPixmap(":/images/multi_probe.png"));
    pixItem * proberesp_arrow = new pixItem(QPixmap(":/images/arrow_dotted.png"));
    pixItem * authreq_arrow = new pixItem(QPixmap(":/images/arrow_long.png"));
    pixItem * authresp_arrow = new pixItem(QPixmap(":/images/arrow_dotted.png"));
    pixItem * assoreq_arrow = new pixItem(QPixmap(":/images/arrow_long.png"));
    pixItem * assoresp_arrow = new pixItem(QPixmap(":/images/arrow_b_dotted.png"));
    pixItem * linkup_fig = new pixItem(QPixmap(":/images/linkup_fig.png"));
    pixItem * dhcpDis_arrow = new pixItem(QPixmap(":/images/arrow_dotted_right.png"));
    pixItem * dhcpOffer_arrow = new pixItem(QPixmap(":/images/arrow_long_left.png"));
    pixItem * dhcpReq_arrow = new pixItem(QPixmap(":/images/arrow_long.png"));
    pixItem * dhcpAck_arrow = new pixItem(QPixmap(":/images/arrow_dotted.png"));
    pixItem * ipchange = new pixItem(QPixmap(":/images/IP_change.png"));    
    textItem * l2h_detc;
    textItem * data_retry;
    textItem * reasso;
    textItem * linkdown;
    textItem * probing;
    textItem * probereq_1;
    textItem * probereq_2;
    textItem * proberesp;
    textItem * auth;
    textItem * authreq;
    textItem * authresp;
    textItem * asso;
    textItem * assoreq;
    textItem * assoresp;
    textItem * linkup;
    textItem * l3h_detc;
    textItem * dhcp;
    textItem * dhcpdis;
    textItem * dhcpoff;
    textItem * dhcpreq;
    textItem * dhcpack;
    textItem * ipconfig;
    l2h_detc = new textItem("L2H Detection");
    data_retry = new textItem("Data Retransimit");
    reasso = new textItem("Reassociation");
    linkdown = new textItem("Link Down Event");
    probing = new textItem("Probing");
    probereq_1 = new textItem("Probe Request");
    probereq_2 = new textItem("Probe Request");
    proberesp = new textItem("Probe Response");
    auth = new textItem("Authentication");
    authreq = new textItem("Authentication Request");
    authresp = new textItem("Authentication Response");
    asso = new textItem("Association");
    assoreq = new textItem("Association Request");
    assoresp = new textItem("Association Response");
    linkup = new textItem("Link Up Event");
    l3h_detc = new textItem("L3H Detection");
    dhcp = new textItem("DHCP");
    dhcpdis = new textItem("DHCP Discover");
    dhcpoff = new textItem("DHCP Offer");
    dhcpreq = new textItem("DHCP Request");
    dhcpack = new textItem("DHCP Ack");
    ipconfig = new textItem("IP Configuration");
    pixItem * l2h = new pixItem(QPixmap(":/images/L2H.png"));
    pixItem * l3h = new pixItem(QPixmap(":/images/L3H.png"));
    pixItem * init = new pixItem(QPixmap(":/images/initial.png"));
    handoffdelay = new pixItem("no data yet");
    l2hdelay = new pixItem("no data yet");
    l3hdelay = new pixItem("no data yet");
    l2hddelay = new pixItem("no data yet");
    probdelay = new pixItem("no data yet");
    authdelay = new pixItem("no data yet");
    assodelay = new pixItem("no data yet");
    l3hddelay = new pixItem("no data yet");
    dhcpdelay = new pixItem("no data yet");
    ipchdelay = new pixItem("no data yet");

    l2h_detc->scale(1.5, 1.5);
    data_retry->scale(1.1, 1.1);
    reasso->scale(1.1, 1.1);
    linkdown->scale(1.1, 1.1);
    probing->scale(1.5, 1.5);
    probereq_1->scale(1.1, 1.1);
    probereq_2->scale(1.1, 1.1);
    proberesp->scale(1.1, 1.1);
    auth->scale(1.5, 1.5);
    authreq->scale(1.1, 1.1);
    authresp->scale(1.1, 1.1);
    asso->scale(1.5, 1.5);
    assoreq->scale(1.1, 1.1);
    assoresp->scale(1.1, 1.1);
    linkup->scale(1.1, 1.1);
    l3h_detc->scale(1.5, 1.5);
    dhcp->scale(1.5, 1.5);
    dhcpdis->scale(1.1, 1.1);
    dhcpoff->scale(1.1, 1.1);
    dhcpreq->scale(1.1, 1.1);
    dhcpack->scale(1.1, 1.1);
    ipconfig->scale(1.5, 1.5);

    line1->setZValue(1);
    line2->setZValue(1);
    line3->setZValue(1);
    linkdown_fig->setZValue(1);
    probereq_fail->setZValue(0.5);
    probereq_1->setZValue(1);
    probereq_2->setZValue(1);
    proberesp_arrow->setZValue(0.3);
    authresp_arrow->setZValue(0.5);
    authresp->setZValue(1);
    dhcpDis_arrow->setZValue(0.7);
    dhcpOffer_arrow->setZValue(0.6);
    dhcpReq_arrow->setZValue(0.5);
    dhcp->setZValue(1);
    dhcpdis->setZValue(1);
    dhcpoff->setZValue(1);
    dhcpreq->setZValue(1);
    dhcpack->setZValue(1);
    linkup_fig->setZValue(1);
    ipchange->setZValue(1);
    handoffdelay->setZValue(1);
    l2hdelay->setZValue(1);
    l3hdelay->setZValue(1);

    QStateMachine * machine = new QStateMachine(this);
    QState * initState = new QState(machine);
    QState * state1 = new QState(machine);
    QState * state2 = new QState(machine);
    QState * state3 = new QState(machine);
    QState * finalState = new QState(machine);
    machine->setInitialState(initState);

    // Initial State
    initState->assignProperty(widget, "geometry", QRectF(600, 0, 50, 100));
    initState->assignProperty(mn, "pos", QPointF(80+90, 0));
    initState->assignProperty(ap1, "pos", QPointF(292+90, 0));
    initState->assignProperty(ap2, "pos", QPointF(402+90, 0));
    initState->assignProperty(line1, "pos", QPointF(110+90, 75));
    initState->assignProperty(line2, "pos", QPointF(352+90, 50));
    initState->assignProperty(line3, "pos", QPointF(470+90, 50));
    initState->assignProperty(retry, "pos", QPointF(-5+90, 85));
    initState->assignProperty(data_retry, "pos", QPointF(110+190, 95));
    initState->assignProperty(reasso, "pos", QPointF(110+190, 125));
    initState->assignProperty(ipchange, "pos", QPointF(-5+90, 700));    
    initState->assignProperty(init, "pos", QPointF(-150+90, 107));
    initState->assignProperty(handoffdelay, "pos", QPointF(-160+90, 440));    
    initState->assignProperty(mn, "opacity", qreal(1));
    initState->assignProperty(ap1, "opacity", qreal(1));
    initState->assignProperty(ap2, "opacity", qreal(1));
    initState->assignProperty(line1, "opacity", qreal(1));
    initState->assignProperty(line2, "opacity", qreal(1));
    initState->assignProperty(line3, "opacity", qreal(1));
    initState->assignProperty(retry, "opacity", qreal(1));
    initState->assignProperty(data_retry, "opacity", qreal(1));
    initState->assignProperty(reasso, "opacity", qreal(1));
    initState->assignProperty(linkdown, "opacity", qreal(0));
    initState->assignProperty(linkdown_fig, "opacity", qreal(0));
    initState->assignProperty(probereq_fail, "opacity", qreal(0));
    initState->assignProperty(probereq_1, "opacity", qreal(0));
    initState->assignProperty(probereq_2, "opacity", qreal(0));
    initState->assignProperty(proberesp, "opacity", qreal(0));
    initState->assignProperty(proberesp_arrow, "opacity", qreal(0));
    initState->assignProperty(authreq_arrow, "opacity", qreal(0));
    initState->assignProperty(authresp_arrow, "opacity", qreal(0));
    initState->assignProperty(assoreq_arrow, "opacity", qreal(0));
    initState->assignProperty(assoresp_arrow, "opacity", qreal(0));
    initState->assignProperty(linkup, "opacity", qreal(0));
    initState->assignProperty(linkup_fig, "opacity", qreal(0));
    initState->assignProperty(dhcpDis_arrow, "opacity", qreal(0));
    initState->assignProperty(dhcpOffer_arrow, "opacity", qreal(0));
    initState->assignProperty(dhcpReq_arrow, "opacity", qreal(0));
    initState->assignProperty(dhcpAck_arrow, "opacity", qreal(0));
    initState->assignProperty(ipchange, "opacity", qreal(1));
    initState->assignProperty(l2h_detc, "opacity", qreal(0));
    initState->assignProperty(probing, "opacity", qreal(0));
    initState->assignProperty(auth, "opacity", qreal(0));
    initState->assignProperty(authreq, "opacity", qreal(0));
    initState->assignProperty(authresp, "opacity", qreal(0));
    initState->assignProperty(asso, "opacity", qreal(0));
    initState->assignProperty(assoreq, "opacity", qreal(0));
    initState->assignProperty(assoresp, "opacity", qreal(0));
    initState->assignProperty(l3h_detc, "opacity", qreal(0));
    initState->assignProperty(dhcp, "opacity", qreal(0));
    initState->assignProperty(dhcpdis, "opacity", qreal(0));
    initState->assignProperty(dhcpoff, "opacity", qreal(0));
    initState->assignProperty(dhcpreq, "opacity", qreal(0));
    initState->assignProperty(dhcpack, "opacity", qreal(0));
    initState->assignProperty(ipconfig, "opacity", qreal(0));
    initState->assignProperty(l2h, "opacity", qreal(0));
    initState->assignProperty(l3h, "opacity", qreal(0));
    initState->assignProperty(init, "opacity", qreal(1));
    initState->assignProperty(handoffdelay, "opacity", qreal(1));
    initState->assignProperty(l2hdelay, "opacity", qreal(0));
    initState->assignProperty(l3hdelay, "opacity", qreal(0));
    initState->assignProperty(l2hddelay, "opacity", qreal(0));
    initState->assignProperty(probdelay, "opacity", qreal(0));
    initState->assignProperty(authdelay, "opacity", qreal(0));
    initState->assignProperty(assodelay, "opacity", qreal(0));
    initState->assignProperty(l3hddelay, "opacity", qreal(0));
    initState->assignProperty(dhcpdelay, "opacity", qreal(0));
    initState->assignProperty(ipchdelay, "opacity", qreal(0));

    // state1: L2H + L3H
    state1->assignProperty(widget, "geometry", QRectF(600, 0, 50, 100));
    state1->assignProperty(mn, "pos", QPointF(80+90, 0));
    state1->assignProperty(ap1, "pos", QPointF(292+90, 0));
    state1->assignProperty(ap2, "pos", QPointF(402+90, 0));
    state1->assignProperty(line1, "pos", QPointF(110+90, 75));
    state1->assignProperty(line2, "pos", QPointF(352+90, 50));
    state1->assignProperty(line3, "pos", QPointF(470+90, 50));
    state1->assignProperty(retry, "pos", QPointF(-5+90, 85));
    state1->assignProperty(data_retry, "pos", QPointF(110+190, 95));
    state1->assignProperty(reasso, "pos", QPointF(110+190, 125));
    state1->assignProperty(assoresp_arrow, "pos", QPointF(-5+90, 463));
    state1->assignProperty(ipchange, "pos", QPointF(-5+90, 700));    
    state1->assignProperty(l2h, "pos", QPointF(-145+90, 109));
    state1->assignProperty(l3h, "pos", QPointF(-141+90, 470));
    state1->assignProperty(l2hdelay, "pos", QPointF(-155+90, 315));
    state1->assignProperty(l3hdelay, "pos", QPointF(-155+90, 625));
    state1->assignProperty(mn, "opacity", qreal(1));
    state1->assignProperty(ap1, "opacity", qreal(1));
    state1->assignProperty(ap2, "opacity", qreal(1));
    state1->assignProperty(line1, "opacity", qreal(1));
    state1->assignProperty(line2, "opacity", qreal(1));
    state1->assignProperty(line3, "opacity", qreal(1));
    state1->assignProperty(retry, "opacity", qreal(1));
    state1->assignProperty(data_retry, "opacity", qreal(1));
    state1->assignProperty(reasso, "opacity", qreal(1));
    state1->assignProperty(linkdown, "opacity", qreal(0));
    state1->assignProperty(linkdown_fig, "opacity", qreal(0));
    state1->assignProperty(probereq_fail, "opacity", qreal(0));
    state1->assignProperty(probereq_1, "opacity", qreal(0));
    state1->assignProperty(probereq_2, "opacity", qreal(0));
    state1->assignProperty(proberesp, "opacity", qreal(0));
    state1->assignProperty(proberesp_arrow, "opacity", qreal(0));
    state1->assignProperty(authreq_arrow, "opacity", qreal(0));
    state1->assignProperty(authresp_arrow, "opacity", qreal(0));
    state1->assignProperty(assoreq_arrow, "opacity", qreal(0));
    state1->assignProperty(assoresp_arrow, "opacity", qreal(1));
    state1->assignProperty(linkup, "opacity", qreal(0));
    state1->assignProperty(linkup_fig, "opacity", qreal(0));
    state1->assignProperty(dhcpDis_arrow, "opacity", qreal(0));
    state1->assignProperty(dhcpOffer_arrow, "opacity", qreal(0));
    state1->assignProperty(dhcpReq_arrow, "opacity", qreal(0));
    state1->assignProperty(dhcpAck_arrow, "opacity", qreal(0));
    state1->assignProperty(ipchange, "opacity", qreal(1));
    state1->assignProperty(l2h_detc, "opacity", qreal(0));
    state1->assignProperty(probing, "opacity", qreal(0));
    state1->assignProperty(auth, "opacity", qreal(0));
    state1->assignProperty(authreq, "opacity", qreal(0));
    state1->assignProperty(authresp, "opacity", qreal(0));
    state1->assignProperty(asso, "opacity", qreal(0));
    state1->assignProperty(assoreq, "opacity", qreal(0));
    state1->assignProperty(assoresp, "opacity", qreal(0));
    state1->assignProperty(l3h_detc, "opacity", qreal(0));
    state1->assignProperty(dhcp, "opacity", qreal(0));
    state1->assignProperty(dhcpdis, "opacity", qreal(0));
    state1->assignProperty(dhcpoff, "opacity", qreal(0));
    state1->assignProperty(dhcpreq, "opacity", qreal(0));
    state1->assignProperty(dhcpack, "opacity", qreal(0));
    state1->assignProperty(ipconfig, "opacity", qreal(0));
    state1->assignProperty(l2h, "opacity", qreal(1));
    state1->assignProperty(l3h, "opacity", qreal(1));
    state1->assignProperty(init, "opacity", qreal(0));
    state1->assignProperty(handoffdelay, "opacity", qreal(0));
    state1->assignProperty(l2hdelay, "opacity", qreal(1));
    state1->assignProperty(l3hdelay, "opacity", qreal(1));
    state1->assignProperty(l2hddelay, "opacity", qreal(0));
    state1->assignProperty(probdelay, "opacity", qreal(0));
    state1->assignProperty(authdelay, "opacity", qreal(0));
    state1->assignProperty(assodelay, "opacity", qreal(0));
    state1->assignProperty(l3hddelay, "opacity", qreal(0));
    state1->assignProperty(dhcpdelay, "opacity", qreal(0));
    state1->assignProperty(ipchdelay, "opacity", qreal(0));

    // state2: show L2H detection + L3H detection
    state2->assignProperty(widget, "geometry", QRectF(600, 0, 50, 100));
    state2->assignProperty(mn, "pos", QPointF(80+90, 0));
    state2->assignProperty(ap1, "pos", QPointF(292+90, 0));
    state2->assignProperty(ap2, "pos", QPointF(402+90, 0));
    state2->assignProperty(line1, "pos", QPointF(110+90, 75));
    state2->assignProperty(line2, "pos", QPointF(352+90, 50));
    state2->assignProperty(line3, "pos", QPointF(470+90, 50));
    state2->assignProperty(retry, "pos", QPointF(-5+90, 85));
    state2->assignProperty(data_retry, "pos", QPointF(110+190, 95));
    state2->assignProperty(reasso, "pos", QPointF(110+190, 125));
    state2->assignProperty(linkdown, "pos", QPointF(110+110, 160));
    state2->assignProperty(linkdown_fig, "pos", QPointF(-2+90, 150));
    state2->assignProperty(assoresp_arrow, "pos", QPointF(-5+90, 463));
    state2->assignProperty(linkup, "pos", QPointF(110+110, 500));
    state2->assignProperty(linkup_fig, "pos", QPointF(101+90, 490));
    state2->assignProperty(dhcpDis_arrow, "pos", QPointF(-2+90, 570));
    state2->assignProperty(ipchange, "pos", QPointF(-5+90, 700));
    state2->assignProperty(l2h_detc, "pos", QPointF(-30+75, 130));    
    state2->assignProperty(l3h_detc, "pos", QPointF(-30+75, 490));    
    state2->assignProperty(l2h, "pos", QPointF(-145+90, 109));
    state2->assignProperty(l3h, "pos", QPointF(-141+90, 470));    
    state2->assignProperty(l2hdelay, "pos", QPointF(-155+90, 315));
    state2->assignProperty(l3hdelay, "pos", QPointF(-155+90, 625));
    state2->assignProperty(l2hddelay, "pos", QPointF(30+90, 150));    
    state2->assignProperty(mn, "opacity", qreal(1));
    state2->assignProperty(ap1, "opacity", qreal(1));
    state2->assignProperty(ap2, "opacity", qreal(1));
    state2->assignProperty(line1, "opacity", qreal(1));
    state2->assignProperty(line2, "opacity", qreal(1));
    state2->assignProperty(line3, "opacity", qreal(1));
    state2->assignProperty(retry, "opacity", qreal(1));
    state2->assignProperty(data_retry, "opacity", qreal(1));
    state2->assignProperty(reasso, "opacity", qreal(1));
    state2->assignProperty(linkdown, "opacity", qreal(1));
    state2->assignProperty(linkdown_fig, "opacity", qreal(1));
    state2->assignProperty(probereq_fail, "opacity", qreal(0));
    state2->assignProperty(probereq_1, "opacity", qreal(0));
    state2->assignProperty(probereq_2, "opacity", qreal(0));
    state2->assignProperty(proberesp, "opacity", qreal(0));
    state2->assignProperty(proberesp_arrow, "opacity", qreal(0));
    state2->assignProperty(authreq_arrow, "opacity", qreal(0));
    state2->assignProperty(authresp_arrow, "opacity", qreal(0));
    state2->assignProperty(assoreq_arrow, "opacity", qreal(0));
    state2->assignProperty(assoresp_arrow, "opacity", qreal(1));
    state2->assignProperty(linkup, "opacity", qreal(1));
    state2->assignProperty(linkup_fig, "opacity", qreal(1));
    state2->assignProperty(dhcpDis_arrow, "opacity", qreal(1));
    state2->assignProperty(dhcpOffer_arrow, "opacity", qreal(0));
    state2->assignProperty(dhcpReq_arrow, "opacity", qreal(0));
    state2->assignProperty(dhcpAck_arrow, "opacity", qreal(0));
    state2->assignProperty(ipchange, "opacity", qreal(1));
    state2->assignProperty(l2h_detc, "opacity", qreal(1));
    state2->assignProperty(probing, "opacity", qreal(0));
    state2->assignProperty(auth, "opacity", qreal(0));
    state2->assignProperty(authreq, "opacity", qreal(0));
    state2->assignProperty(authresp, "opacity", qreal(0));
    state2->assignProperty(asso, "opacity", qreal(0));
    state2->assignProperty(assoreq, "opacity", qreal(0));
    state2->assignProperty(assoresp, "opacity", qreal(0));
    state2->assignProperty(l3h_detc, "opacity", qreal(1));
    state2->assignProperty(dhcp, "opacity", qreal(0));
    state2->assignProperty(dhcpdis, "opacity", qreal(0));
    state2->assignProperty(dhcpoff, "opacity", qreal(0));
    state2->assignProperty(dhcpreq, "opacity", qreal(0));
    state2->assignProperty(dhcpack, "opacity", qreal(0));
    state2->assignProperty(ipconfig, "opacity", qreal(0));
    state2->assignProperty(l2h, "opacity", qreal(1));
    state2->assignProperty(l3h, "opacity", qreal(1));
    state2->assignProperty(init, "opacity", qreal(0));
    state2->assignProperty(handoffdelay, "opacity", qreal(0));
    state2->assignProperty(l2hdelay, "opacity", qreal(1));
    state2->assignProperty(l3hdelay, "opacity", qreal(1));
    state2->assignProperty(l2hddelay, "opacity", qreal(1));
    state2->assignProperty(probdelay, "opacity", qreal(0));
    state2->assignProperty(authdelay, "opacity", qreal(0));
    state2->assignProperty(assodelay, "opacity", qreal(0));
    state2->assignProperty(l3hddelay, "opacity", qreal(0));
    state2->assignProperty(dhcpdelay, "opacity", qreal(0));
    state2->assignProperty(ipchdelay, "opacity", qreal(0));

    // state3: show probing + DHCP
    state3->assignProperty(widget, "geometry", QRectF(600, 0, 50, 100));
    state3->assignProperty(mn, "pos", QPointF(80+90, 0));
    state3->assignProperty(ap1, "pos", QPointF(292+90, 0));
    state3->assignProperty(ap2, "pos", QPointF(402+90, 0));
    state3->assignProperty(line1, "pos", QPointF(110+90, 75));
    state3->assignProperty(line2, "pos", QPointF(352+90, 50));
    state3->assignProperty(line3, "pos", QPointF(470+90, 50));
    state3->assignProperty(retry, "pos", QPointF(-5+90, 85));
    state3->assignProperty(data_retry, "pos", QPointF(110+190, 95));
    state3->assignProperty(reasso, "pos", QPointF(110+190, 125));
    state3->assignProperty(linkdown, "pos", QPointF(110+110, 160));
    state3->assignProperty(linkdown_fig, "pos", QPointF(-2+90, 150));
    state3->assignProperty(probereq_fail, "pos", QPointF(110+90, 170));
    state3->assignProperty(probereq_1, "pos", QPointF(110+200, 210));
    state3->assignProperty(probereq_2, "pos", QPointF(110+200, 265));
    state3->assignProperty(proberesp, "pos", QPointF(110+200, 325));
    state3->assignProperty(proberesp_arrow, "pos", QPointF(-2+90, 330));
    state3->assignProperty(assoresp_arrow, "pos", QPointF(-5+90, 463));
    state3->assignProperty(linkup, "pos", QPointF(110+110, 500));
    state3->assignProperty(linkup_fig, "pos", QPointF(101+90, 490));
    state3->assignProperty(dhcpDis_arrow, "pos", QPointF(-2+90, 570));
    state3->assignProperty(dhcpOffer_arrow, "pos", QPointF(110+90, 593));
    state3->assignProperty(dhcpReq_arrow, "pos", QPointF(110+90, 617));
    state3->assignProperty(dhcpAck_arrow, "pos", QPointF(-2+90, 640));
    state3->assignProperty(ipchange, "pos", QPointF(-5+90, 700));
    state3->assignProperty(l2h_detc, "pos", QPointF(-30+75, 130));
    state3->assignProperty(probing, "pos", QPointF(20+90, 190));    ;
    state3->assignProperty(l3h_detc, "pos", QPointF(-30+75, 490));
    state3->assignProperty(dhcp, "pos", QPointF(30+90, 600));
    state3->assignProperty(dhcpdis, "pos", QPointF(110+200, 570));
    state3->assignProperty(dhcpoff, "pos", QPointF(110+200, 595));
    state3->assignProperty(dhcpreq, "pos", QPointF(110+200, 620));
    state3->assignProperty(dhcpack, "pos", QPointF(110+200, 645));
    state3->assignProperty(l2h, "pos", QPointF(-145+90, 109));
    state3->assignProperty(l3h, "pos", QPointF(-141+90, 470));
    state3->assignProperty(init, "pos", QPointF(-150+90, 107));
    state3->assignProperty(l2hdelay, "pos", QPointF(-155+90, 315));
    state3->assignProperty(l3hdelay, "pos", QPointF(-155+90, 625));
    state3->assignProperty(l2hddelay, "pos", QPointF(30+90, 150));
    state3->assignProperty(probdelay, "pos", QPointF(30+90, 210));
    state3->assignProperty(authdelay, "pos", QPointF(30+90, 375));
    state3->assignProperty(assodelay, "pos", QPointF(30+90, 455));
    state3->assignProperty(l3hddelay, "pos", QPointF(30+90, 520));
    state3->assignProperty(dhcpdelay, "pos", QPointF(30+90, 615));
    state3->assignProperty(mn, "opacity", qreal(1));
    state3->assignProperty(ap1, "opacity", qreal(1));
    state3->assignProperty(ap2, "opacity", qreal(1));
    state3->assignProperty(line1, "opacity", qreal(1));
    state3->assignProperty(line2, "opacity", qreal(1));
    state3->assignProperty(line3, "opacity", qreal(1));
    state3->assignProperty(retry, "opacity", qreal(1));
    state3->assignProperty(data_retry, "opacity", qreal(1));
    state3->assignProperty(reasso, "opacity", qreal(1));
    state3->assignProperty(linkdown, "opacity", qreal(1));
    state3->assignProperty(linkdown_fig, "opacity", qreal(1));
    state3->assignProperty(probereq_fail, "opacity", qreal(1));
    state3->assignProperty(probereq_1, "opacity", qreal(1));
    state3->assignProperty(probereq_2, "opacity", qreal(1));
    state3->assignProperty(proberesp, "opacity", qreal(1));
    state3->assignProperty(proberesp_arrow, "opacity", qreal(1));
    state3->assignProperty(authreq_arrow, "opacity", qreal(0));
    state3->assignProperty(authresp_arrow, "opacity", qreal(0));
    state3->assignProperty(assoreq_arrow, "opacity", qreal(0));
    state3->assignProperty(assoresp_arrow, "opacity", qreal(1));
    state3->assignProperty(linkup, "opacity", qreal(1));
    state3->assignProperty(linkup_fig, "opacity", qreal(1));
    state3->assignProperty(dhcpDis_arrow, "opacity", qreal(1));
    state3->assignProperty(dhcpOffer_arrow, "opacity", qreal(1));
    state3->assignProperty(dhcpReq_arrow, "opacity", qreal(1));
    state3->assignProperty(dhcpAck_arrow, "opacity", qreal(1));
    state3->assignProperty(ipchange, "opacity", qreal(1));
    state3->assignProperty(l2h_detc, "opacity", qreal(1));
    state3->assignProperty(probing, "opacity", qreal(1));
    state3->assignProperty(auth, "opacity", qreal(0));
    state3->assignProperty(authreq, "opacity", qreal(0));
    state3->assignProperty(authresp, "opacity", qreal(0));
    state3->assignProperty(asso, "opacity", qreal(0));
    state3->assignProperty(assoreq, "opacity", qreal(0));
    state3->assignProperty(assoresp, "opacity", qreal(0));
    state3->assignProperty(l3h_detc, "opacity", qreal(1));
    state3->assignProperty(dhcp, "opacity", qreal(1));
    state3->assignProperty(dhcpdis, "opacity", qreal(1));
    state3->assignProperty(dhcpoff, "opacity", qreal(1));
    state3->assignProperty(dhcpreq, "opacity", qreal(1));
    state3->assignProperty(dhcpack, "opacity", qreal(1));
    state3->assignProperty(ipconfig, "opacity", qreal(0));
    state3->assignProperty(l2h, "opacity", qreal(1));
    state3->assignProperty(l3h, "opacity", qreal(1));
    state3->assignProperty(init, "opacity", qreal(0));
    state3->assignProperty(handoffdelay, "opacity", qreal(0));
    state3->assignProperty(l2hdelay, "opacity", qreal(1));
    state3->assignProperty(l3hdelay, "opacity", qreal(1));
    state3->assignProperty(l2hddelay, "opacity", qreal(1));
    state3->assignProperty(probdelay, "opacity", qreal(1));
    state3->assignProperty(authdelay, "opacity", qreal(0));
    state3->assignProperty(assodelay, "opacity", qreal(0));
    state3->assignProperty(l3hddelay, "opacity", qreal(1));
    state3->assignProperty(dhcpdelay, "opacity", qreal(1));
    state3->assignProperty(ipchdelay, "opacity", qreal(0));

    // Final State
    finalState->assignProperty(widget, "geometry", QRectF(600, 0, 50, 100));
    finalState->assignProperty(mn, "pos", QPointF(80+90, 0));
    finalState->assignProperty(ap1, "pos", QPointF(292+90, 0));
    finalState->assignProperty(ap2, "pos", QPointF(402+90, 0));
    finalState->assignProperty(line1, "pos", QPointF(110+90, 75));
    finalState->assignProperty(line2, "pos", QPointF(352+90, 50));
    finalState->assignProperty(line3, "pos", QPointF(470+90, 50));
    finalState->assignProperty(retry, "pos", QPointF(-5+90, 85));
    finalState->assignProperty(data_retry, "pos", QPointF(110+190, 95));
    finalState->assignProperty(reasso, "pos", QPointF(110+190, 125));
    finalState->assignProperty(linkdown, "pos", QPointF(110+110, 160));
    finalState->assignProperty(linkdown_fig, "pos", QPointF(-2+90, 150));
    finalState->assignProperty(probereq_fail, "pos", QPointF(110+90, 170));
    finalState->assignProperty(probereq_1, "pos", QPointF(110+200, 210));
    finalState->assignProperty(probereq_2, "pos", QPointF(110+200, 265));
    finalState->assignProperty(proberesp, "pos", QPointF(110+200, 325));
    finalState->assignProperty(proberesp_arrow, "pos", QPointF(-2+90, 330));
    finalState->assignProperty(authreq_arrow, "pos", QPointF(110+90, 365));
    finalState->assignProperty(authresp_arrow, "pos", QPointF(-2+90, 400));
    finalState->assignProperty(assoreq_arrow, "pos", QPointF(110+90, 430));
    finalState->assignProperty(assoresp_arrow, "pos", QPointF(-5+90, 463));
    finalState->assignProperty(linkup, "pos", QPointF(110+110, 500));
    finalState->assignProperty(linkup_fig, "pos", QPointF(101+90, 490));
    finalState->assignProperty(dhcpDis_arrow, "pos", QPointF(-2+90, 570));
    finalState->assignProperty(dhcpOffer_arrow, "pos", QPointF(110+90, 593));
    finalState->assignProperty(dhcpReq_arrow, "pos", QPointF(110+90, 617));
    finalState->assignProperty(dhcpAck_arrow, "pos", QPointF(-2+90, 640));
    finalState->assignProperty(ipchange, "pos", QPointF(-5+90, 700));
    finalState->assignProperty(l2h_detc, "pos", QPointF(-30+75, 130));
    finalState->assignProperty(probing, "pos", QPointF(20+90, 190));
    finalState->assignProperty(auth, "pos", QPointF(-30+70, 360));
    finalState->assignProperty(authreq, "pos", QPointF(110+200, 365));
    finalState->assignProperty(authresp, "pos", QPointF(110+200, 400));
    finalState->assignProperty(asso, "pos", QPointF(-10+80, 440));
    finalState->assignProperty(assoreq, "pos", QPointF(110+200, 430));
    finalState->assignProperty(assoresp, "pos", QPointF(110+200, 462));
    finalState->assignProperty(l3h_detc, "pos", QPointF(-30+75, 490));
    finalState->assignProperty(dhcp, "pos", QPointF(30+90, 600));
    finalState->assignProperty(dhcpdis, "pos", QPointF(110+200, 570));
    finalState->assignProperty(dhcpoff, "pos", QPointF(110+200, 595));
    finalState->assignProperty(dhcpreq, "pos", QPointF(110+200, 620));
    finalState->assignProperty(dhcpack, "pos", QPointF(110+200, 645));
    finalState->assignProperty(ipconfig, "pos", QPointF(-45+80, 675));
    finalState->assignProperty(l2h, "pos", QPointF(-145+90, 109));
    finalState->assignProperty(l3h, "pos", QPointF(-141+90, 470));
    finalState->assignProperty(init, "pos", QPointF(-150+90, 107));
    finalState->assignProperty(handoffdelay, "pos", QPointF(-160+90, 440));
    finalState->assignProperty(l2hdelay, "pos", QPointF(-155+90, 315));
    finalState->assignProperty(l3hdelay, "pos", QPointF(-155+90, 625));
    finalState->assignProperty(l2hddelay, "pos", QPointF(30+90, 150));
    finalState->assignProperty(probdelay, "pos", QPointF(30+90, 210));
    finalState->assignProperty(authdelay, "pos", QPointF(30+90, 380));
    finalState->assignProperty(assodelay, "pos", QPointF(30+90, 455));
    finalState->assignProperty(l3hddelay, "pos", QPointF(30+90, 520));
    finalState->assignProperty(dhcpdelay, "pos", QPointF(30+90, 615));
    finalState->assignProperty(ipchdelay, "pos", QPointF(30+90, 695)); //!!!!!!!!!!!!!!!! here !!!!!!!!!!!!!!!!!!!
    finalState->assignProperty(mn, "opacity", qreal(1));
    finalState->assignProperty(ap1, "opacity", qreal(1));
    finalState->assignProperty(ap2, "opacity", qreal(1));
    finalState->assignProperty(line1, "opacity", qreal(1));
    finalState->assignProperty(line2, "opacity", qreal(1));
    finalState->assignProperty(line3, "opacity", qreal(1));
    finalState->assignProperty(retry, "opacity", qreal(1));
    finalState->assignProperty(data_retry, "opacity", qreal(1));
    finalState->assignProperty(reasso, "opacity", qreal(1));
    finalState->assignProperty(linkdown, "opacity", qreal(1));
    finalState->assignProperty(linkdown_fig, "opacity", qreal(1));
    finalState->assignProperty(probereq_fail, "opacity", qreal(1));
    finalState->assignProperty(probereq_1, "opacity", qreal(1));
    finalState->assignProperty(probereq_2, "opacity", qreal(1));
    finalState->assignProperty(proberesp, "opacity", qreal(1));
    finalState->assignProperty(proberesp_arrow, "opacity", qreal(1));
    finalState->assignProperty(authreq_arrow, "opacity", qreal(1));
    finalState->assignProperty(authresp_arrow, "opacity", qreal(1));
    finalState->assignProperty(assoreq_arrow, "opacity", qreal(1));
    finalState->assignProperty(assoresp_arrow, "opacity", qreal(1));
    finalState->assignProperty(linkup, "opacity", qreal(1));
    finalState->assignProperty(linkup_fig, "opacity", qreal(1));
    finalState->assignProperty(dhcpDis_arrow, "opacity", qreal(1));
    finalState->assignProperty(dhcpOffer_arrow, "opacity", qreal(1));
    finalState->assignProperty(dhcpReq_arrow, "opacity", qreal(1));
    finalState->assignProperty(dhcpAck_arrow, "opacity", qreal(1));
    finalState->assignProperty(ipchange, "opacity", qreal(1));
    finalState->assignProperty(l2h_detc, "opacity", qreal(1));
    finalState->assignProperty(probing, "opacity", qreal(1));
    finalState->assignProperty(auth, "opacity", qreal(1));
    finalState->assignProperty(authreq, "opacity", qreal(1));
    finalState->assignProperty(authresp, "opacity", qreal(1));
    finalState->assignProperty(asso, "opacity", qreal(1));
    finalState->assignProperty(assoreq, "opacity", qreal(1));
    finalState->assignProperty(assoresp, "opacity", qreal(1));
    finalState->assignProperty(l3h_detc, "opacity", qreal(1));
    finalState->assignProperty(dhcp, "opacity", qreal(1));
    finalState->assignProperty(dhcpdis, "opacity", qreal(1));
    finalState->assignProperty(dhcpoff, "opacity", qreal(1));
    finalState->assignProperty(dhcpreq, "opacity", qreal(1));
    finalState->assignProperty(dhcpack, "opacity", qreal(1));
    finalState->assignProperty(ipconfig, "opacity", qreal(1));
    finalState->assignProperty(l2h, "opacity", qreal(1));
    finalState->assignProperty(l3h, "opacity", qreal(1));
    finalState->assignProperty(init, "opacity", qreal(0));
    finalState->assignProperty(handoffdelay, "opacity", qreal(0));
    finalState->assignProperty(l2hdelay, "opacity", qreal(1));
    finalState->assignProperty(l3hdelay, "opacity", qreal(1));
    finalState->assignProperty(l2hddelay, "opacity", qreal(1));
    finalState->assignProperty(probdelay, "opacity", qreal(1));
    finalState->assignProperty(authdelay, "opacity", qreal(1));
    finalState->assignProperty(assodelay, "opacity", qreal(1));
    finalState->assignProperty(l3hddelay, "opacity", qreal(1));
    finalState->assignProperty(dhcpdelay, "opacity", qreal(1));
    finalState->assignProperty(ipchdelay, "opacity", qreal(1));

    QGraphicsScene * scene = new QGraphicsScene(this);
    scene->setBackgroundBrush(QPixmap(":/images/white.png"));
    scene->setItemIndexMethod(QGraphicsScene::NoIndex);
    scene->addItem(widget);
    scene->addItem(mn);
    scene->addItem(ap1);
    scene->addItem(ap2);
    scene->addItem(line1);
    scene->addItem(line2);
    scene->addItem(line3);
    scene->addItem(retry);
    scene->addItem(data_retry);
    scene->addItem(reasso);
    scene->addItem(linkdown);
    scene->addItem(linkdown_fig);
    scene->addItem(probereq_fail);
    scene->addItem(probereq_1);
    scene->addItem(probereq_2);
    scene->addItem(proberesp);
    scene->addItem(proberesp_arrow);
    scene->addItem(authreq_arrow);
    scene->addItem(authresp_arrow);
    scene->addItem(assoreq_arrow);
    scene->addItem(assoresp_arrow);
    scene->addItem(linkup);
    scene->addItem(linkup_fig);
    scene->addItem(dhcpDis_arrow);
    scene->addItem(dhcpOffer_arrow);
    scene->addItem(dhcpReq_arrow);
    scene->addItem(dhcpAck_arrow);
    scene->addItem(ipchange);
    scene->addItem(l2h_detc);
    scene->addItem(probing);
    scene->addItem(auth);
    scene->addItem(authreq);
    scene->addItem(authresp);
    scene->addItem(asso);
    scene->addItem(assoreq);
    scene->addItem(assoresp);
    scene->addItem(l3h_detc);
    scene->addItem(dhcp);
    scene->addItem(dhcpdis);
    scene->addItem(dhcpoff);
    scene->addItem(dhcpreq);
    scene->addItem(dhcpack);
    scene->addItem(ipconfig);
    scene->addItem(l2h);
    scene->addItem(l3h);
    scene->addItem(init);
    scene->addItem(handoffdelay);
    scene->addItem(l2hdelay);
    scene->addItem(l3hdelay);
    scene->addItem(l2hddelay);
    scene->addItem(probdelay);
    scene->addItem(authdelay);
    scene->addItem(assodelay);
    scene->addItem(l3hddelay);
    scene->addItem(dhcpdelay);
    scene->addItem(ipchdelay);
    scene->setSceneRect(0, 0, 600, 750);
    //scene->setSceneRect(scene->itemsBoundingRect());
    setScene(scene);
    setMinimumSize(500, 600);
    //scale(1.5, 2.0);
    setWindowTitle(tr("Handoff Procedure"));

    QAbstractTransition * init2one;
    QAbstractTransition * one2two;
    QAbstractTransition * two2three;
    QAbstractTransition * three2final;
    init2one = initState->addTransition(zoomOutIcon, SIGNAL(clicked()), state1);
    one2two = state1->addTransition(zoomOutIcon, SIGNAL(clicked()), state2);
    two2three = state2->addTransition(zoomOutIcon, SIGNAL(clicked()), state3);
    three2final = state3->addTransition(zoomOutIcon, SIGNAL(clicked()), finalState);

    QAbstractTransition * final2three;
    QAbstractTransition * three2two;
    QAbstractTransition * two2one;
    QAbstractTransition * one2init;
    final2three = finalState->addTransition(zoomInIcon, SIGNAL(clicked()), state3);
    three2two = state3->addTransition(zoomInIcon, SIGNAL(clicked()), state2);
    two2one = state2->addTransition(zoomInIcon, SIGNAL(clicked()), state1);
    one2init = state1->addTransition(zoomInIcon, SIGNAL(clicked()), initState);

    machine->start();    
}

void ZoomWidget::resizeEvent(QResizeEvent * event)
{
    QGraphicsView::resizeEvent(event);
    fitInView(scene()->sceneRect(), Qt::KeepAspectRatio);
}

void ZoomWidget::updateTime()
{
    qreal time;

    unsigned int sniffer_size = logmatcher->getSnifferLogSize();
    cout << "[zoom] event size: " << logmatcher->getEventSize() <<
            ", sniffer size: " << sniffer_size << endl;
    cout << "[zoom] retry: " << logmatcher->retry_idx + 1 <<
            ", reAssoreq: " << logmatcher->reAssoReq_idx + 1 <<
            ", probeResp: " << logmatcher->probeResp_idx + 1 <<
            ", authResp: " << logmatcher->authResp_idx + 1 <<
            ", assoResp: " << logmatcher->assoResp_idx + 1 << endl;

    if (logmatcher->getEventSize() != 0) {
        time = timeAnalyzer->getDHCPdelay();
        dhcpdelay->getDelayTime(time);

        time = timeAnalyzer->getIPCHdelay();
        ipchdelay->getDelayTime(time);
    }

    if (logmatcher->getSnifferLogSize() != 0) {
        if (logmatcher->probeResp_idx != -1 && logmatcher->authResp_idx != -1) {
            time = timeAnalyzer->getAuthDelay();
            authdelay->getDelayTime(time);
        }

        if (logmatcher->authResp_idx != -1 && logmatcher->assoResp_idx != -1) {
            time = timeAnalyzer->getAssoDelay();
            assodelay->getDelayTime(time);
        }

        if (logmatcher->retry_idx != -1 && logmatcher->assoResp_idx != -1) {
            time = timeAnalyzer->getL2Hdelay();
            l2hdelay->getDelayTime(time);
        }
    }

    if (logmatcher->getEventSize() != 0 && logmatcher->getSnifferLogSize() != 0) {
        if (logmatcher->retry_idx != -1) {
            time = timeAnalyzer->getL2HDdelay();
            l2hddelay->getDelayTime(time);
        }

        if (logmatcher->probeResp_idx != -1) {
            time = timeAnalyzer->getProbDelay();
            probdelay->getDelayTime(time);
        }

        if (logmatcher->assoResp_idx != -1) {
            time = timeAnalyzer->getL3HDdelay();
            l3hddelay->getDelayTime(time);
        }

        if (logmatcher->assoResp_idx != -1) {
            time = timeAnalyzer->getL3Hdelay();
            l3hdelay->getDelayTime(time);
        }

        if (logmatcher->retry_idx != -1) {
            time = timeAnalyzer->getHandoffDelay();
            handoffdelay->getDelayTime(time);
        }
    }
}
