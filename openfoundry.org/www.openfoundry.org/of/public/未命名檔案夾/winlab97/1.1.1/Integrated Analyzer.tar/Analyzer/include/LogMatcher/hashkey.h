#ifndef HASHKEY_H
#define HASHKEY_H

#include <QWidget>
#include <QMultiHash>
#include <ostream>

struct Key{
    u_int ip_id;                  /* identification */
    u_char  ip_p;                 /* protocol */
    QString ip_src, ip_dst;       /* source and dest address */

    //constructor
    Key (){}
    Key (u_int id, u_char p, const QString& src, const QString& dst)
    {
        ip_id = id;
        ip_p = p;
        ip_src  = src;
        ip_dst = dst;
    }
};

//---------------
//inline is for the purpose of avoiding multiple definition
inline bool operator==(const Key &e1, const Key &e2)
{
    return (e1.ip_id == e2.ip_id)
            && (e1.ip_p == e2.ip_p)
            && (e1.ip_src == e2.ip_src)
            && (e1.ip_dst == e2.ip_dst);
}

inline uint qHash(const Key &key)
{
    return (qHash(key.ip_src) ^ qHash(key.ip_dst)) | qHash(key.ip_id) | qHash(key.ip_p);
}

inline std::ostream& operator<<(std::ostream& os, const Key &key) {
    os << "(" <<  key.ip_src.toStdString() << ", " << key.ip_dst.toStdString() << ", ";
    os << key.ip_id << ", " << (unsigned int)key.ip_p << ")";
    return os;
}

#endif // HASHKEY_H
