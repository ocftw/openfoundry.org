#include "CallGraph.h"
#include <iostream>
using namespace std;

CallGraph::CallGraph(QWidget * parent)
{
    this->parent = parent;
}

void CallGraph::graphing(const QString &caller, const QString &callee)
{
    CallRoute branch;
    CallGraphNode callerNode, calleeNode;
    if (routes.size() == 0){
        //call graph is empty
        callerNode.name = caller;
        callerNode.callerIdx = -1;
        callerNode.calleeNum++;
        calleeNode.name = callee;
        calleeNode.callerIdx = 0;
        calleeNode.scope = 1;
        //insert the nodes to a route
        branch.nodes << callerNode << calleeNode;
        routes << branch;
    } else {
        //first check if the caller is in the graph,
        //if yes, add the callee to graph of the matched one.
        //searching from back, because we want match the nearest one
        bool found = false;
        for (int i = routes.size() - 1; i >= 0 ; i--)
        {
            for (int j = routes[i].nodes.size() - 1; j >= 0; j--)
            {
                //the "j"th node in the "i"th path
                if (caller == routes[i].nodes[j].name){                    
                    found = true;
                    calleeNode.name = callee;
                    calleeNode.callerIdx = j;                   
                    //the scope of child is the scope of parent plus 1
                    calleeNode.scope = routes[i].nodes[j].scope + 1;
                    //we insert the node after the found one and its children
                    int deep = 0;
                    for (int k = j + 1; k < routes[i].nodes.size(); k++) {
                        if ( routes[i].nodes[k].scope > calleeNode.scope )
                            deep++;
                    }
                    routes[i].nodes.insert(j + routes[i].nodes[j].calleeNum + 1 + deep, calleeNode);
                    //cout << callee.toStdString() << ": " << j + routes[i].nodes[j].calleeNum + 1
                            //<< " caller: " << routes[i].nodes[j].name.toStdString() << " " << j << endl;
                    routes[i].nodes[j].calleeNum++;
                    break;
                }
            }
            if (found == true) break;
        }

        //if not, it build up a new graph branch by its own.
        if (found == false) {
            callerNode.name = caller;
            callerNode.callerIdx = -1;
            callerNode.calleeNum++;
            calleeNode.name = callee;
            calleeNode.callerIdx = 0;
            calleeNode.scope = 1;
            branch.nodes << callerNode << calleeNode;
            routes << branch;
        }
    }
}

QString CallGraph::drawGraph()
{
    QString str;
    for (int i = 0; i < routes.size(); i++)
    {
        for (int j = 0; j < routes[i].nodes.size(); j++)
        {
            for (int k = 0; k < routes[i].nodes[j].scope; k++) {
                str.append("  |  ");
                //cout << "  |  ";
            }            
            str.append(routes[i].nodes[j].name);
            //cout << routes[i].nodes[j].name.toStdString() << " " << j << endl;
            str.append("\n");
        }
        str.append("\n");
    }
    return str;
}

QString CallGraph::showRoots()
{
    QString str;
    for(int i = 0; i < routes.size(); i++){
        str.append(routes[i].nodes[0].name);
        str.append("\n");
    }
    return str;
}

void CallGraph::test(QString caller)
{
    cout << caller.toStdString() << " :" << endl;
    QList<QString> values = caller2func.values(caller);
    for(int i = 0; i < values.size(); i++){
        cout << "   " << values.at(i).toStdString() << endl;
    }
}
