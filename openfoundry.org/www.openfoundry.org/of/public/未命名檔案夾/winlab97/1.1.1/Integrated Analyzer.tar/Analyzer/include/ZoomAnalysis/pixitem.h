#ifndef PIXITEM_H
#define PIXITEM_H

#include <QtGui>
#include <iostream>
using namespace std;

class pixItem : public QGraphicsObject
{
    Q_OBJECT

public:
    pixItem(const QPixmap &pix);
    pixItem(const QString &delaytime) { delay = delaytime; }

    void paint(QPainter * painter, const QStyleOptionGraphicsItem *, QWidget *);
    QRectF boundingRect() const;
    void getDelayTime(qreal);

private:
    QPixmap icon;
    QString delay;
};

class textItem : public QGraphicsObject
{
    Q_OBJECT

public:
    textItem(const QPixmap &pix);
    textItem(const QString &textname) { text = textname; }

    void paint(QPainter * painter, const QStyleOptionGraphicsItem *, QWidget *);
    QRectF boundingRect() const;

private:
    QPixmap icon;
    QString text;
};


#endif // PIXITEM_H
