#ifndef RENDERAREA_H
#define RENDERAREA_H

#include <QFont>
#include <QList>
#include <QPainterPath>
#include <QRect>
#include <QWidget>
#include "TimeAnalysis.h"

QT_BEGIN_NAMESPACE
class QPaintEvent;
QT_END_NAMESPACE

#define ENLARGE 80
#define RANGE 370

class RenderArea : public QWidget
{
    Q_OBJECT

public:
    RenderArea(QWidget *parent = 0);
    //void setShape(const QPainterPath &shape);
    QSize minimumSizeHint() const;
    QSize sizeHint() const;

    void setTimeAnalyzer(TimeAnalysis *timeAnalyzer) { this->timeAnalyzer = timeAnalyzer; }
    void setMaximum(int size) { pktSize = size; }

public slots:
    void setValue(int s_idx);

protected:
    void paintEvent(QPaintEvent *event);

private:
    TimeAnalysis *timeAnalyzer;
    int pktSize;
    int startIdx;
    int endIdx;

    void drawCoordinates(QPainter &painter);
    void drawCalibration(QPainter &painter, int &range);
    void drawPktPosition(QPainter &painter);
    void drawRectPkt(QPainter &painter, QPoint &end, int idx);
    //void drawShape(QPainter &painter);
    //void transformPainter(QPainter &painter);

    //QPainterPath shape;
    QRect xBoundingRect;
    QRect yBoundingRect;
};
//! [2]

#endif // RENDERAREA_H
