#ifndef WLANREADER_H
#define WLANREADER_H

#include <QtCore>
#include <arpa/inet.h>
#include <netinet/ip.h>

#define ETH_HEADER_SIZE 14
#define AVS_HEADER_SIZE 64          /* AVS capture header size */
#define RADIOTAP_HEADER_SIZE 26     /* Radiotap header size */
#define DATA_80211_FRAME_SIZE 24    /* header for 802.11 data packet */
#define DATA_80211_QoS_FRAME_SIZE 26    /* header for 802.11 Qos data packet */
#define LLC_HEADER_SIZE 8           /* LLC frame for encapsulation */
#define IP_HEADER_SIZE 20
#define UDP_HEADER_SIZE 8

#define UNKNOWN 99
#define IEEE_80211 11
#define LLC 98
#define LLMNR 97
#define NBNS 96
#define SSDP 95
#define MDNS 94
#define DHCP 93
#define NATPMP 92
#define LLC_STP 0x010b                  /* Spanning Tree Protocol */
#define ETHERTYPE_IPv6 0x86dd           /* Internet Protocol v6 */
#define PIM 0x67
#define BNA 0x31
#define IGMP 0x02
#define EMCON 0x0e

#define BOOTPS 67  // bootstrap protocol server / DHCP
#define BOOTPC 68  // bootstrap protocol client / DHCP

struct ieee80211_radiotap_header
{
    u_int8_t        it_version;     /* set to 0 */
    u_int8_t        it_pad;
    u_int16_t       it_len;         /* entire length */
    u_int32_t       it_present;     /* fields present */
};// __attribute__((__packed__));

struct ieee80211_mac_header
{
    unsigned char fc[2];
    unsigned char id[2];
    unsigned char add1[6];
    unsigned char add2[6];
    unsigned char add3[6];
    //unsigned char sc[2];
    u_int16_t sc;
};

struct frame_control
{
    unsigned protocol:2;
    unsigned type:2;
    unsigned subtype:4;
    unsigned to_ds:1;
    unsigned from_ds:1;
    unsigned more_frag:1;
    unsigned retry:1;
    unsigned pwr_mgt:1;
    unsigned more_data:1;
    unsigned wep:1;
    unsigned order:1;
};

struct beacon_header
{
    unsigned char timestamp[8];
    unsigned char beacon_interval[2];
    unsigned char cap_info[2];
};

struct llc_header
{
    u_int8_t dsap;
    u_int8_t ssap;
    u_int8_t ctl;
    u_int8_t org[3];
    //u_int8_t org2;
    u_int16_t ether_type;           /* ethernet type */
};// __attribute__ ((__packed__));

#ifndef MY_IP
#define MY_IP
struct my_ip
{
    u_char  ip_vhl;                 /* version << 4 | header length >> 2 */
    u_char  ip_tos;                 /* type of service */
    u_short ip_len;                 /* total length */
    u_short ip_id;                  /* identification */
    u_short ip_off;                 /* fragment offset field */
    #define IP_RF 0x8000            /* reserved fragment flag */
    #define IP_DF 0x4000            /* dont fragment flag */
    #define IP_MF 0x2000            /* more fragments flag */
    #define IP_OFFMASK 0x1fff       /* mask for fragmenting bits */
    u_char  ip_ttl;                 /* time to live */
    u_char  ip_p;                   /* protocol */
    u_short ip_sum;                 /* checksum */
    struct  in_addr ip_src, ip_dst; /* source and dest address */
};

#define IP_HL(ip) (((ip)->ip_vhl) & 0x0f)
#define IP_V(ip)  (((ip)->ip_vhl) >> 4)
#endif

struct UDP_hdr
{
    u_short uh_sport;               /* source port */
    u_short uh_dport;               /* destination port */
    u_short uh_ulen;                /* datagram length */
    u_short uh_sum;                 /* datagram checksum */
};

#endif // WLANREADER_H
