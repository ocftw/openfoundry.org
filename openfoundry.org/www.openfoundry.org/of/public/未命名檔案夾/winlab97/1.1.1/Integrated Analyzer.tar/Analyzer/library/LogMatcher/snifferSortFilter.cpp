#include <QtGui>
#include "snifferSortFilter.h"
#include <stdio.h>

snifferSortFilter::snifferSortFilter(QObject *parent)
    : QSortFilterProxyModel(parent)
{
    flag[SRCIP] = true;
    flag[DSTIP] = false;
    flag[PROTO] = false;
    flag[NO] = false;
}

bool snifferSortFilter::filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const
{
    if(flag[SRCIP] == true){
        QModelIndex index = sourceModel()->index(sourceRow, 2, sourceParent);
        return (sourceModel()->data(index).toString().contains(filterRegExp()));
    } else if(flag[DSTIP] == true){
        QModelIndex index = sourceModel()->index(sourceRow, 3, sourceParent);
        return (sourceModel()->data(index).toString().contains(filterRegExp()));
    } else if(flag[PROTO]) {
        QModelIndex index = sourceModel()->index(sourceRow, 4, sourceParent);
        return (sourceModel()->data(index).toString().contains(filterRegExp()));
    } else if(flag[NO]) {
        QModelIndex index = sourceModel()->index(sourceRow, 0, sourceParent);
        return (sourceModel()->data(index).toString().contains(filterRegExp()));
    }

    return true;
}

//Protocol is ignored!
bool snifferSortFilter::lessThan(const QModelIndex &left, const QModelIndex &right) const
{
    QVariant leftData = sourceModel()->data(left);
    QVariant rightData = sourceModel()->data(right);

    if(leftData.type() == QVariant::Int){
        //Compare "No."
        return leftData.toInt() < rightData.toInt();
    }else{
        char ip_str[20];
        char ip2_str[20];
        QString leftString = leftData.toString();
        QString rightString = rightData.toString();

        strcpy(ip_str, leftString.toStdString().c_str());
        strcpy(ip2_str, rightString.toStdString().c_str());

        int ip[4];
        int ip2[4];
        int retCode, retCode2;

        retCode = sscanf(ip_str,"%d.%d.%d.%d",&ip[0],&ip[1],&ip[2],&ip[3]);
        retCode2 = sscanf(ip2_str,"%d.%d.%d.%d",&ip2[0],&ip2[1],&ip2[2],&ip2[3]);

        //compare "Protocol"!!!!
        if (retCode != 4 && retCode != 4)
            return QString::localeAwareCompare(leftString, rightString) < 0;

        if (retCode != 4){
            //null compare with others, we assume that null is the bigger one.
            return false;
        }

        if (retCode2 != 4){
            //others compare with null.
            return true;
        }

        //compare IP addr.
        if(ip[0] != ip2[0]){
            return ip[0] < ip2[0];
        }else{
            if(ip[1] != ip2[1]){
                return ip[1] < ip2[1];
            }else{
                if(ip[2] != ip2[2]){
                    return ip[2] < ip2[2];
                }else{
                    return ip[3] < ip2[3];
                }
            }
        }
    }
}
