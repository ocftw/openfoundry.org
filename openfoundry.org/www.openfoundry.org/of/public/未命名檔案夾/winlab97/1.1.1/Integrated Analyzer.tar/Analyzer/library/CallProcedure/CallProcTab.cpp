#include "CallProcTab.h"

CallProcTab::CallProcTab(QWidget *parent)
    : QTabWidget(parent)
{
    callprocTab = new QTextEdit();
    callgraphTab = new QTextEdit();
    callgraph = new CallGraph(this);

    //addTab(callprocTab, "Call Procedure");
    addTab(callgraphTab, "Call Graph");
    addTab(callprocTab, "Call Procedure");
}
