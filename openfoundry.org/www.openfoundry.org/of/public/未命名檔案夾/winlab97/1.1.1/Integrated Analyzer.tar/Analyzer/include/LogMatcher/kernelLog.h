#ifndef KERNELLOG_H
#define KERNELLOG_H

#include <QtGui>
#include <QtNetwork>
#include "readSymTable.h"
#include "hashkey.h"

#define LEVEL 1

struct Footprint
{
    quint8 pkt_t;
    quint32 id_pkt;

    bool ipFlag;
    QHostAddress * dipv4, * sipv4;
    quint16 * id, * mac_t;
    quint8 * protocol;
};

class KernelLog
{
public:
    // functions used for accessing the log data
    void getData(quint32 funcID, quint32 callerID, quint8 func_type, quint64 time, quint8 t_len);
    void getPktNumAndIniFP(int pkt_num);
    void getPktID(int k, quint8 pkt_type, quint32 pkt_id);
    void getIPheader(int k, QHostAddress dip, QHostAddress sip, quint16 iden, quint8 proto);
    void getMacType(int k, quint16 mac_type);

    // functions for return data
    int getPktNum() { return pktNum; }
    QString getFunction();
    QString getCaller();
    QString getTime();
    qreal getTimeF();
    quint8 getType() { return type; }
    QString getPktID(quint32);
    QList< Key > getKey();
    Key getKey(quint32);

    // functions for adjudging something
    bool isIPrecord();
    bool hasThePkt(quint32);    
    void printkey(quint32);
    void outputData(int scope, quint64 i);

private:
    quint32 func, caller;
    quint64 timestamp;
    quint8 type, tot_len;
    int pktNum;

    Footprint * ftPrint;
};

#endif // KERNELLOG_H
