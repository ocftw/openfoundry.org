#include "readSymTable.h"

const int MAXLEN = 256;
char * sym_t;
QHash< QString, QString > addr2sym;
QList< quint32 > addr_list;

void getSymTable(char *sym_table)
{
    sym_t = sym_table;
}

QString addr2symFunc(QString addr)
{
    int status;
    char cmd[MAXLEN];
    char line[MAXLEN];
    string funcaddr;

    funcaddr = addr.toStdString();
    sprintf(cmd, "echo 0x%s | ./addr2sym -m %s", funcaddr.c_str(), sym_t);

    FILE *fp = popen(cmd, "r");

    if (fp == NULL){
        cout << "addr2sym popen failed" << endl;
        return NULL;
    }

    while (fgets(line, MAXLEN, fp) != NULL){
        //printf("%s", line);
    }
    line[strlen(line) - 1] = '\0';

    status = pclose(fp);
    if (status == -1) {
        /* Error reported by pclose() */
        cout << "addr2sym close pipe failed." << endl;
    } else {
        /* Use macros described under wait() to inspect `status' in order
           to determine success/failure of command executed by popen() */
        //cout << "addr2sym close success." << endl;
    }

    return QString(line);
}

void readSymTable()
{
    ifstream in(sym_t);
    string addr_str;
    char symtype;
    string funcname;
    int addr;

    while(!in.eof())
    {
        in >> addr_str >> symtype >> funcname;
        if (in.fail()) break;
        //cout << addr << ' ' << symtype << ' ' << funcname << endl;

        sscanf(addr_str.c_str(), "%x", &addr);
        addr_list << addr;
        addr2sym.insert(QString(addr_str.c_str()), QString(funcname.c_str()));
    }
    in.close();
}

QString lookupSym(quint32 addr)
{
    QString addr_str;
    addr_str = QString::number(addr, 16);

    QList<QString> value = addr2sym.values(addr_str);
    if(!value.isEmpty()){
        //if the addr is in the hash table,
        //then return the value
        return value.at(0);
    } else {
        //if addr is not in the hash table,
        //first check if addr is outside the range of address.
        if(addr > addr_list.at(addr_list.size() - 1) || addr < addr_list.at(0)){
            QString addrname = "0x";
            addrname.append(QString::number(addr, 16));
            return QString(addrname);
        } else {
            //if is not either in hash table or outside the range,
            //do a binary search in the addr array.
            int guess_idx;
            int lower = 0;
            int upper = addr_list.size() - 1;
            while(lower != upper - 1)
            {
                guess_idx = lower + (upper - lower) / 2;
                if (addr < addr_list.at(guess_idx))
                    upper = guess_idx;
                if (addr > addr_list.at(guess_idx))
                    lower = guess_idx;
            }

            int offset = addr - addr_list.at(lower);
            QString name = addr2sym.value(QString::number(addr_list.at(lower), 16));

            //in addr2sym python,
            //there is a line "if startswith(name, ".")"
            string name_str = name.toStdString();
            char funcname[MAXLEN];
            sprintf(funcname, "%s+0x%x", name_str.c_str(), offset);
            return QString(funcname);
        }
    }

    return "lookup symbol failed";
}

void compareAddr(quint32 addr)
{
    for(int i = 0; i < addr_list.size(); i++){
        if(addr == addr_list.at(i))
            printf("addr matched at %d: %x\n", i, addr_list.at(i));
    }
}
