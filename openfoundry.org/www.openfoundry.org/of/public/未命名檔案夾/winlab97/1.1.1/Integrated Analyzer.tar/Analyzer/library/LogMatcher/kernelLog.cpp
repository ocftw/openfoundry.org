#include <sys/time.h>
#include <time.h>
#include <iostream>
#include "kernelLog.h"

using namespace std;

void KernelLog::getData(quint32 funcID, quint32 callerID, quint8 func_type, quint64 time, quint8 t_len)
{
    func = funcID;
    caller = callerID;
    type = func_type;
    timestamp = time;
    tot_len = t_len;
}

void KernelLog::getPktNumAndIniFP(int pkt_num)
{
    pktNum = pkt_num;
    if (pktNum != 0)
        ftPrint = new Footprint[pktNum];
}

void KernelLog::getPktID(int k, quint8 pkt_type, quint32 pkt_id)
{
    if (pktNum == 0) {
        qDebug("[KernelLog]getPktID: try to use Footprint with pktNum = 0");
        exit(1);
    }

    ftPrint[k].pkt_t = pkt_type;
    ftPrint[k].id_pkt = pkt_id;

    ftPrint[k].ipFlag = false;
    if (ftPrint[k].pkt_t == 1 || ftPrint[k].pkt_t == 3)
    {
        ftPrint[k].ipFlag = true;
        ftPrint[k].dipv4 = new QHostAddress;
        ftPrint[k].sipv4 = new QHostAddress;
        ftPrint[k].id = new quint16;
        ftPrint[k].protocol = new quint8;
    }
    if (ftPrint[k].pkt_t == 2 || ftPrint[k].pkt_t == 3)
        ftPrint[k].mac_t = new quint16;
}

void KernelLog::getIPheader(int k, QHostAddress dip, QHostAddress sip, quint16 iden, quint8 proto)
{
    if (ftPrint[k].ipFlag == false) {
        cout << "[KernelLog] error: try to get IP header with no IP header" << endl;
        exit(1);
    }

    *(ftPrint[k].dipv4) = dip;
    *(ftPrint[k].sipv4) = sip;
    *(ftPrint[k].id) = iden;
    *(ftPrint[k].protocol) = proto;
}

void KernelLog::getMacType(int k, quint16 mac_type)
{
    //cout << "getMacType" << endl;
    *(ftPrint[k].mac_t) = mac_type;
}

QString KernelLog::getFunction()
{
    QString funcname = lookupSym(func);
    return funcname;
}

QString KernelLog::getCaller()
{
    QString callername = lookupSym(caller);
    return callername;
}

QString KernelLog::getTime()
{
    struct tm *ts;
    struct timeval tv;
    quint64 temp;
    temp = qToBigEndian(timestamp);//For gettime
    memcpy(&tv, &temp, sizeof(struct timeval));
    ts = localtime(&tv.tv_sec);
    char time[30];
    //strftime(time, 30, "%m-%d-%Y\t%T.", localtime(&tv.tv_sec));
    sprintf(time, "%02d:%02d:%06ld", ts->tm_min, ts->tm_sec, tv.tv_usec);
    return QString(time);
}

qreal KernelLog::getTimeF()
{
    struct timeval tv;
    quint64 temp;
    temp = qToBigEndian(timestamp);//For gettime
    memcpy(&tv, &temp, sizeof(struct timeval));
    qreal time = (qreal)tv.tv_sec + (qreal)tv.tv_usec / 1000000;
    return time;
}

QString KernelLog::getPktID(quint32 pkt_id)
{
    for (int i = 0; i < pktNum; i++)
    {
        if (ftPrint[i].id_pkt == pkt_id) {
            char pkt_addr[50];
            sprintf(pkt_addr, "0x%x %d", ftPrint[i].id_pkt, i);
            return QString(pkt_addr);
        }
    }
    return "pkt id not found";
}

QList< Key > KernelLog::getKey()
{
    int count = 0;
    Key null_key(0, 0, "null", "null");
    QList< Key > key_ls;

    for (int i = 0; i < pktNum; i++)
    {
        if (ftPrint[i].ipFlag) {
            if (ftPrint[i].id == NULL || ftPrint[i].protocol == NULL ||
                ftPrint[i].sipv4 == NULL || ftPrint[i].dipv4 == NULL) {
                qDebug("[kernel Log] getKey: null footprint showed up.");
                key_ls << null_key;
                break;
            }

            Key pkt_key(u_int(*(ftPrint[i].id)), *(ftPrint[i].protocol),
                        ftPrint[i].sipv4->toString(), ftPrint[i].dipv4->toString());
            count++;
            //return pkt_key;
            key_ls << pkt_key;
        }
    }

    if (count == 0) {
        key_ls << null_key;
        cout << "[kernel Log] This Record doesn't have key" << endl;
    }

    return key_ls;
}

Key KernelLog::getKey(quint32 pkt_id)
{
    Key null_key(0, 0, "null", "null");
    for (int i = 0; i < pktNum; i++)
    {
        if (ftPrint[i].id_pkt == pkt_id) {
            if (!ftPrint[i].ipFlag) {
                qDebug("[kernel Log] getKey: packet id is found, but not an IP packet.");
                return null_key;
            }

            if (ftPrint[i].id == NULL || ftPrint[i].protocol == NULL ||
                ftPrint[i].sipv4 == NULL || ftPrint[i].dipv4 == NULL) {
                qDebug("[kernel Log] getKey: null footprint showed up.");
                return null_key;
            }

            Key pkt_key(u_int(*(ftPrint[i].id)), *(ftPrint[i].protocol),
                        ftPrint[i].sipv4->toString(), ftPrint[i].dipv4->toString());
            return pkt_key;
        }
    }

    return null_key;
}

bool KernelLog::isIPrecord()
{
    if (pktNum == 0)
        return false;

    int idx;
    for (idx = 0; idx < pktNum; idx++)
    {
        if (ftPrint[idx].ipFlag == true)
            return true;
    }
    return false;
}

bool KernelLog::hasThePkt(quint32 pkt_id)
{
    for(int i = 0; i < pktNum; i++){
        if(ftPrint[i].id_pkt == pkt_id)
            return true;
    }
    return false;
}

void KernelLog::printkey(quint32 pkt_id)
{
    for (int i = 0; i < pktNum; i++)
    {
        if (ftPrint[i].id_pkt == pkt_id) {
            if (!ftPrint[i].ipFlag) {
                qDebug("[kernel Log]printkey: packet id found, but not an IP packet.");
                break;
            }

            cout << "(" << ftPrint[i].sipv4->toString().toStdString() << ", " <<
                     ftPrint[i].dipv4->toString().toStdString() << ", "
                     << *(ftPrint[i].id) << ", " <<
                     QString::number(*(ftPrint[i].protocol)).toStdString() << ")" << endl;
            break;
        }
    }
}

void KernelLog::outputData(int scope, quint64 i)
{
    int j;    
    quint8 pkt_len;

    cout << "========= KernelLog " << QString::number(i + 1).toStdString() << " =========" << endl;

    for (j = LEVEL; j < scope; j++)
        cout << "-";
    if (scope >= LEVEL)
        cout << getFunction().toStdString() <<
               " <-- " << getCaller().toStdString() << endl;

    for (j = LEVEL; j < scope; j++)
        cout << "-";
    if (scope >= LEVEL)
        cout << "Timestamp " << getTime().toStdString() << endl;

    pkt_len = tot_len - 18;
    if (pkt_len != 0)
    {
        int idx;
        for (idx = 0; idx < pktNum; idx++)
        {
            for (j = LEVEL; j < scope; j++)
                cout << "-";
            if (scope >= LEVEL)
                cout << "Pkt_ID " << QString::number(ftPrint[idx].id_pkt, 16).toStdString() << endl;

            if (ftPrint[idx].pkt_t == 1 || ftPrint[idx].pkt_t == 3)
            {
                for (j = LEVEL; j < scope; j++)
                    cout << "-";
                if (scope >= LEVEL)
                    cout << "(DIP: " << ftPrint[idx].dipv4->toString().toStdString() <<
                           ", SIP: " << ftPrint[idx].sipv4->toString().toStdString() << ")" << endl;

                for (j = LEVEL; j < scope; j++)
                    cout << "-";
                if (scope >= LEVEL)
                    cout << "(Iden: " << QString::number(*(ftPrint[idx].id)).toStdString() <<
                           ", Proto: " << QString::number(*(ftPrint[idx].protocol)).toStdString() << ")" << endl;
            }

            if (ftPrint[idx].pkt_t == 2 || ftPrint[idx].pkt_t == 3)
            {
                for (j = LEVEL; j < scope; j++)
                    cout << "-";
                if (scope >= LEVEL)
                    cout << "MAC_T " << QString::number(*(ftPrint[idx].mac_t), 16).toStdString() << endl;
            }
        }
    }
}

