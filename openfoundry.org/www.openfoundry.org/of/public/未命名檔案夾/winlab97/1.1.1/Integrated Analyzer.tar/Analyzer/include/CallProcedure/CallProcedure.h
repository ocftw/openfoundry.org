#ifndef CALLPROCEDURE_H
#define CALLPROCEDURE_H

#include <QtCore>
#include <QtGui>
#include <QFrame>
#include <QTextEdit>
#include "LogMatcher.h"
#include "TimeAnalysis.h"
#include "CallProcTab.h"
#include "wlanreader.h"

QT_BEGIN_NAMESPACE
class QAction;
class QActionGroup;
class QLabel;
class QMenu;
QT_END_NAMESPACE

class CallProcedure : public QObject
{
    Q_OBJECT

public:
    CallProcedure(QWidget *);
    void setLogMatcher(LogMatcher * logmatcher) { this->logmatcher = logmatcher; }
    void setTimeAnalyzer(TimeAnalysis * timeAnalyzer) { this->timeAnalyzer = timeAnalyzer; }

public slots:
    void showPopupMenu(const QModelIndex &);
    void openNewWindow();

private:
    QWidget * parent;
    CallProcTab * proc_tab;
    LogMatcher * logmatcher;
    TimeAnalysis * timeAnalyzer;
    int pkt_idx; //indicate which packet we selected

    //! [functions for procedure analysis]
    bool showCallProcedure();
    quint64 calculateEnd(quint64, QPair<QString, quint32>, quint32);
    bool checkKeyInProc(quint64, quint64, quint32, Key);
    bool checkARPInProc(quint64, quint64, quint32, quint64);
    void showPktAnalysis(quint64, quint64, quint32);
    bool showAllCall();
};

#endif // CALLPROCEDURE_H
