#ifndef CALLGRAPH_H
#define CALLGRAPH_H

#include <QtCore>
#include <QtGui>
#include <QMultiHash>

struct CallGraphNode
{
    CallGraphNode()
    {
        callerIdx = 0;
        calleeNum = 0;
        scope = 0;
    }

    QString name;
    int callerIdx; //indicate which node is its caller
    int calleeNum; //Number of child it has
    int scope;     //present which layer it is (layer means the deepth of calling)
};

struct CallRoute
{
    QList< CallGraphNode > nodes;
};

class CallGraph : public QObject
{
    Q_OBJECT

public:
    CallGraph(QWidget *);
    void doHashFunc(const QString &caller, const QString &callee){ caller2func.insert(caller, callee); }
    void graphing(const QString &, const QString &);
    QString drawGraph();
    QString showRoots();
    void test(QString);

private:
    QWidget *parent;
    QMultiHash<QString, QString> caller2func;
    QList< CallRoute > routes;
};
#endif // CALLGRAPH_H
