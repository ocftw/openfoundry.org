#ifndef TIMEANALYSIS_H
#define TIMEANALYSIS_H

#include <QtCore>
#include <QProgressDialog>
#include <time.h>
#include <sys/time.h>
#include "LogMatcher.h"

class TimeAnalysis : public QObject
{
    Q_OBJECT

public:
    TimeAnalysis(QWidget *);

    QTreeView * kernelTimeSortView;
    QAbstractItemModel * kernelTime_model;
    QSortFilterProxyModel * proxyModel;

    void setKernelTimeModel() { proxyModel->setSourceModel(kernelTime_model); }

    bool readFuncProcTimeLogFlag;

    void setLogMatcher(LogMatcher * logmatcher) { this->logmatcher = logmatcher; }
    unsigned int pktSize() { return logmatcher->getSnifferLogSize(); }

    qreal calTimeRange();
    qreal getPktTime(int idx);
    qreal drawLineRange(int s_idx, int e_idx);

    quint64 findExitPoint(quint64 &idx);
    quint64 findEntryPoint(quint64 &idx);
    qreal funcExeTime(quint64 &idx);

    qreal pktProcessingTime(quint64 &start, quint64 &end);
    void funcProcTime();
    void Load_FuncProcTime_Log(QString);

    //get delay time funcitons
    qreal getL2HDdelay();
    qreal getProbDelay();
    qreal getAuthDelay();
    qreal getAssoDelay();
    qreal getL3HDdelay();
    qreal getDHCPdelay();
    qreal getIPCHdelay();
    qreal getL2Hdelay();
    qreal getL3Hdelay();
    qreal getHandoffDelay();

private slots:
    void checkReadOrCal(bool flag) { readFuncProcTimeLogFlag = flag; }
    void kernelTimeComboBoxIndexChanged(int index) { kernelTimeFilterIndex = index; }
    void kernelTimeTextFilterChanged(const QString &text) { kernelTimeFilterText = QString(text); }
    void kernelTimeFilterGo();

private:
    QWidget * parent;

    LogMatcher * logmatcher;
    quint64 kernel_size;
    qreal firstPktTime;
    qreal * entryFuncProcTime;
    int kernelTimeFilterIndex;
    QString kernelTimeFilterText;

    QAbstractItemModel * createKernelTimeModel();
    void removeKernelTimeEntry();
};

#endif // TIMEANALYSIS_H
