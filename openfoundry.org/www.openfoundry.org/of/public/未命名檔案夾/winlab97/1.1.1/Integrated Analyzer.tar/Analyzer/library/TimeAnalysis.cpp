#include "TimeAnalysis.h"

TimeAnalysis::TimeAnalysis(QWidget * parent)
{
    this->parent = parent;
    kernel_size = 0;
    readFuncProcTimeLogFlag = true;
    kernelTimeFilterIndex = 0;

    proxyModel = new QSortFilterProxyModel;
    proxyModel->setDynamicSortFilter(true);

    kernelTimeSortView = new QTreeView;
    kernelTimeSortView->setRootIsDecorated(false);
    kernelTimeSortView->setAlternatingRowColors(true);
    kernelTimeSortView->setModel(proxyModel);
    kernelTimeSortView->setSortingEnabled(true);
    kernelTimeSortView->sortByColumn(0, Qt::AscendingOrder);

    kernelTime_model = createKernelTimeModel();
}

QAbstractItemModel * TimeAnalysis::createKernelTimeModel()
{
    QStandardItemModel * model = new QStandardItemModel(0, 4, this);

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("No."));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Proc. Time"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Function"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Caller"));

    return model;
}

void TimeAnalysis::removeKernelTimeEntry()
{
    int rows = kernelTime_model->rowCount(QModelIndex());
    for(int i = 0; i < rows ; i++){
        kernelTime_model->removeRow(0, QModelIndex());
    }
}

qreal TimeAnalysis::calTimeRange()
{
    QPair<struct timeval, struct timeval> range;
    range = logmatcher->getTimeRange();

    firstPktTime = (qreal)range.first.tv_sec + (qreal)range.first.tv_usec / 1000000;
    qreal end = (qreal)range.second.tv_sec + (qreal)range.second.tv_usec / 1000000;
    //cout << "start: " << firstPktTime << ", end: " << end << endl;
    //cout << "The time range is: " << end - firstPktTime << "s" << endl;

    return (end - firstPktTime);
}

qreal TimeAnalysis::getPktTime(int idx)
{
    struct timeval *ts;
    ts = logmatcher->getPktTime(idx);

    qreal pktTs = (qreal)ts->tv_sec + (qreal)ts->tv_usec / 1000000;
    //cout << (pktTs - firstPktTime) << endl;
    return (pktTs - firstPktTime);
}

qreal TimeAnalysis::drawLineRange(int s_idx, int e_idx)
{
    qreal start;
    qreal end;

    start = getPktTime(s_idx);
    end = getPktTime(e_idx);

    return (end - start);
}

quint64 TimeAnalysis::findExitPoint(quint64 &idx)
{
    KernelLog * tmp;
    KernelLog * kl_ptr;
    QString callee, tmp_callee, caller, tmp_caller;

    kl_ptr = logmatcher->getKernelLog(idx);
    callee = kl_ptr->getFunction();
    caller = kl_ptr->getCaller();

    for (quint64 i = idx; i < logmatcher->getKernelLogSize(); i++)
    {
        tmp = logmatcher->getKernelLog(i);
        tmp_callee = tmp->getFunction();
        tmp_caller = tmp->getCaller();
        if(callee == tmp_callee && caller == tmp_caller && tmp->getType() == 0x02) {
            return i;
        }
    }

    return 0;
}

quint64 TimeAnalysis::findEntryPoint(quint64 &idx)
{
    KernelLog * tmp;
    KernelLog * kl_ptr;
    QString callee, tmp_callee, caller, tmp_caller;

    kl_ptr = logmatcher->getKernelLog(idx);
    callee = kl_ptr->getFunction();
    caller = kl_ptr->getCaller();

    double temp = (double)idx;
    if (temp < 0){
        printf("TimeAnalysis::findEntryPoint: quint64 to double failed\n");
        return 0;
    }

    for (double i = (double)idx; i >= 0; i--)
    {
        tmp = logmatcher->getKernelLog(i);
        tmp_callee = tmp->getFunction();
        tmp_caller = tmp->getCaller();
        if(callee == tmp_callee && caller == tmp_caller && tmp->getType() == 0x01) {
            return i;
        }
    }

    return 0;
}

qreal TimeAnalysis::funcExeTime(quint64 &idx)
{
    quint64 find;
    KernelLog * tmp;
    KernelLog * kl_ptr;
    //QString callee, tmp_callee, caller, tmp_caller;
    qreal en_time, ex_time;

    kl_ptr = logmatcher->getKernelLog(idx);
    //callee = kl_ptr->getFunction();
    //caller = kl_ptr->getCaller();

    if (kl_ptr->getType() == 0x01){
        find = findExitPoint(idx);
        if (find == 0) return 0;
        else {
            tmp = logmatcher->getKernelLog(find);
            //cout << tmp->getTime().toStdString() << " - " << kl_ptr->getTime().toStdString() << endl;

            en_time = kl_ptr->getTimeF();
            ex_time = tmp->getTimeF();
            return (ex_time - en_time);
        }
    } else {
        find = findEntryPoint(idx);
        if (find == 0) return 0;
        else {
            tmp = logmatcher->getKernelLog(find);
            cout << kl_ptr->getTime().toStdString() << " - " << tmp->getTime().toStdString() << endl;

            ex_time = kl_ptr->getTimeF();
            en_time = tmp->getTimeF();
            return (ex_time - en_time);
        }
    }

    return 0;
}

qreal TimeAnalysis::pktProcessingTime(quint64 &start, quint64 &end)
{
    /*
     *elapsed time = the first entry function time - the last exit function time
     */
    quint64 find;
    KernelLog * tmp;
    KernelLog * kl_ptr;
    qreal en_time, ex_time;

    //first of all, find the start's entry time,
    //if the start is a entry function, then skip the step
    kl_ptr = logmatcher->getKernelLog(start);
    if (kl_ptr->getType() == 0x02) {
        find = findEntryPoint(start);
        if (find == 0) return 0;
        tmp = logmatcher->getKernelLog(find);
        en_time = tmp->getTimeF();
        cout << tmp->getTime().toStdString() << " - ";
    } else {
        en_time = kl_ptr->getTimeF();
        cout << kl_ptr->getTime().toStdString() << " - ";
    }

    kl_ptr = logmatcher->getKernelLog(end);
    if (kl_ptr->getType() == 0x01) {
        find = findExitPoint(end);
        if (find == 0) return 0;
        tmp = logmatcher->getKernelLog(find);
        ex_time = tmp->getTimeF();
        cout << tmp->getTime().toStdString() << endl;
    } else {
        ex_time = kl_ptr->getTimeF();
        cout << kl_ptr->getTime().toStdString() << endl;
    }

    cout << "Processing Time: " << (ex_time - en_time) << endl;
    return (ex_time - en_time);
}

void TimeAnalysis::funcProcTime()
{
    qDebug() << "[Time Analysis] func prcessing time calculate start!";

    KernelLog * tmp;
    KernelLog * kl_ptr;
    quint64 find;    
    qreal en_time, ex_time;

    kernel_size = logmatcher->getKernelLogSize();
    entryFuncProcTime = new qreal[kernel_size];
    memset(entryFuncProcTime, 0, kernel_size);

    QProgressDialog progress("Calculating kernel function processing time...", "Cancel", 0, kernel_size, parent);
    progress.setWindowModality(Qt::WindowModal);
    int j = 0;
    int deltCnt = kernel_size / 10;
    for (quint64 k = 0; k < kernel_size; k++)
    {
        j++;
        if (j == deltCnt) {
            progress.setValue(k);
            j = 0;
        }

        kl_ptr = logmatcher->getKernelLog(k);
        if (kl_ptr->getType() == 0x01) {
            find = findExitPoint(k);
            if (find == 0) entryFuncProcTime[k] = 0.0;
            else {
                tmp = logmatcher->getKernelLog(find);
                en_time = kl_ptr->getTimeF();
                ex_time = tmp->getTimeF();
                entryFuncProcTime[k] = ex_time - en_time;
            }
        }
    }

    cout << "[Time Analysis] func prcessing time calculate finished." << endl;
    cout << "[Time Analysis] start saving processing time log..." << endl;

    QFile timedata("func_proc_time.log");
    timedata.open(QFile::WriteOnly);
    QTextStream out(&timedata);
    out << QString::number(kernel_size) << endl;

    for (quint64 k = 0; k < kernel_size; k++)
    {
        if (entryFuncProcTime[k] != 0)
            out << QString::number(k) << " " << QString::number(entryFuncProcTime[k]) << endl;
    }

    out.flush();
    timedata.close();

    cout << "[Time Analysis] finish saving processing time log!!!" << endl;
}

void TimeAnalysis::Load_FuncProcTime_Log(QString file)
{
    ifstream in(file.toStdString().c_str());
    //quint64 kernel_size;
    quint64 idx;
    qreal proctime;

    in >> kernel_size;
    //cout << kernel_size << endl;

    entryFuncProcTime = new qreal[kernel_size];
    memset(entryFuncProcTime, 0, kernel_size);

    quint64 i = 0;
    qDebug() << "[Time Analysis] start loading Function Proc. Time Log.";
    while (!in.eof()) {
        i++;
        in >> idx >> proctime;
        if (in.fail()) {
            cout << "[Time Analysis] Read func_proc_time.log failed.:" << i << endl;
            break;
        }

        entryFuncProcTime[idx] = proctime;
    }

    in.close();
    //printf("60th: %.12f\n", entryFuncProcTime[59]);
    //fflush(stdout);
}

void TimeAnalysis::kernelTimeFilterGo()
{
    int tmp = (int)kernel_size;
    if (tmp < 0) {
        qDebug("pkt_counter to int failed\n");
        return;
    }

    if(kernelTime_model->rowCount(QModelIndex()) != 0)
        removeKernelTimeEntry();

    KernelLog * kl_ptr;
    qreal time_bound = kernelTimeFilterText.toDouble();
    unsigned int count = 0;    

    switch(kernelTimeFilterIndex) {
    case 0:
        // more than
        cout << "[Time Analysis] start filtering, time lower bound: " << time_bound << endl;
        for(int idx = (int)kernel_size - 1; idx >= 0; --idx)
        {
            if (entryFuncProcTime[idx] >= time_bound) {
                count++;
                kernelTime_model->insertRow(0);
                kernelTime_model->setData(kernelTime_model->index(0, 0), idx + 1);
                kernelTime_model->setData(kernelTime_model->index(0, 1), entryFuncProcTime[idx]);

                if (logmatcher->getKernelLogSize() != 0) {
                    kl_ptr = logmatcher->getKernelLog(idx);
                    kernelTime_model->setData(kernelTime_model->index(0, 2), kl_ptr->getFunction());
                    kernelTime_model->setData(kernelTime_model->index(0, 3), kl_ptr->getCaller());
                }
            }
        }

        if (count == 0) {
            QMessageBox::warning(parent, tr("Time Analyzer"),
                                 tr("Time Bound is too big. No record found. Set a smaller one."), QMessageBox::Close);
        }
        break;

    case 1:
        // less than
        cout << "[Time Analysis] start filtering, time upper bound: " << time_bound << endl;
        for(int idx = (int)kernel_size - 1; idx >= 0; --idx)
        {
            if (entryFuncProcTime[idx] <= time_bound && entryFuncProcTime[idx] != 0) {
                count++;
                kernelTime_model->insertRow(0);
                kernelTime_model->setData(kernelTime_model->index(0, 0), idx + 1);
                kernelTime_model->setData(kernelTime_model->index(0, 1), entryFuncProcTime[idx]);

                if (logmatcher->getKernelLogSize() != 0) {
                    kl_ptr = logmatcher->getKernelLog(idx);
                    kernelTime_model->setData(kernelTime_model->index(0, 2), kl_ptr->getFunction());
                    kernelTime_model->setData(kernelTime_model->index(0, 3), kl_ptr->getCaller());
                }
                cout << "found " << idx << endl;
            }
        }

        if (count == 0) {
            QMessageBox::warning(parent, tr("Time Analyzer"),
                                 tr("Time Bound is too small. No record found. Set a bigger one."), QMessageBox::Close);
        }
        break;

    default:
        break;
    }
}

qreal TimeAnalysis::getL2HDdelay()
{   
    int retry_idx = logmatcher->retry_idx;
    int finish;

    qreal s_time;
    qreal f_time;

    struct timeval reTry_ts_val = logmatcher->getSnifferTime(retry_idx);
    struct tm * reTry_ts;
    reTry_ts = localtime(&reTry_ts_val.tv_sec);

    for (int i = 0; i < (int)logmatcher->getEventSize(); i++) {
        if (logmatcher->getEvent(i).contains("LINK_DOWN"))
            finish = i;
    }

    s_time = (qreal)reTry_ts->tm_min * 60 + (qreal)reTry_ts->tm_sec + (qreal)reTry_ts_val.tv_usec / 1000000;
    f_time = logmatcher->getEventTime(finish);// - DEVIATION;

    //cout << "[Time Analyzer] L2H detection delay: " << f_time - s_time << endl;
    return (f_time - s_time);
}

qreal TimeAnalysis::getProbDelay()
{
    int start;
    int probe_resp_idx = logmatcher->probeResp_idx;

    qreal s_time;
    qreal f_time;

    for (int i = 0; i < (int)logmatcher->getEventSize(); i++) {
        if (logmatcher->getEvent(i).contains("LINK_DOWN"))
            start = i;
    }

    struct timeval probeResp_ts_val = logmatcher->getSnifferTime(probe_resp_idx);
    struct tm * probeResp_ts;
    probeResp_ts = localtime(&probeResp_ts_val.tv_sec);

    s_time = logmatcher->getEventTime(start);// - DEVIATION;
    f_time = (qreal)probeResp_ts->tm_min * 60 + (qreal)probeResp_ts->tm_sec + (qreal)probeResp_ts_val.tv_usec / 1000000;

    //cout << "[Time Analyzer] probing delay: " << f_time - s_time << endl;
    return (f_time - s_time);
}

qreal TimeAnalysis::getAuthDelay()
{
    int probe_resp_idx = logmatcher->probeResp_idx;
    int auth_resp_idx = logmatcher->authResp_idx;

    qreal s_time;
    qreal f_time;

    struct timeval probeResp_ts_val = logmatcher->getSnifferTime(probe_resp_idx);
    struct timeval authResp_ts_val = logmatcher->getSnifferTime(auth_resp_idx);

    struct tm * tmp = localtime(&probeResp_ts_val.tv_sec);
    struct tm probeResp_ts = * tmp;
    struct tm * authResp_ts;
    authResp_ts = localtime(&authResp_ts_val.tv_sec);

    s_time = (qreal)probeResp_ts.tm_min * 60 + (qreal)probeResp_ts.tm_sec + (qreal)probeResp_ts_val.tv_usec / 1000000;
    f_time = (qreal)authResp_ts->tm_min * 60 + (qreal)authResp_ts->tm_sec + (qreal)authResp_ts_val.tv_usec / 1000000;

    /*printf("start: %d:%02d:%02d.%06ld \n",
                   probeResp_ts.tm_hour, probeResp_ts.tm_min, probeResp_ts.tm_sec, probeResp_ts_val.tv_usec);
    printf("finish: %d:%02d:%02d.%06ld \n",
                   authResp_ts->tm_hour, authResp_ts->tm_min, authResp_ts->tm_sec, authResp_ts_val.tv_usec);*/

    //cout << "[Time Analyzer] authentication delay: " << f_time - s_time << endl;
    return (f_time - s_time);
}

qreal TimeAnalysis::getAssoDelay()
{
    int auth_resp_idx = logmatcher->authResp_idx;
    int asso_resp_idx = logmatcher->assoResp_idx;

    qreal s_time;
    qreal f_time;

    struct timeval authResp_ts_val = logmatcher->getSnifferTime(auth_resp_idx);
    struct timeval assoResp_ts_val = logmatcher->getSnifferTime(asso_resp_idx);

    struct tm * tmp = localtime(&authResp_ts_val.tv_sec);
    struct tm authResp_ts = * tmp;
    struct tm * assoResp_ts;
    assoResp_ts = localtime(&assoResp_ts_val.tv_sec);

    s_time = (qreal)authResp_ts.tm_min * 60 + (qreal)authResp_ts.tm_sec + (qreal)authResp_ts_val.tv_usec / 1000000;
    f_time = (qreal)assoResp_ts->tm_min * 60 + (qreal)assoResp_ts->tm_sec + (qreal)assoResp_ts_val.tv_usec / 1000000;

    /*printf("start: %d:%02d:%02d.%06ld \n",
                   authResp_ts.tm_hour, authResp_ts.tm_min, authResp_ts.tm_sec, authResp_ts_val.tv_usec);
    printf("finish: %d:%02d:%02d.%06ld \n",
                   assoResp_ts->tm_hour, assoResp_ts->tm_min, assoResp_ts->tm_sec, assoResp_ts_val.tv_usec);*/

    //cout << "[Time Analyzer] association delay: " << f_time - s_time << endl;
    return (f_time - s_time);
}

qreal TimeAnalysis::getL3HDdelay()
{
    int asso_resp_idx = logmatcher->assoResp_idx;
    int finish;

    qreal s_time;
    qreal f_time;

    struct timeval assoResp_ts_val = logmatcher->getSnifferTime(asso_resp_idx);
    struct tm * assoResp_ts;
    assoResp_ts = localtime(&assoResp_ts_val.tv_sec);

    for (int i = 0; i < (int)logmatcher->getEventSize(); i++) {
        if (logmatcher->getEvent(i).contains("DHCPDISCOVER"))
            finish = i;
    }

    s_time = (qreal)assoResp_ts->tm_min * 60 + (qreal)assoResp_ts->tm_sec + (qreal)assoResp_ts_val.tv_usec / 1000000;
    f_time = logmatcher->getEventTime(finish);// - DEVIATION;

    //cout << "[Time Analyzer] L3H detection delay: " << f_time - s_time << endl;
    fflush(stdout);

    return (f_time - s_time);
}

qreal TimeAnalysis::getDHCPdelay()
{
    // calculate the dhcp delay time
    int start;
    int finish;

    qreal s_time;
    qreal f_time;

    for (int i = 0; i < (int)logmatcher->getEventSize(); i++) {
        if (logmatcher->getEvent(i).contains("DHCPDISCOVER"))
            start = i;

        if (logmatcher->getEvent(i).contains("DHCPACK"))
            finish = i;
    }

    s_time = logmatcher->getEventTime(start);
    f_time = logmatcher->getEventTime(finish);

    //cout << "[Time Analyzer] dhcp delay: " << f_time - s_time << endl;
    return (f_time - s_time);
}

qreal TimeAnalysis::getIPCHdelay()
{
    // calculate the dhcp delay time
    int start;
    int finish;

    qreal s_time;
    qreal f_time;

    for (int i = 0; i < (int)logmatcher->getEventSize(); i++) {
        if (logmatcher->getEvent(i).contains("DHCPACK"))
            start = i;

        if (logmatcher->getEvent(i).contains("IP_CHANGE"))
            finish = i;
    }

    s_time = logmatcher->getEventTime(start);
    f_time = logmatcher->getEventTime(finish);

    //cout << "[Time Analyzer] dhcp delay: " << f_time - s_time << endl;
    return (f_time - s_time);
}

qreal TimeAnalysis::getL2Hdelay()
{
    //int reasso_idx = logmatcher->reAssoReq_idx;
    int retry_idx = logmatcher->retry_idx;
    int asso_resp_idx = logmatcher->assoResp_idx;

    qreal s_time;
    qreal f_time;

    //struct timeval reAsso_ts_val = logmatcher->getSnifferTime(reasso_idx);
    struct timeval reTry_ts_val = logmatcher->getSnifferTime(retry_idx);
    struct timeval assoResp_ts_val = logmatcher->getSnifferTime(asso_resp_idx);

    //struct tm * tmp = localtime(&reAsso_ts_val.tv_sec);
    //struct tm reAsso_ts = * tmp;
    struct tm * tmp = localtime(&reTry_ts_val.tv_sec);
    struct tm reTry_ts = * tmp;
    struct tm * assoResp_ts;
    assoResp_ts = localtime(&assoResp_ts_val.tv_sec);

    //s_time = (qreal)reAsso_ts.tm_min * 60 + (qreal)reAsso_ts.tm_sec + (qreal)reAsso_ts_val.tv_usec / 1000000;
    s_time = (qreal)reTry_ts.tm_min * 60 + (qreal)reTry_ts.tm_sec + (qreal)reTry_ts_val.tv_usec / 1000000;
    f_time = (qreal)assoResp_ts->tm_min * 60 + (qreal)assoResp_ts->tm_sec + (qreal)assoResp_ts_val.tv_usec / 1000000;

    //cout << "[Time Analyzer] L2H delay: " << f_time - s_time << endl;
    return (f_time - s_time);
}

qreal TimeAnalysis::getL3Hdelay()
{
    int asso_resp_idx = logmatcher->assoResp_idx;
    int finish;

    qreal s_time;
    qreal f_time;

    struct timeval assoResp_ts_val = logmatcher->getSnifferTime(asso_resp_idx);
    struct tm * assoResp_ts;
    assoResp_ts = localtime(&assoResp_ts_val.tv_sec);

    for (int i = 0; i < (int)logmatcher->getEventSize(); i++) {
        if (logmatcher->getEvent(i).contains("IP_CHANGE"))
            finish = i;
    }

    s_time = (qreal)assoResp_ts->tm_min * 60 + (qreal)assoResp_ts->tm_sec + (qreal)assoResp_ts_val.tv_usec / 1000000;
    f_time = logmatcher->getEventTime(finish);// - DEVIATION;

    //cout << "[Time Analyzer] L3H delay: " << f_time - s_time << endl;
    return (f_time - s_time);
}

qreal TimeAnalysis::getHandoffDelay()
{
    //int reasso_idx = logmatcher->reAssoReq_idx;
    int retry_idx = logmatcher->retry_idx;
    int finish;

    qreal s_time;
    qreal f_time;

    //struct timeval reAsso_ts_val = logmatcher->getSnifferTime(reasso_idx);
    //struct tm * reAsso_ts;
    //reAsso_ts = localtime(&reAsso_ts_val.tv_sec);

    struct timeval reTry_ts_val = logmatcher->getSnifferTime(retry_idx);
    struct tm * reTry_ts;
    reTry_ts = localtime(&reTry_ts_val.tv_sec);

    for (int i = 0; i < (int)logmatcher->getEventSize(); i++) {
        if (logmatcher->getEvent(i).contains("IP_CHANGE"))
            finish = i;
    }

    //s_time = (qreal)reAsso_ts->tm_min * 60 + (qreal)reAsso_ts->tm_sec + (qreal)reAsso_ts_val.tv_usec / 1000000;
    s_time = (qreal)reTry_ts->tm_min * 60 + (qreal)reTry_ts->tm_sec + (qreal)reTry_ts_val.tv_usec / 1000000;
    f_time = logmatcher->getEventTime(finish);// - DEVIATION;

    //cout << "[Time Analyzer] Handoff delay: " << f_time - s_time << endl;
    return (f_time - s_time);
}
