#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(char *sym_table) :
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // before loading the sniffer log, we can't show it
    ui->actionShowAllPacket->setEnabled(false);
    // before loading the sniffer log, we can't load kernel log or filter it
    ui->actionOpenKernelLog->setEnabled(false);
    ui->actionFindKernelPacket->setEnabled(false);

    log = new LogMatcher(this);
    timeAnalyzer = new TimeAnalysis(this);
    callAnalyzer = new CallProcedure(this);
    hoAnalyzer = new ZoomWidget;
    cout << "sniffer size: " << log->getSnifferLogSize() <<
            ", kernel size: " << log->getKernelLogSize() <<
            ", event size: " << log->getEventSize() << endl;

    timeAnalyzer->setLogMatcher(log);
    callAnalyzer->setLogMatcher(log);
    callAnalyzer->setTimeAnalyzer(timeAnalyzer);
    hoAnalyzer->setLogMatcher(log);
    hoAnalyzer->setTimeAnalyzer(timeAnalyzer);
    /*render = new RenderArea;
    render->setTimeAnalyzer(timeAnalyzer);
    renderScroll = new QScrollBar;
    renderScroll->setFocusPolicy(Qt::StrongFocus);*/

    createTips();
    createLabelAndFilter();
    createConn(); // connection have to be writed after ui->setupUI()!!!  

    getSymTable(sym_table);
    readSymTable();

    QLabel * macAddrLabel = new QLabel(tr("MN's MAC Address: "));
    QLineEdit * macAddrLineEdit = new QLineEdit(tr("00:02:8A:BA:AD:75"));
    ui->toolBar->addWidget(macAddrLabel);
    ui->toolBar->addWidget(macAddrLineEdit);

    QWidget * topFiller = new QWidget;
    topFiller->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    QLabel * descriptionLabel = new QLabel(tr("Network Behavior Analyzer: "
                                              "\nPlease Load the Sniffer, Kernel, and Event logs to start the analysis."));
    descriptionLabel->setFrameStyle(QFrame::StyledPanel | QFrame::Sunken);
    descriptionLabel->setAlignment(Qt::AlignCenter);

    QWidget * bottomFiller = new QWidget;
    bottomFiller->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    QVBoxLayout * mainLayout = new QVBoxLayout;
    mainLayout->setMargin(5);
    mainLayout->addWidget(topFiller);
    mainLayout->addWidget(descriptionLabel);
    mainLayout->addWidget(bottomFiller);
    ui->centralWidget->setLayout(mainLayout);
//    ReadBoth();
//    ReadSniffer();
}

void MainWindow::ReadSniffer()
{
    QString file = "/home/winlab/DataBase/ex110125/2/0125";
    log->Load_Sniffer_Data(file, this);
    log->add_sniffer_data();
    log->setSnifferModel();
    ui->actionShowAllPacket->setEnabled(true);
    ui->actionOpenKernelLog->setEnabled(true);    
    createSnifferDock();
    hoAnalyzer->updateTime();
}

void MainWindow::ReadBoth()
{
//    QString file1 = "/home/winlab/DataBase/ex101129/iperf_test_1129";
//    QString file2 = "/home/winlab/DataBase/ex101129/iperf_test_1129.out";
    QString file1 = "/home/winlab/DataBase/ex110125/2/0125";
    QString file2 = "/home/winlab/DataBase/ex110125/2/0125.out";
    log->Load_Sniffer_Data(file1, this);
    log->add_sniffer_data();
    log->setSnifferModel();
    log->Load_Kernel_Data(file2, this);
    ui->actionOpenKernelLog->setEnabled(true);
    ui->actionShowAllPacket->setEnabled(true);
    ui->actionFindKernelPacket->setEnabled(true);
    createSnifferDock();
    createKernelDock();
    hoAnalyzer->updateTime();
}

void MainWindow::createTips()
{
    ui->actionOpenSnifferLog->setStatusTip(tr("Open Sniffer log file"));
    ui->actionOpenKernelLog->setStatusTip(tr("Open Kernel log file"));
    ui->actionOpenEventLog->setStatusTip(tr("Open Event log file"));
    ui->actionExit->setStatusTip(tr("Exit Analyzer"));
    ui->actionAbout_Analyzer->setStatusTip(tr("About Analyzer"));
    ui->actionShowAllPacket->setStatusTip(tr("Show All Packets"));
    ui->actionFindKernelPacket->setStatusTip("Find Packets that mapping to Kernel Logs");
    ui->actionHoAnalysis->setStatusTip(tr("Perform Handover Procedure Analysis"));
    ui->actionFuncTimeAnalysis->setStatusTip(tr("Perform Kernel funciton processing time analysis"));
}

void MainWindow::createLabelAndFilter()
{
    filterPatternLineEdit = new QLineEdit;
    filterPatternLabel = new QLabel(tr("Filter:"));
    filterPatternLabel->setBuddy(filterPatternLineEdit);
    filterSyntaxComboBox = new QComboBox;
    filterSyntaxComboBox->addItem(tr("IP source address"));
    filterSyntaxComboBox->addItem(tr("IP destination address"));
    filterSyntaxComboBox->addItem(tr("Protocol"));
    filterSyntaxComboBox->addItem(tr("No."));

    kernelFilterSyntaxComboBox = new QComboBox;
    kernelFilterSyntaxComboBox->addItem(tr("Callee"));
    kernelFilterSyntaxComboBox->addItem(tr("Caller"));;
    kernelFilterPatternLineEdit = new QLineEdit;
    kernelFilterGoSearchButton = new QPushButton(tr("Go"));

    kernelTimePatternComboBox = new QComboBox;
    kernelTimePatternComboBox->addItem(tr("more than"));
    kernelTimePatternComboBox->addItem(tr("less than"));
    kernelTimePatternLineEdit = new QLineEdit;
    kernelTimeFilterGoSearchButton = new QPushButton(tr("Go"));
}

void MainWindow::createConn()
{
    // Handle Log data
    connect(log->sourceView, SIGNAL(clicked(const QModelIndex &)), log, SLOT(showIndex(const QModelIndex &)));
    connect(log->sourceView, SIGNAL(doubleClicked(const QModelIndex &)), callAnalyzer, SLOT(showPopupMenu(const QModelIndex &)));
    connect(log->kernelView, SIGNAL(clicked(const QModelIndex &)), log, SLOT(showKernelIndex(const QModelIndex &)));
    connect(log->eventView, SIGNAL(clicked(const QModelIndex &)), log, SLOT(showEventTime(const QModelIndex &)));
    connect(log->dhcpView, SIGNAL(clicked(const QModelIndex &)), log, SLOT(showDhcpTime(const QModelIndex &)));

    connect(log, SIGNAL(changeSnifferBox(int)), filterSyntaxComboBox, SLOT(setCurrentIndex(int)));
    connect(log, SIGNAL(changeSnifferText(const QString &)), filterPatternLineEdit, SLOT(setText(const QString &)));

    connect(filterPatternLineEdit, SIGNAL(textChanged(const QString &)), log, SLOT(textFilterChanged(const QString &)));
    connect(filterSyntaxComboBox, SIGNAL(currentIndexChanged(int)), log, SLOT(ComboBoxIndexChanged(int)));

    connect(kernelFilterSyntaxComboBox, SIGNAL(currentIndexChanged(int)), log, SLOT(kernelComboBoxIndexChanged(int)));
    connect(kernelFilterPatternLineEdit, SIGNAL(textChanged(const QString &)), log, SLOT(kernelTextFilterChanged(const QString &)));
    connect(kernelFilterGoSearchButton, SIGNAL(clicked()), log, SLOT(kernelFilterGo()));

    connect(kernelTimePatternComboBox, SIGNAL(currentIndexChanged(int)), timeAnalyzer, SLOT(kernelTimeComboBoxIndexChanged(int)));
    connect(kernelTimePatternLineEdit, SIGNAL(textChanged(const QString &)), timeAnalyzer, SLOT(kernelTimeTextFilterChanged(const QString &)));
    connect(kernelTimeFilterGoSearchButton, SIGNAL(clicked()), timeAnalyzer, SLOT(kernelTimeFilterGo()));

    // ui's action
    connect(ui->actionOpenSnifferLog, SIGNAL(triggered()), this, SLOT(Read_Sniffer_Log()));
    connect(ui->actionOpenKernelLog, SIGNAL(triggered()), this, SLOT(Read_Kernel_Log()));
    connect(ui->actionOpenEventLog, SIGNAL(triggered()), this, SLOT(Read_Event_Log()));
    connect(ui->actionAbout_Analyzer, SIGNAL(triggered()), this, SLOT(aboutMe()));
    connect(ui->actionFindKernelPacket, SIGNAL(triggered()), this, SLOT(showKernelPacket()));
    connect(ui->actionShowAllPacket, SIGNAL(triggered()), this, SLOT(showAllPacket()));
    connect(ui->actionHoAnalysis, SIGNAL(triggered()), this, SLOT(showHoAnalysis()));
    connect(ui->actionFuncTimeAnalysis, SIGNAL(triggered()), this, SLOT(showKernelFuncTime()));
    //connect(renderScroll, SIGNAL(valueChanged(int)), render, SLOT(setValue(int)));
}

void MainWindow::createSnifferDock()
{
    dockwindow = new QDockWidget(tr("Sniffer Log"), this);
    QWidget * snifferWidget = new QWidget();
    QGridLayout * snifferlayout = new QGridLayout;
    snifferlayout->addWidget(filterPatternLabel, 0, 0);
    snifferlayout->addWidget(filterPatternLineEdit, 0, 1);
    snifferlayout->addWidget(filterSyntaxComboBox, 0, 2);
    snifferlayout->addWidget(log->sourceView, 1, 0, 1, 3);
    snifferWidget->setLayout(snifferlayout);
    dockwindow->setWidget(snifferWidget);
    addDockWidget(Qt::LeftDockWidgetArea, dockwindow);
    ui->menuView->addAction(dockwindow->toggleViewAction());
    setCentralWidget(dockwindow);
}

void MainWindow::createKernelDock()
{
    dockwindow = new QDockWidget(tr("Kernel Log"), this);
    QWidget * kernelWidget = new QWidget();
    QGridLayout * kernelLayout = new QGridLayout;
    kernelLayout->addWidget(kernelFilterSyntaxComboBox, 0, 0);
    kernelLayout->addWidget(kernelFilterPatternLineEdit, 0, 1);
    kernelLayout->addWidget(kernelFilterGoSearchButton, 0, 2);
    kernelLayout->addWidget(log->kernelView, 1, 0, 1, 3);
    kernelWidget->setLayout(kernelLayout);
    dockwindow->setWidget(kernelWidget);
    addDockWidget(Qt::RightDockWidgetArea, dockwindow);
    ui->menuView->addAction(dockwindow->toggleViewAction());
}

void MainWindow::createKernelTimeDock()
{
    dockwindow = new QDockWidget(tr("Function Processing Time Log"), this);
    QWidget * kernelTimeWidget = new QWidget();
    QGridLayout * kernelTimeLayout = new QGridLayout;
    kernelTimeLayout->addWidget(kernelTimePatternComboBox, 0, 0);
    kernelTimeLayout->addWidget(kernelTimePatternLineEdit, 0, 1);
    kernelTimeLayout->addWidget(kernelTimeFilterGoSearchButton, 0, 2);
    kernelTimeLayout->addWidget(timeAnalyzer->kernelTimeSortView, 1, 0, 1, 3);
    kernelTimeWidget->setLayout(kernelTimeLayout);
    dockwindow->setWidget(kernelTimeWidget);
    addDockWidget(Qt::BottomDockWidgetArea, dockwindow);
    ui->menuView->addAction(dockwindow->toggleViewAction());
}

void MainWindow::createEventDock()
{
    dockwindow = new QDockWidget(tr("Event and DHCP Log"), this);
    QWidget * eventWidget = new QWidget();
    QGroupBox * eventGroupBox = new QGroupBox(tr("Event Log"));
    QGroupBox * dhcpGroupBox = new QGroupBox(tr("DHCP Log"));

    QHBoxLayout * eventLayout = new QHBoxLayout;
    eventLayout->addWidget(log->eventView);
    eventGroupBox->setLayout(eventLayout);

    QHBoxLayout * dhcpLayout = new QHBoxLayout;
    dhcpLayout->addWidget(log->dhcpView);
    dhcpGroupBox->setLayout(dhcpLayout);


    QVBoxLayout * mainLayout = new QVBoxLayout;
    mainLayout->addWidget(eventGroupBox);
    mainLayout->addWidget(dhcpGroupBox);
    eventWidget->setLayout(mainLayout);
    dockwindow->setWidget(eventWidget);
    addDockWidget(Qt::RightDockWidgetArea, dockwindow);
    ui->menuView->addAction(dockwindow->toggleViewAction());
}

QString MainWindow::Read_Log()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open DirectorDataBasey"),
                                                    "/home/winlab/DataBase");
    if (!fileName.isEmpty())
        return fileName;
    else
        return NULL;
}

void MainWindow::Read_Sniffer_Log()
{
    QString filename;
    filename = Read_Log();
    if(filename == NULL) {
        qDebug() << "Read_Sniffer_Log: Read Null File";
        return;
    }

    log->Load_Sniffer_Data(filename, this);
    log->add_sniffer_data();
    log->setSnifferModel();

    /*renderScroll->setMinimum(0);
    renderScroll->setMaximum(log->getSnifferLogSize() - 10);
    render->setMaximum(log->getSnifferLogSize());
    render->update();*/
    // update actions, after load the sniffer log,
    // then can we load the kernel log and filter sniffer log.    
    ui->actionOpenKernelLog->setEnabled(true);
    ui->actionShowAllPacket->setEnabled(true);
    createSnifferDock();
    hoAnalyzer->updateTime();
}

void MainWindow::Read_Kernel_Log()
{
    QString filename;
    filename = Read_Log();
    if(filename == NULL) {
        qDebug() << "Read_Kernel_Log: Read Null File";
        return;
    }

    log->Load_Kernel_Data(filename, this);
    //add_Kernel_data();
    ui->actionFindKernelPacket->setEnabled(true);
    createKernelDock();
}

void MainWindow::Read_Event_Log()
{
    QString filename;
    filename = Read_Log();
    if(filename == NULL) {
        qDebug() << "Read_Event_Log: Read Null File";
        return;
    }

    log->Load_Event_Data(filename, this);
    log->add_event_data();
    createEventDock();
    hoAnalyzer->updateTime();
}

void MainWindow::Read_FuncProcTime_Log()
{
    if (timeAnalyzer->readFuncProcTimeLogFlag) {

        QString filename;
        filename = Read_Log();
        if(filename == NULL) {
            qDebug() << "Read_FuncProcTime_Log: Read Null File";
            return;
        }

        timeAnalyzer->Load_FuncProcTime_Log(filename);
        timeAnalyzer->setKernelTimeModel();

    } else {

        if (log->getKernelLogSize() == 0) {
            QMessageBox::warning(this, tr("Analyzer"),
                                 tr("Please Load Kernel Log before doing this! ok!?"), QMessageBox::Close);
            return;
        } else {
            timeAnalyzer->funcProcTime();
            timeAnalyzer->setKernelTimeModel();
        }

    }

    createKernelTimeDock();
}

void MainWindow::showKernelFuncTime()
{
    QFrame * popup = new QFrame(this, Qt::Popup | Qt::Dialog );

    QLabel * instruction = new QLabel(tr("Calculating The function processing time of Kernel log\n"
                                         "is a time-comsuming job. If You did this before, please\n"
                                         "read from the exist log."));

    QGroupBox * groupBox = new QGroupBox(tr("Make a choice"));

    QRadioButton * readFromLog;
    QRadioButton * calculate;
    readFromLog = new QRadioButton(tr("&Read kernel function processing time from exist file"));
    calculate = new QRadioButton(tr("&Calculate kernel function processing time from kernel log and save the data"));

    readFromLog->setChecked(true);
    connect(readFromLog, SIGNAL(toggled(bool)), timeAnalyzer, SLOT(checkReadOrCal(bool)));
    timeAnalyzer->readFuncProcTimeLogFlag = 1;

    QVBoxLayout * groupBoxLayout = new QVBoxLayout;
    groupBoxLayout->addWidget(readFromLog);
    groupBoxLayout->addWidget(calculate);
    groupBox->setLayout(groupBoxLayout);

    QDialogButtonBox * buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    connect(buttonBox, SIGNAL(accepted()), popup, SLOT(close()));
    connect(buttonBox, SIGNAL(accepted()), this, SLOT(Read_FuncProcTime_Log()));
    connect(buttonBox, SIGNAL(rejected()), popup, SLOT(close()));

    QVBoxLayout * layout = new QVBoxLayout;
    layout->addWidget(instruction);
    layout->addWidget(groupBox);
    layout->addWidget(buttonBox);
    popup->setLayout(layout);
    popup->setWindowTitle("Handle function processing time");
    popup->show();
}

void MainWindow::showHoAnalysis()
{
    hoAnalyzer->show();
}

void MainWindow::aboutMe()
{
    QFrame * popup = new QFrame(this, Qt::Popup | Qt::Dialog );

    QLabel * toolNameLable = new QLabel(tr("Network Behavior Analyzer\n"));
    QLabel * descriptionLabel = new QLabel(tr("Copyright WinLab corporation. All rights are reserved.\n"));
    QLabel * designerLable = new QLabel(tr("This Tool is Designed By Gabriel Yu.\n"
                                         "Please Contact: esa721@hotmail.com"));

    QPushButton * addButton = new QPushButton(tr("Close"));
    connect(addButton, SIGNAL(clicked()), popup, SLOT(close()));

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(toolNameLable);
    mainLayout->addWidget(descriptionLabel);
    mainLayout->addWidget(designerLable);
    mainLayout->addWidget(addButton, 0, Qt::AlignCenter);

    popup->setLayout(mainLayout);
    popup->setWindowTitle("About Analyzer");
    popup->show();
}

MainWindow::~MainWindow()
{
    delete ui;
}
