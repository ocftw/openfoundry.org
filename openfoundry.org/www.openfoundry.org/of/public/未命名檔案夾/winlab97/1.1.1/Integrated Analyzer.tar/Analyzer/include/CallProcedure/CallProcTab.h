#ifndef CALLPROCTAB_H
#define CALLPROCTAB_H

#include <QTabWidget>
#include <QItemSelection>
#include <QTextEdit>
#include "CallGraph.h"

class CallProcTab : public QTabWidget
{
    Q_OBJECT

public:
    CallProcTab(QWidget *parent=0);
    void getProcString(QString str) { callprocTab->append(str); }
    void getGraphString(QString str) { callgraphTab->append(str); }
    void getGraphHash(const QString &caller, const QString &callee) { callgraph->doHashFunc(caller, callee); }
    void makingGraph(const QString &caller, const QString &callee) { callgraph->graphing(caller, callee); }
    void drawCallGraph() { callgraphTab->append( callgraph->drawGraph() ); }
    void getRoots() { callgraphTab->append( callgraph->showRoots() ); }
    void test(QString caller) { callgraph->test(caller); }

private:
    QTextEdit *callprocTab;
    QTextEdit *callgraphTab;
    CallGraph *callgraph;
};

#endif // CALLPROCTAB_H
