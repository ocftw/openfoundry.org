#include "LogMatcher.h"

u_int16_t seq_num = 0;
int count_same_seq = 1;

LogMatcher::LogMatcher(QWidget * parent)
{
    this->parent = parent;

    wired = 0;
    pkt_counter = 0;
    rcd_counter = 0;
    evt_counter = 0;
    radio_header_len = 0;
    retry_idx = -1;
    reAssoReq_idx = -1;
    probeResp_idx = -1;
    authResp_idx = -1;
    assoResp_idx = -1;
    kernelFilterIndex = 0;
    //cout << pkt_counter << " " << rcd_counter << " " << evt_counter << endl;

    proxyModel = new snifferSortFilter(this);
    proxyModel->setDynamicSortFilter(true);

    sourceView = new QTreeView;
    sourceView->setRootIsDecorated(false);
    sourceView->setAlternatingRowColors(true);
    sourceView->setSortingEnabled(true);
    sourceView->sortByColumn(0, Qt::AscendingOrder);

    kernelView = new QTreeView;
    kernelView->setRootIsDecorated(false);
    kernelView->setAlternatingRowColors(true);

    eventView = new QTreeView;
    eventView->setRootIsDecorated(false);
    eventView->setAlternatingRowColors(true);

    dhcpView = new QTreeView;
    dhcpView->setRootIsDecorated(false);
    dhcpView->setAlternatingRowColors(true);

    sniffer_model = createSnifferModel();
    kernel_model = createKernelModel();
    event_model = createEventModel();
    dhcp_model = createDhcpModel();

    sourceView->setModel(proxyModel);
    kernelView->setModel(kernel_model);
    eventView->setModel(event_model);
    dhcpView->setModel(dhcp_model);
}

QAbstractItemModel * LogMatcher::createSnifferModel()
{
    QStandardItemModel * model = new QStandardItemModel(0, 5, this);

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("No."));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Time"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Source"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Destination"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("Protocol"));

    return model;
}

QAbstractItemModel * LogMatcher::createKernelModel()
{
    QStandardItemModel * model = new QStandardItemModel(0, 4, this);

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("No."));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Time"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Function"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Caller"));

    return model;
}

QAbstractItemModel * LogMatcher::createEventModel()
{
    QStandardItemModel * model = new QStandardItemModel(0, 2, this);

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Time"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Event"));

    return model;
}

QAbstractItemModel * LogMatcher::createDhcpModel()
{
    QStandardItemModel * model = new QStandardItemModel(0, 2, this);

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Time"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("DHCP Message"));

    return model;
}

void LogMatcher::Load_Sniffer_Data(const QString &file, QWidget *parent)
{
    unsigned int pkt_counter = 0;   // packet counter

    //temporary packet buffers
    const u_char * pkt_ptr;
    struct pcap_pkthdr header;    // The header that pcap gives us

    //open the pcap file
    pcap_t *handle;
    char errbuf[PCAP_ERRBUF_SIZE]; //not sure what to do with this, oh well
    string tmp_filename = file.toStdString();
    handle = pcap_open_offline(tmp_filename.c_str(), errbuf);   //call pcap library function

    if (handle == NULL) {
        QMessageBox::warning(parent, tr("Analyzer"),
                             tr("pcap_open_offline() failed\n"), QMessageBox::Close);
        return;
    }

    // find out the datalink type of the connection
    switch (pcap_datalink(handle))
    {
    case DLT_EN10MB:
        qDebug("[Sniffer] data link type: Ethernet.");
        wired = 1;
        break;
    case DLT_PRISM_HEADER:
        qDebug("[Sniffer] data link type: WLAN-ng PRISM.");
        wired = 0;
        break;
    case DLT_IEEE802_11_RADIO_AVS:
        qDebug("[Sniffer] data link type: WLAN-ng PRISM AVS.");
        wired = 0;
        break;
    case DLT_IEEE802_11_RADIO:
        qDebug("[Sniffer] data link type: Radiotap.");
        wired = 0;
        break;
    default:
        qDebug("I don't support this interface type: %d!\n", pcap_datalink(handle));
        exit(1);
        break;
    }

    ///////////////////////////////////////////////////////////
    //Round 1, calculate the packet number of the sniffer log//
    ///////////////////////////////////////////////////////////
    while (pcap_next(handle, &header)) pkt_counter++; //increment number of packets seen
    pcap_close(handle);  //close the pcap file

    this->pkt_counter = pkt_counter;

    handle = pcap_open_offline(tmp_filename.c_str(), errbuf); // open again

    if (handle == NULL) {
        QMessageBox::warning(parent, tr("Analyzer"),
                             tr("pcap_open_offline():2 failed\n"), QMessageBox::Close);
        return;
    }

    packet = new u_char*[pkt_counter];
    pkt_ts = new struct timeval[pkt_counter];
    pkt_len = new unsigned int[pkt_counter];

    ///////////////////////////////////////////
    //Round 2, read the save file into memory//
    ///////////////////////////////////////////
    QProgressDialog progress("Loading sniffer data...", "Cancel", 0, pkt_counter, parent);
    progress.setWindowModality(Qt::WindowModal);
    progress.show();
    pkt_counter = 0;
    while ((pkt_ptr = pcap_next(handle, &header)) != NULL)
    {
        //show the progress of processing sniffer log data
        progress.setValue(pkt_counter);
        //header contains information about the packet (e.g. timestamp)
        pkt_ts[pkt_counter] = header.ts;
        pkt_len[pkt_counter] = header.len;
        u_char * tmp = (u_char *)pkt_ptr;
        packet[pkt_counter] = new u_char[header.len];
        memcpy(packet[pkt_counter], tmp, header.len * sizeof(u_char));
        pkt_counter++;
    } //end internal loop for reading packets (all in one file)
    progress.setValue(pkt_counter);

    pcap_close(handle);  //close the pcap file
    if (radio_header_len == 0) {
        struct ieee80211_radiotap_header * rptr = (struct ieee80211_radiotap_header *)(packet[0]);
        radio_header_len = rptr->it_len;
    }

    u_int count_ip = 0;
    //Do Hashing!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    if (wired) {
        for(unsigned int k = 0; k < pkt_counter; k++)
        {
            u_char * pkt_ptr = packet[k];
            struct ether_header * eptr;
            eptr = (struct ether_header *) pkt_ptr;

            if (ntohs(eptr->ether_type) == ETHERTYPE_IP)
            {
                struct my_ip *ip_hdr = (struct my_ip *)(pkt_ptr + sizeof(struct ether_header));
                u_int id_snifflog = ntohs(ip_hdr->ip_id);
                Key sniffer_key( id_snifflog, ip_hdr->ip_p,
                                 QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)));
                //cout << QString(inet_ntoa(ip_hdr->ip_src)).toStdString() << " " << QString(inet_ntoa(ip_hdr->ip_dst)).toStdString() << endl;
                count_ip++;
                //Do Kerenl Log to Sniffer Log Hash Function
                kernel2sniffer.insert(sniffer_key, k);
            }
        }
    } else {
        for(unsigned int k = 0; k < pkt_counter; k++)
        {
            u_char * pkt_ptr = packet[k];
            struct ieee80211_mac_header * eptr = (struct ieee80211_mac_header *)(pkt_ptr + radio_header_len);
            struct frame_control * control = (struct frame_control *) eptr->fc;
            //printf("[IEEE 802.11 Data]protocol: %d, type: %d, subtype: %d\n", control->protocol, control->type, control->subtype);

            if (control->protocol == 0 && control->type == 2)
            {
                struct llc_header * paket_llc;
                switch (control->subtype)
                {
                case 0:
                    paket_llc = (struct llc_header *)
                                (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE);
                    if (ntohs(paket_llc->ether_type) == ETHERTYPE_IP)
                    {
                        // org = 0 is a right encapsulated IP packet
                        if (paket_llc->org[0] != 0 || paket_llc->org[1] != 0 || paket_llc->org[2] != 0) break;

                        struct my_ip *ip_hdr = (struct my_ip *)
                                               (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE + LLC_HEADER_SIZE);
                        u_int id_snifflog = ntohs(ip_hdr->ip_id);
                        Key sniffer_key( id_snifflog, ip_hdr->ip_p,
                                         QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)));
                        kernel2sniffer.insert(sniffer_key, k);
                        count_ip++;
                    }
                    break;

                case 8:
                    // a QoS data + CF-Ack or a QoS (IP) packet!!!!!!!!!!!!!!!!
                    paket_llc = (struct llc_header *)
                                (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE);
                    if (ntohs(paket_llc->ether_type) == ETHERTYPE_IP)
                    {
                        struct my_ip *ip_hdr = (struct my_ip *)
                                               (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE + LLC_HEADER_SIZE);
                        u_int id_snifflog = ntohs(ip_hdr->ip_id);
                        Key sniffer_key( id_snifflog, ip_hdr->ip_p,
                                         QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)));
                        kernel2sniffer.insert(sniffer_key, k);
                        count_ip++;
                    }
                    break;

                default:
                    break;
                }
            }
        }
    }

    cout << "[Sniffer] Total: " << this->pkt_counter << ", ip amount: "
            << count_ip << ", kernel2sniffer size: " << kernel2sniffer.size() << endl;
    return;
}

void LogMatcher::add_sniffer_data()
{
    int tmp = (int)pkt_counter;
    if (tmp < 0) {
        qDebug("pkt_counter to int failed\n");
        return;
    }

    if(sniffer_model->rowCount(QModelIndex()) != 0)
        removeSnifferEntry();

    //bool check[pkt_counter];
    //memset(check, 0, pkt_counter);

    if (wired) {
        for(int i = (int)pkt_counter - 1; i >= 0; --i)
            add_sniffer_single_wired_data(i);
    } else {
        for(int i = (int)pkt_counter - 1; i >= 0; --i)
            add_sniffer_single_wireless_data(i);
    }

    cout << "[sniffer] retry: " << retry_idx + 1 << ", reAssoReq: " << reAssoReq_idx + 1 <<
            ", probeResp: " << probeResp_idx + 1 << ", authResp: " << authResp_idx + 1 <<
            ", assoResp: " << assoResp_idx + 1 << endl;
}

void LogMatcher::Load_Kernel_Data(const QString &file, QWidget *parent)
{
    quint64 i = 0; // The number of records in a log file
    int scope = 1;

    //The variables for open the kernel behavior log
    QFile log(file);
    log.open(QIODevice::ReadOnly);
    QDataStream in(&log);
    quint64 old_pos;

    //The variables for processing the KBL data
    quint8 type, tot_len, pkt_len, pkt_t;
    quint32 addr, func, caller, id_pkt;
    quint64 timestamp;
    int pkt_num, idx;
    QHostAddress dipv4, sipv4;
    quint16 id, mac_t;
    quint8 protocol;

    //bool match_idx[pkt_counter];
    match_idx = new bool[pkt_counter];
    memset(match_idx, false, pkt_counter);

    //////////////////////////////////////////////////////////////
    //Round 1, we have to check how many records in the log file//
    //////////////////////////////////////////////////////////////
    if (log.isSequential())
    {
        QMessageBox::warning(parent, tr("Analyzer"),
                             tr("LogMatcher::Load kernel data: file is Sequential."), QMessageBox::Close);
        exit(0);
    } else
    {
        old_pos = in.device()->pos();
        while (!in.atEnd())
        {
            in >> addr;
            if (addr == 0) continue;
            in >> addr >> type >> timestamp >> tot_len;
            pkt_len = tot_len - 18;
            while (pkt_len != 0)
            {
                in >> pkt_t >> id_pkt;
                pkt_len -= 5;
                if (pkt_t == 1 || pkt_t == 3)
                {
                    in >> addr >> addr >> id >> protocol;
                    pkt_len -= 11;
                }
                if (pkt_t == 2 || pkt_t == 3)
                {
                    in >> mac_t;
                    pkt_len -= 2;
                }
            }
            i++; //we found 1 record
        }

        if (in.device()->seek(old_pos) != true)
        {
            cout << "LogMatcher.cpp: seek old position failed" << endl;
            exit(0);
        }
    }

    rcd_counter = i;
    qDebug() << "[Kernel] Round 1, total:" << rcd_counter;

    //////////////////////////////////////////////////////////////////
    //Round 2, allocate the memory for every single records,        //
    //then parse the record field of log into Record Data Structure.//
    //////////////////////////////////////////////////////////////////
    QProgressDialog progress("Loading kernel data...", "Cancel", 0, rcd_counter, parent);
    progress.setWindowModality(Qt::WindowModal);
    progress.show();
    rcd = new KernelLog[rcd_counter];
    i = 0;
    int j = 0;
    int deltCnt = rcd_counter / 10; //devide the rcd_counter to 10 parts
    while (!in.atEnd())
    {
        j++;
        if (j == deltCnt) {
            //once reach every 10% of the kernel log data
            //we show the progression to avoiding slowdown problem
            progress.setValue(i);
            j = 0;
        }

        //***** ID of function
        in >> addr;
        if (addr == 0) continue;
        func = qToBigEndian(addr);        
        //***** ID of caller
        in >> addr;
        caller = qToBigEndian(addr);
        //***** Entry or Exit & Timestamp & Total length of KBL
        in >> type >> timestamp >> tot_len;
        rcd[i].getData(func, caller, type, timestamp, tot_len);

        //--------------------
        //The following is to calculate the number of footprint
        //of each record.
        pkt_num = 0;
        pkt_len = tot_len - 18;
        if (pkt_len != 0)
        {
            old_pos = in.device()->pos();
            while (pkt_len != 0)
            {
                in >> pkt_t >> id_pkt;
                pkt_len -= 5;

                if (pkt_t == 1 || pkt_t == 3)
                {
                    in >> addr >> addr >> id >> protocol;
                    pkt_len -= 11;
                }
                if (pkt_t == 2 || pkt_t == 3)
                {
                    in >> mac_t;
                    pkt_len -= 2;
                }
                pkt_num++;
            }

            if (in.device()->seek(old_pos) != true)
            {
                cout << "LogMatcher.cpp: seek old position failed" << endl;
                exit(0);
            }
            rcd[i].getPktNumAndIniFP(pkt_num);
        }
        else
            rcd[i].getPktNumAndIniFP(pkt_num);

        //--------------------
        //The following is to parse the footprint data
        idx = 0;//index of footprint
        pkt_len = tot_len - 18;
        while (pkt_len != 0)
        {
            //***** Which layer of the Packet & ID of Packet
            in >> pkt_t >> id_pkt;
            rcd[i].getPktID(idx, pkt_t, id_pkt);
            pkt_len -= 5;

            //***** IP Header
            if (pkt_t == 1 || pkt_t == 3)
            {
                in >> addr;
                dipv4.setAddress(addr);
                in >> addr;
                sipv4.setAddress(addr);
                in >> id >> protocol;
                rcd[i].getIPheader(idx, dipv4, sipv4, id, protocol);
                pkt_len -= 11;

                //insert the sniffer log to KBL mapping relation to hash table
                Key kernel_key(u_int(id), protocol, sipv4.toString(), dipv4.toString());
                QPair< quint64, quint32 > door(i, id_pkt);
                sniffer2kernel.insert(kernel_key, door);
            }

            //***** Type of MAC header
            if (pkt_t == 2 || pkt_t == 3)
            {
                in >> mac_t;
                rcd[i].getMacType(idx, mac_t);
                pkt_len -= 2;
                if (QString::number(mac_t, 16) == "806") { //remember the arp record
                    /*cout << i << " : " << QString::number(mac_t, 16).toStdString()
                            << ", " << rcd[i].getTime().toStdString() <<endl;*/
                    QPair< quint64, quint32 > key(i, id_pkt);
                    arp_ls << key;
                }
            }

            idx++;
        } //end of the while loop for packets
//        if(rcd[i].isIPrecord())
//            rcd[i].outputData(scope, i, out);

        if (type == 0x01) scope++;
        if (type == 0x02) {
            if(scope >= 0) scope--;
            //rcd[i].outputData(scope, i);
        }

        i++;
    } //end of the while loop for a single record

    progress.setValue(rcd_counter);
    cout << "[Kernel] Round 2, total: " << i << ", sniffer2kernel size: " << sniffer2kernel.size() << endl;    

    u_int bingo = 0;
    if (wired) {
        for (unsigned int k = 0; k < pkt_counter; k++)
        {
            u_char *pkt_ptr = packet[k];
            struct ether_header *eptr;
            eptr = (struct ether_header *) pkt_ptr;

            if (ntohs(eptr->ether_type) == ETHERTYPE_IP)
            {
                struct my_ip *ip_hdr = (struct my_ip *)(pkt_ptr + sizeof(struct ether_header));
                u_int id_snifflog = ntohs(ip_hdr->ip_id);
                Key sniffer_key( id_snifflog, ip_hdr->ip_p,
                                 QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)));

                QList< QPair<quint64, quint32> > values = sniffer2kernel.values(sniffer_key);
                if (!values.isEmpty()) {
                    match_idx[k] = true;
                    bingo++;
                }
            }
        }
    } else {
        for (unsigned int k = 0; k < pkt_counter; k++)
        {
            u_char *pkt_ptr = packet[k];
            struct ieee80211_mac_header *eptr = (struct ieee80211_mac_header *)(pkt_ptr + radio_header_len);
            struct frame_control *control = (struct frame_control *) eptr->fc;

            if (control->protocol == 0 && control->type == 2)
            {
                struct llc_header * paket_llc;
                switch (control->subtype) {
                case 0:
                    paket_llc = (struct llc_header *)
                                (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE);
                    if (ntohs(paket_llc->ether_type) == ETHERTYPE_IP)
                    {
                        // org = 0 is a right encapsulated IP packet
                        if (paket_llc->org[0] != 0 || paket_llc->org[1] != 0 || paket_llc->org[2] != 0) break;

                        struct my_ip *ip_hdr = (struct my_ip *)
                                               (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE + LLC_HEADER_SIZE);
                        u_int id_snifflog = ntohs(ip_hdr->ip_id);
                        Key sniffer_key( id_snifflog, ip_hdr->ip_p,
                                         QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)));
                        QList< QPair< quint64, quint32 > > values = sniffer2kernel.values(sniffer_key);
                        if (!values.isEmpty()) {
                            match_idx[k] = true;
                            bingo++;
                        }
                    }
                    break;

                case 8:
                    // a QoS data + CF-Ack or a QoS (IP) packet!!!!!!!!!!!!!!!!
                    paket_llc = (struct llc_header *)
                                (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE);
                    if (ntohs(paket_llc->ether_type) == ETHERTYPE_IP)
                    {
                        struct my_ip *ip_hdr = (struct my_ip *)
                                               (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE + LLC_HEADER_SIZE);
                        u_int id_snifflog = ntohs(ip_hdr->ip_id);
                        Key sniffer_key( id_snifflog, ip_hdr->ip_p,
                                         QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)));
                        QList< QPair< quint64, quint32 > > values = sniffer2kernel.values(sniffer_key);
                        if (!values.isEmpty()) {
                            match_idx[k] = true;
                            bingo++;
                        }
                    }
                    break;

                default:
                    break;
                }
            }
        }
    }

    cout << "[Kernel] Total pkts: " << pkt_counter << ", match pkts: " << bingo << endl;
    //for(unsigned int k = 0; k < pkt_counter; k++) if (match_idx[k] == true) cout << k + 1 << endl;
    //for (int i = 0; i < arp_ls.size(); i++) cout << arp_ls.at(i) << endl;

    return;
}

void LogMatcher::add_Kernel_data()
{
    int tmp = (int)rcd_counter;
    if (tmp < 0){
        qDebug("pkt_counter to int failed\n");
        return;
    }

    cout << "add kernel: transform rcd_counter: " << tmp << endl;
    for(int idx = (int)rcd_counter - 1; idx >= 0; --idx){
        if (rcd[idx].isIPrecord())
        {
            kernel_model->insertRow(0);
            kernel_model->setData(kernel_model->index(0, 0), idx + 1);
            kernel_model->setData(kernel_model->index(0, 1), rcd[idx].getFunction());
            kernel_model->setData(kernel_model->index(0, 2), rcd[idx].getCaller());
        }
    }
}

void LogMatcher::add_pkt2kernel_data()
{
    if(sniffer_model->rowCount(QModelIndex()) != 0)
        removeSnifferEntry();

    QProgressDialog progress("Loading packet data...", "Cancel", 0, pkt_counter, parent);
    progress.setWindowModality(Qt::WindowModal);
    progress.show();

    if (wired) {
        for (unsigned int k = 0; k < pkt_counter; k++)
        {
            progress.setValue(k);
            if (match_idx[k] == true) {
                add_sniffer_single_wired_data(k);
            }
        }
    } else {
        for (unsigned int k = 0; k < pkt_counter; k++)
        {
            progress.setValue(k);
            if (match_idx[k] == true) {
                add_sniffer_single_wireless_data(k);
            }
        }
    }

    progress.setValue(pkt_counter);
}

void LogMatcher::Load_Event_Data(const QString &file, QWidget * parent)
{
    FILE * fp = fopen(file.toStdString().c_str(), "r");
    if (fp == NULL) {
        QMessageBox::warning(parent, tr("Analyzer"),
                             tr("Load Event Log failed\n"), QMessageBox::Close);
        return;
    }

    struct tm ts;
    struct timeval ts_val;
    char tmp[255];

    int r;
    r = fscanf(fp, "%d:%02d:%02d.%ld %*s %[^\n]",
                    &ts.tm_hour, &ts.tm_min, &ts.tm_sec, &ts_val.tv_usec, tmp);
    evt_counter++;
    while (r == 5) {
        r = fscanf(fp, "%d:%02d:%02d.%ld %*s %[^\n]",
                        &ts.tm_hour, &ts.tm_min, &ts.tm_sec, &ts_val.tv_usec, tmp);
        if (r == 5) evt_counter++;
    }

    fclose(fp);
    fp = fopen(file.toStdString().c_str(), "r");
    if (fp == NULL) {
        QMessageBox::warning(parent, tr("Analyzer"),
                             tr("Load Event Log failed (2)\n"), QMessageBox::Close);
        return;
    }

    ev_ts = new struct tm[evt_counter];
    ev_ts_val = new struct timeval[evt_counter];
    event = new QString[evt_counter];

    for (unsigned int i = 0; i < evt_counter; i++) {
        r = fscanf(fp, "%d:%02d:%02d.%ld %*s %[^\n]",
                   &ev_ts[i].tm_hour, &ev_ts[i].tm_min, &ev_ts[i].tm_sec, &ev_ts_val[i].tv_usec, tmp);
        event[i] = (QString)tmp;

        /*printf("%d:%02d:%02d.%06ld ",
               ev_ts[i].tm_hour, ev_ts[i].tm_min, ev_ts[i].tm_sec, ev_ts_val[i].tv_usec);
        cout << event[i].toStdString() << endl;
        fflush(stdout);*/
    }

    qDebug("[Event] event log: %d records", evt_counter);
    fflush(stdout);
}

void LogMatcher::add_event_data()
{
    int tmp = (int)evt_counter;
    if (tmp < 0) {
        printf("pkt_counter to int failed\n");
        return;
    }

    int pos;
    int order[evt_counter];
    for (int i = 0; i < (int)evt_counter; i++)
    {
        pos = 0;
        // i's time
        qreal time_i = (qreal)ev_ts[i].tm_min * 60 + (qreal)ev_ts[i].tm_sec + (qreal)ev_ts_val[i].tv_usec / 1000000;
        //printf("time: %10f\n", time_i);
        for (int j = 0; j < (int)evt_counter; j++) {
            if (i != j) {
                // ignore itself
                // if i's time > j's time
                qreal time_j = (qreal)ev_ts[j].tm_min * 60 + (qreal)ev_ts[j].tm_sec + (qreal)ev_ts_val[j].tv_usec / 1000000;
                if (time_i - time_j > 0) pos++;
            }
        }
        order[pos] = i;
    }

    char time[30];
    for (int i = (int)evt_counter - 1; i >= 0; --i)
    {
        sprintf(time, "%02d:%02d.%06ld", ev_ts[i].tm_min, ev_ts[i].tm_sec, ev_ts_val[i].tv_usec);
                //ev_ts[order[i]].tm_hour, ev_ts[order[i]].tm_min, ev_ts[order[i]].tm_sec, ev_ts_val[order[i]].tv_usec);


        if (event[i].contains("DHCP")) {
            dhcp_model->insertRow(0);
            dhcp_model->setData(dhcp_model->index(0, 0), time);
            dhcp_model->setData(dhcp_model->index(0, 1), event[i]);
        } else {
            event_model->insertRow(0);
            event_model->setData(event_model->index(0, 0), time);
            event_model->setData(event_model->index(0, 1), event[i]);
        }
    }
}

void LogMatcher::add_sniffer_single_wired_data(int idx)
{
    sniffer_model->insertRow(0);
    sniffer_model->setData(sniffer_model->index(0, 0), idx + 1);

    //getting timestamp
    struct tm *ts;
    ts = localtime(&pkt_ts[idx].tv_sec);
    char time[30];
    sprintf(time, "%02d:%02d:%06ld", ts->tm_min, ts->tm_sec, pkt_ts[idx].tv_usec);
    sniffer_model->setData(sniffer_model->index(0, 1), time);

    u_char *pkt_ptr = packet[idx];

    struct ether_header *eptr;
    eptr = (struct ether_header *) pkt_ptr;

    if (ntohs(eptr->ether_type) != ETHERTYPE_IP) {

        sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa((const struct ether_addr *)&eptr->ether_shost)));
        sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa((const struct ether_addr *)&eptr->ether_dhost)));
        ins_sniffer_data(ntohs(eptr->ether_type));

    } else {

        struct my_ip *ip_hdr = (struct my_ip *)(pkt_ptr + sizeof(struct ether_header));
        sniffer_model->setData(sniffer_model->index(0, 2), QString(inet_ntoa(ip_hdr->ip_src)));
        sniffer_model->setData(sniffer_model->index(0, 3), QString(inet_ntoa(ip_hdr->ip_dst)));
        ins_sniffer_data(ip_hdr->ip_p);

    }
}

void LogMatcher::add_sniffer_single_wireless_data(int idx)
{
    sniffer_model->insertRow(0);
    sniffer_model->setData(sniffer_model->index(0, 0), idx + 1);

    //getting timestamp
    struct tm * ts;
    ts = localtime(&pkt_ts[idx].tv_sec);
    char time[30];
    sprintf(time, "%02d:%02d:%06ld", ts->tm_min, ts->tm_sec, pkt_ts[idx].tv_usec);
    sniffer_model->setData(sniffer_model->index(0, 1), time);

    u_char * pkt_ptr = packet[idx];    

    struct ieee80211_mac_header * eptr = (struct ieee80211_mac_header *)(pkt_ptr + radio_header_len);
    struct frame_control * control = (struct frame_control *) eptr->fc;    

    if (control->protocol == 0 && control->type == 0) {

        if (control->subtype != 13) {
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            if (strcmp((ether_ntoa ((struct ether_addr *)eptr->add1)), "ff:ff:ff:ff:ff:ff") == 0) {
                sniffer_model->setData(sniffer_model->index(0, 3), "Broadcast");
            } else {
                sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            }
        }

        switch (control->subtype) {
        case 0:
            // an Association Request
            ins_sniffer_data(IEEE_80211);
            break;

        case 1:
            // an Association Response
            if (assoResp_idx == -1) {
                if (strcmp((ether_ntoa ((struct ether_addr *)eptr->add1)), "0:2:8a:ba:ad:75") == 0)
                    assoResp_idx = idx;
            }

            ins_sniffer_data(IEEE_80211);
            break;

        case 2:
            // a Reassociation Request                        
            // the very first one
            if (strcmp((ether_ntoa ((struct ether_addr *)eptr->add2)), "0:2:8a:ba:ad:75") == 0)
                reAssoReq_idx = idx;

            ins_sniffer_data(IEEE_80211);
            break;

        case 4:
            // a Probe Request                        
            ins_sniffer_data(IEEE_80211);
            break;

        case 5:
            // a Probe Response
            if (probeResp_idx == -1 && strcmp((ether_ntoa ((struct ether_addr *)eptr->add1)), "0:2:8a:ba:ad:75") == 0) {

                if (authResp_idx != -1) {
                    u_char * pkt_ptr = packet[authResp_idx];
                    struct ieee80211_mac_header * auth_eptr = (struct ieee80211_mac_header *)(pkt_ptr + radio_header_len);

                    char * tmp = ether_ntoa ((struct ether_addr *)auth_eptr->add2);
                    QString auth_macaddr = QString(tmp);
                    tmp = ether_ntoa ((struct ether_addr *)eptr->add2); // probe resp mac addr

                    //cout << "auth mac: " << auth_macaddr.toStdString() << endl;
                    //printf("%d aprobe resp: %s\n", idx, tmp);

                    if (strcmp(auth_macaddr.toStdString().c_str(), tmp) == 0)
                        probeResp_idx = idx;
                }
            }

            ins_sniffer_data(IEEE_80211);
            break;

        case 6:
            // a Fragmented Frame
            ins_sniffer_data(IEEE_80211);
            break;

        case 8:
            // a Beacon
            ins_sniffer_data(IEEE_80211);
            break;

        case 9:
            // an ATIM
            ins_sniffer_data(IEEE_80211);
            break;

        case 10:
            // a Disassociate
            ins_sniffer_data(IEEE_80211);
            break;

        case 11:
            // an Authentication
            if (authResp_idx == -1) {
                if (strcmp((ether_ntoa ((struct ether_addr *)eptr->add1)), "0:2:8a:ba:ad:75") == 0)
                    authResp_idx = idx;
            }

            ins_sniffer_data(IEEE_80211);
            break;

        case 12:
            // a Deauthentication
            ins_sniffer_data(IEEE_80211);
            break;

        case 13:
            // an Action
            ins_sniffer_data(IEEE_80211);
            break;

        case 15:
            // an Aruba Management
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else if (control->protocol == 0 && control->type == 1) {

        switch (control->subtype) {
        case 0:
            // Unknown
            ins_sniffer_data(IEEE_80211);
            break;

        case 2:
            // Unknown
            ins_sniffer_data(IEEE_80211);
            break;

        case 4:
            // Unknown
            ins_sniffer_data(IEEE_80211);
            break;

        case 7:
            // Control Wrapper
            ins_sniffer_data(IEEE_80211);
            break;

        case 11:
            // Request-to-send ??
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 12:
            // Clear-to-send ??
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 13:
            // an Ack
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 14:
            // CF-End
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 15:
            // CF-End + CF-Ack
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            //check[i] = 1;
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else if (control->protocol == 0 && control->type == 2) {

        struct llc_header * paket_llc;

        switch (control->subtype) {
        case 0:
            // find out the retry packet
            if (control->retry == 1)
            {
                if (seq_num == eptr->sc)
                    count_same_seq++;
                else {
                    seq_num = eptr->sc;
                    count_same_seq = 1;
                }

                if (count_same_seq > 3)
                    retry_idx = idx;
            }

            // a UDP packet or ARP or something else
            paket_llc = (struct llc_header *)
                        (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE);
            if (ntohs(paket_llc->ether_type) == ETHERTYPE_IP) {

                // org = 0 is a right encapsulated IP packet
                if (paket_llc->org[0] != 0 || paket_llc->org[1] != 0 || paket_llc->org[2] != 0) {
                    sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
                    if (strcmp( (ether_ntoa ((struct ether_addr *)eptr->add1)), "ff:ff:ff:ff:ff:ff") == 0) {
                        sniffer_model->setData(sniffer_model->index(0, 3), "Broadcast");
                    } else {
                        sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
                    }
                    ins_sniffer_data(LLC);
                    break;
                }

                u_int IP_len;
                struct my_ip *ip_hdr = (struct my_ip *)
                                       (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE + LLC_HEADER_SIZE);
                sniffer_model->setData(sniffer_model->index(0, 2), QString(inet_ntoa(ip_hdr->ip_src)));
                sniffer_model->setData(sniffer_model->index(0, 3), QString(inet_ntoa(ip_hdr->ip_dst)));

                IP_len = IP_HL(ip_hdr) * 4; // ip_hl is in 4-byte words

                // check if packet is other protocol
                if (ip_hdr->ip_p == IPPROTO_UDP) {
                    struct UDP_hdr * udp_hdr = (struct UDP_hdr *)
                                               (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE + LLC_HEADER_SIZE + IP_len);
                    // the dport of llmnr is 5355
                    if (ntohs(udp_hdr->uh_dport) == 5355)
                        ins_sniffer_data(LLMNR);
                    else if (ntohs(udp_hdr->uh_dport) == 5353)
                        ins_sniffer_data(MDNS);
                    else if (ntohs(udp_hdr->uh_dport) == 5351)
                        ins_sniffer_data(NATPMP);
                    else if (ntohs(udp_hdr->uh_dport) == 1900)
                        ins_sniffer_data(SSDP);
                    else if (ntohs(udp_hdr->uh_sport) == 137&& ntohs(udp_hdr->uh_dport) == 137)
                        ins_sniffer_data(NBNS);
                    else
                        ins_sniffer_data(ip_hdr->ip_p);
                } else
                    ins_sniffer_data(ip_hdr->ip_p);

            } else if (ntohs(paket_llc->ether_type) == ETHERTYPE_IPv6) {

                sniffer_model->setData(sniffer_model->index(0, 2), "IPv6 src");
                sniffer_model->setData(sniffer_model->index(0, 3), "IPv6 dst");
                ins_sniffer_data(ntohs(paket_llc->ether_type));

            } else if (ntohs(paket_llc->ether_type) == ETHERTYPE_ARP) {

                sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
                if (strcmp( (ether_ntoa ((struct ether_addr *)eptr->add1)), "ff:ff:ff:ff:ff:ff") == 0) {
                    sniffer_model->setData(sniffer_model->index(0, 3), "Broadcast");
                } else {
                    sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
                }

                ins_sniffer_data(ntohs(paket_llc->ether_type));

            } else if (ntohs(paket_llc->ether_type) == LLC_STP) {

                sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
                if (strcmp( (ether_ntoa ((struct ether_addr *)eptr->add1)), "ff:ff:ff:ff:ff:ff") == 0) {
                    sniffer_model->setData(sniffer_model->index(0, 3), "Broadcast");
                } else {
                    sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
                }

                ins_sniffer_data(LLC_STP);

            } else {

                sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));

                if (strcmp( (ether_ntoa ((struct ether_addr *)eptr->add1)), "ff:ff:ff:ff:ff:ff") == 0) {
                    sniffer_model->setData(sniffer_model->index(0, 3), "Broadcast");
                } else {
                    sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
                }

                ins_sniffer_data(LLC);

            }
            break;

        case 2:
            // Data + CF-Poll or a IPX (packet 9565)!!!!!!!!
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 4:
            // Null Function
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 5:
            // an Ack (dst is IPv6mcast???)
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 6:
            // a CF-Poll
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 7:
            // a CF-Ack/Poll
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 8:
            // a QoS data + CF-Ack or a QoS (IP) packet!!!!!!!!!!!!!!!!
            paket_llc = (struct llc_header *)
                        (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE);
            if (ntohs(paket_llc->ether_type) == ETHERTYPE_IP) {

                u_int IP_len;
                struct my_ip *ip_hdr = (struct my_ip *)
                                       (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE + LLC_HEADER_SIZE);
                sniffer_model->setData(sniffer_model->index(0, 2), QString(inet_ntoa(ip_hdr->ip_src)));
                sniffer_model->setData(sniffer_model->index(0, 3), QString(inet_ntoa(ip_hdr->ip_dst)));

                IP_len = IP_HL(ip_hdr) * 4; // ip_hl is in 4-byte words

                // check if packet is other protocol
                if (ip_hdr->ip_p == IPPROTO_UDP) {
                    struct UDP_hdr * udp_hdr = (struct UDP_hdr *)
                                               (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE + LLC_HEADER_SIZE + IP_len);
                    // the dport of llmnr is 5355
                    if (ntohs(udp_hdr->uh_dport) == 5355)
                        ins_sniffer_data(LLMNR);
                    else if (ntohs(udp_hdr->uh_dport) == 5353)
                        ins_sniffer_data(MDNS);
                    else if (ntohs(udp_hdr->uh_dport) == 5351)
                        ins_sniffer_data(NATPMP);
                    else if (ntohs(udp_hdr->uh_dport) == 1900)
                        ins_sniffer_data(SSDP);
                    else if (ntohs(udp_hdr->uh_sport) == 137 && ntohs(udp_hdr->uh_dport) == 137)
                        ins_sniffer_data(NBNS);
                    else if (ntohs(udp_hdr->uh_sport) == BOOTPC && ntohs(udp_hdr->uh_dport) == BOOTPS)
                        ins_sniffer_data(DHCP);
                    else if (ntohs(udp_hdr->uh_sport) == BOOTPS && ntohs(udp_hdr->uh_dport) == BOOTPC)
                        ins_sniffer_data(DHCP);
                    else
                        ins_sniffer_data(ip_hdr->ip_p);
                } else
                    ins_sniffer_data(ip_hdr->ip_p);

            } else if (ntohs(paket_llc->ether_type) == ETHERTYPE_ARP) {

                sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
                sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
                ins_sniffer_data(ETHERTYPE_ARP);

            }else {

                sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
                sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
                ins_sniffer_data(IEEE_80211);

            }
            break;

        case 9:
            // a QoS data + CF-Ack
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 12:
            // a QoS Null Functions
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            //check[i] = 1;
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else if (control->protocol == 1 && control->type == 0) {

        switch (control->subtype) {
        case 1:
            // Association Response
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            if (strcmp((ether_ntoa ((struct ether_addr *)eptr->add1)), "ff:ff:ff:ff:ff:ff") == 0) {
                sniffer_model->setData(sniffer_model->index(0, 3), "Broadcast");
            } else {
                sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            }

            if (strcmp((ether_ntoa ((struct ether_addr *)eptr->add1)), "0:2:8a:ba:ad:75") == 0)
                assoResp_idx = idx;

            ins_sniffer_data(IEEE_80211);
            break;

        case 3:
            // Reassociation Response
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            if (strcmp( (ether_ntoa ((struct ether_addr *)eptr->add1)), "ff:ff:ff:ff:ff:ff") == 0) {
                sniffer_model->setData(sniffer_model->index(0, 3), "Broadcast");
            } else {
                sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            }
            ins_sniffer_data(IEEE_80211);
            break;

        case 5:
            // Probe Response
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            //check[i] = 1;
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else if (control->protocol == 1 && control->type == 1) {

        switch (control->subtype) {
        case 7:
            // Control Wrapper
            ins_sniffer_data(IEEE_80211);
            break;

        case 13:
            // Ack
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 14:
            // CF-End
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 15:
            // CF-End + CF-Ack
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            //check[i] = 1;
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else if (control->protocol == 1 && control->type == 2) {

        switch (control->subtype) {
        case 4:
            // Null Function
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 9:
            // need to be confirm what it is
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            //check[i] = 1;
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else if (control->protocol == 2 && control->type == 0) {

        switch (control->subtype) {
        case 2:
            // Reassociation Request
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            //check[i] = 1;
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else if (control->protocol == 2 && control->type == 1) {

        switch (control->subtype) {
        case 0:
            // Unknown
            ins_sniffer_data(IEEE_80211);
            break;

        case 2:
            // Unknown
            ins_sniffer_data(IEEE_80211);
            break;

        case 8:
            // 802.11 Block Ack
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 11:
            // Request-to-send ??
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 12:
            // Clear-to-send ??
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 13:
            // an Ack
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        case 14:
            // an CF-End
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            //check[i] = 1;
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else if (control->protocol == 2 && control->type == 2) {

        switch (control->subtype) {
        case 1:
            // Data + CF-Ack
            ins_sniffer_data(IEEE_80211);
            break;

        case 2:
            // Data + CF-Poll
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            //check[i] = 1;
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else if (control->protocol == 3 && control->type == 0) {

        sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
        if (strcmp( (ether_ntoa ((struct ether_addr *)eptr->add1)), "ff:ff:ff:ff:ff:ff") == 0) {
            sniffer_model->setData(sniffer_model->index(0, 3), "Broadcast");
        } else {
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add1)));
        }

        switch (control->subtype) {
        case 4:
            // Probe Request (Fragmented)
            ins_sniffer_data(IEEE_80211);
            break;

        case 5:
            // Probe Response
            ins_sniffer_data(IEEE_80211);
            break;

        case 11:
            // Authentication (Fragmented)
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            //check[i] = 1;
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else if (control->protocol == 3 && control->type == 2) {

        switch (control->subtype) {
        case 4:
            // Null function
            sniffer_model->setData(sniffer_model->index(0, 2), QString(ether_ntoa ((struct ether_addr *)eptr->add2)));
            sniffer_model->setData(sniffer_model->index(0, 3), QString(ether_ntoa ((struct ether_addr *)eptr->add3)));
            ins_sniffer_data(IEEE_80211);
            break;

        default:
            //check[i] = 1;
            ins_sniffer_data(UNKNOWN);
            break;
        }

    } else {
        // the rest of are some unrecognized IEEE 802.11 frame
        //check[i] = 1;
        ins_sniffer_data(IEEE_80211);
    }   
}

void LogMatcher::ins_sniffer_data(uint16_t protocol)
{
    switch (protocol)
    {
    case ETHERTYPE_ARP:
        sniffer_model->setData(sniffer_model->index(0, 4), "ARP");
        break;
    case ETHERTYPE_REVARP:
        sniffer_model->setData(sniffer_model->index(0, 4), "RARP");
        break;
    case ETHERTYPE_PUP:
        sniffer_model->setData(sniffer_model->index(0, 4), "PUP");
        break;
    case IPPROTO_ICMP:
        sniffer_model->setData(sniffer_model->index(0, 4), "ICMP");
        break;
    case IPPROTO_IGMP:
        sniffer_model->setData(sniffer_model->index(0, 4), "IGMP");
        break;
    case IPPROTO_IP:
        sniffer_model->setData(sniffer_model->index(0, 4), "IP");
        break;
    case IPPROTO_TCP:
        sniffer_model->setData(sniffer_model->index(0, 4), "TCP");
        break;
    case IPPROTO_UDP:
        sniffer_model->setData(sniffer_model->index(0, 4), "UDP");
        break;

    /*
     *  the following is defined by cmyu!!
     */
    case UNKNOWN:
        sniffer_model->setData(sniffer_model->index(0, 4), "Unknown Protocol");
        break;
    case IEEE_80211:
        sniffer_model->setData(sniffer_model->index(0, 4), "IEEE 80211");
        break;
    case LLC:
        sniffer_model->setData(sniffer_model->index(0, 4), "LLC");
        break;
    case LLMNR:
        sniffer_model->setData(sniffer_model->index(0, 4), "LLMNR");
        break;
    case NBNS:
        sniffer_model->setData(sniffer_model->index(0, 4), "NBNS");
        break;
    case SSDP:
        sniffer_model->setData(sniffer_model->index(0, 4), "SSDP");
        break;
    case MDNS:
        sniffer_model->setData(sniffer_model->index(0, 4), "MDNS");
        break;
    case DHCP:
        sniffer_model->setData(sniffer_model->index(0, 4), "DHCP");
        break;
    case NATPMP:
        sniffer_model->setData(sniffer_model->index(0, 4), "NAT-PMP");
        break;
    case LLC_STP:
        sniffer_model->setData(sniffer_model->index(0, 4), "STP");
        break;
    case ETHERTYPE_IPv6:
        sniffer_model->setData(sniffer_model->index(0, 4), "IPv6");
        break;
    case PIM:
        sniffer_model->setData(sniffer_model->index(0, 4), "PIM");
        break;
    case BNA:
        sniffer_model->setData(sniffer_model->index(0, 4), "BNA");
        break;
    case EMCON:
        sniffer_model->setData(sniffer_model->index(0, 4), "EMCON");
        break;
    default:
        sniffer_model->setData(sniffer_model->index(0, 4), "Out of Range");
        break;
    }
}

void LogMatcher::removeSnifferEntry()
{
    int rows = sniffer_model->rowCount(QModelIndex());
    for(int i = 0; i < rows ; i++){
        sniffer_model->removeRow(0, QModelIndex());
    }
}

void LogMatcher::removeKernelEntry()
{
    int rows = kernel_model->rowCount(QModelIndex());
    for(int i = 0; i < rows ; i++){
        kernel_model->removeRow(0, QModelIndex());
    }
}

void LogMatcher::showIndex(const QModelIndex & index)
{
    QModelIndex index0 = proxyModel->index(index.row(), 0);
    int idx = proxyModel->data(index0).toInt() - 1;

    if(kernel_model->rowCount(QModelIndex()) != 0)
        removeKernelEntry();

    if (wired) {
        u_char *pkt_ptr = packet[idx];
        struct ether_header *eptr;
        eptr = (struct ether_header *) pkt_ptr;

        if (ntohs(eptr->ether_type) == ETHERTYPE_IP)
        {
            struct my_ip *ip_hdr = (struct my_ip *)(pkt_ptr + sizeof(struct ether_header));
            u_int id = ntohs(ip_hdr->ip_id);
            Key key1( id, ip_hdr->ip_p, QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)) );

            if (!sniffer2kernel.isEmpty()) {
                QList< QPair<quint64, quint32> > rec_idx = sniffer2kernel.values(key1);
                qDebug() << "packet "<< idx + 1 << " (dstIP, srcIP, iden, protocol)";
                cout << key1 << endl;

                if (rcd_counter != 0) {
                    for (int i = 0; i < rec_idx.size(); i++) {
                        kernel_model->insertRow(0);
                        kernel_model->setData(kernel_model->index(0, 0), rec_idx.at(i).first + 1);
                        kernel_model->setData(kernel_model->index(0, 1), rcd[rec_idx.at(i).first].getTime());
                        kernel_model->setData(kernel_model->index(0, 2), rcd[rec_idx.at(i).first].getFunction());
                        kernel_model->setData(kernel_model->index(0, 3), rcd[rec_idx.at(i).first].getCaller());
                    }
                }
            } else {
                QMessageBox::warning(parent, tr("Analyzer"),
                                     tr("sniffer2kernel hash is still empty"), QMessageBox::Close);
            }
        }
    } else {
        qreal pkt_time = (qreal)pkt_ts[idx].tv_sec + (qreal)pkt_ts[idx].tv_usec / 1000000;
        u_char * pkt_ptr = packet[idx];
        struct ieee80211_mac_header * eptr = (struct ieee80211_mac_header *)(pkt_ptr + radio_header_len);
        struct frame_control * control = (struct frame_control *) eptr->fc;

        if (control->protocol == 0 && control->type == 2)
        {
            struct llc_header * paket_llc;
            switch (control->subtype)
            {
            case 0:
                paket_llc = (struct llc_header *)
                            (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE);

                if (ntohs(paket_llc->ether_type) == ETHERTYPE_IP)
                {
                    // org = 0 is a right encapsulated IP packet
                    if (paket_llc->org[0] != 0 || paket_llc->org[1] != 0 || paket_llc->org[2] != 0) break;

                    struct my_ip * ip_hdr = (struct my_ip *)
                                            (pkt_ptr + radio_header_len + DATA_80211_FRAME_SIZE + LLC_HEADER_SIZE);
                    u_int id_snifflog = ntohs(ip_hdr->ip_id);                    
                    Key key1( id_snifflog, ip_hdr->ip_p, QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)));

                    if (!sniffer2kernel.isEmpty())
                    {
                        QList< QPair<quint64, quint32> > rec_idx = sniffer2kernel.values(key1);
                        cout << "packet " << idx + 1 << " (dstIP, srcIP, iden, protocol)";
                        cout << key1 << endl;
                        if (id_snifflog != 0) {
                            if (rcd_counter != 0) {
                                for (int i = 0; i < rec_idx.size(); i++) {
                                    //rcd[rec_idx.at(i).first].outputData(2, rec_idx.at(i).first);
                                    //cout << rec_idx.at(i).first + 1 << endl;
                                    kernel_model->insertRow(0);
                                    kernel_model->setData(kernel_model->index(0, 0), rec_idx.at(i).first + 1);
                                    kernel_model->setData(kernel_model->index(0, 1), rcd[rec_idx.at(i).first].getTime());
                                    kernel_model->setData(kernel_model->index(0, 2), rcd[rec_idx.at(i).first].getFunction());
                                    kernel_model->setData(kernel_model->index(0, 3), rcd[rec_idx.at(i).first].getCaller());
                                }
                            }
                        } else {
                            quint32 pkt_id;
                            qreal min = 100.0;
                            quint64 min_idx = 0;
                            for (int i = 0; i < rec_idx.size(); i++) {
                                qreal diff = pkt_time - rcd[rec_idx.at(i).first].getTimeF();
                                //cout << i << " " << rec_idx.at(i).first + 1 << " " << fabs(diff) << endl;
                                if (fabs(diff) < min) {
                                    min = fabs(diff);
                                    min_idx = i;
                                }
                            }

                            pkt_id = rec_idx.at(min_idx).second;
                            //cout << "min: " << min_idx << " " << rec_idx.at(min_idx).first + 1 << " " << min << endl;

                            for (int i = 0; i < rec_idx.size(); i++) {
                                qreal diff = pkt_time - rcd[rec_idx.at(i).first].getTimeF();
                                if (rec_idx.at(i).second == pkt_id && fabs(diff) < 0.1) {
                                    kernel_model->insertRow(0);
                                    kernel_model->setData(kernel_model->index(0, 0), rec_idx.at(i).first + 1);
                                    kernel_model->setData(kernel_model->index(0, 1), rcd[rec_idx.at(i).first].getTime());
                                    kernel_model->setData(kernel_model->index(0, 2), rcd[rec_idx.at(i).first].getFunction());
                                    kernel_model->setData(kernel_model->index(0, 3), rcd[rec_idx.at(i).first].getCaller());
                                }
                            }
                        }
                    } else {
                        QMessageBox::warning(parent, tr("Analyzer"),
                                             tr("sniffer2kernel hash is still empty"), QMessageBox::Close);
                    }
                }
                break;

            case 8:
                // a QoS data + CF-Ack or a QoS (IP) packet!!!!!!!!!!!!!!!!
                paket_llc = (struct llc_header *)
                            (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE);

                if (ntohs(paket_llc->ether_type) == ETHERTYPE_ARP)
                {
                    //quint32 pkt_id;
                    qreal min = 100.0;
                    quint64 min_idx = 0;
                    for (int i = 0; i < arp_ls.size(); i++) {
                        qreal diff = pkt_time - rcd[arp_ls.at(i).first].getTimeF();
                        if (fabs(diff) < min) {
                            min = fabs(diff);
                            min_idx = i;
                        }
                    }

                    kernel_model->insertRow(0);
                    kernel_model->setData(kernel_model->index(0, 0), arp_ls.at(min_idx).first + 1);
                    kernel_model->setData(kernel_model->index(0, 1), rcd[arp_ls.at(min_idx).first].getTime());
                    kernel_model->setData(kernel_model->index(0, 2), rcd[arp_ls.at(min_idx).first].getFunction());
                    kernel_model->setData(kernel_model->index(0, 3), rcd[arp_ls.at(min_idx).first].getCaller());
                }

                if (ntohs(paket_llc->ether_type) == ETHERTYPE_IP)
                {
                    struct my_ip *ip_hdr = (struct my_ip *)
                                           (pkt_ptr + radio_header_len + DATA_80211_QoS_FRAME_SIZE + LLC_HEADER_SIZE);
                    u_int id_snifflog = ntohs(ip_hdr->ip_id);
                    Key key2( id_snifflog, ip_hdr->ip_p, QString(inet_ntoa(ip_hdr->ip_src)), QString(inet_ntoa(ip_hdr->ip_dst)));

                    if (!sniffer2kernel.isEmpty()) {
                        QList< QPair<quint64, quint32> > rec_idx = sniffer2kernel.values(key2);
                        cout << "packet" << idx + 1 << "(dstIP, srcIP, iden, protocol)";
                        cout << key2 << endl;
                        if (id_snifflog != 0) {
                            if (rcd_counter != 0) {
                                for (int i = 0; i < rec_idx.size(); i++) {
                                    //rcd[rec_idx.at(i).first].outputData(2, rec_idx.at(i).first);
                                    //cout << rec_idx.at(i).first + 1 << endl;
                                    kernel_model->insertRow(0);
                                    kernel_model->setData(kernel_model->index(0, 0), rec_idx.at(i).first + 1);
                                    kernel_model->setData(kernel_model->index(0, 1), rcd[rec_idx.at(i).first].getTime());
                                    kernel_model->setData(kernel_model->index(0, 2), rcd[rec_idx.at(i).first].getFunction());
                                    kernel_model->setData(kernel_model->index(0, 3), rcd[rec_idx.at(i).first].getCaller());
                                }
                            }
                        } else {
                            quint32 pkt_id;
                            qreal min = 100.0;
                            quint64 min_idx = 0;
                            for (int i = 0; i < rec_idx.size(); i++) {
                                qreal diff = pkt_time - rcd[rec_idx.at(i).first].getTimeF();
                                //cout << i << " " << rec_idx.at(i).first + 1 << " " << fabs(diff) << endl;
                                if (fabs(diff) < min) {
                                    min = fabs(diff);
                                    min_idx = i;
                                }
                            }

                            pkt_id = rec_idx.at(min_idx).second;
                            //cout << "min: " << min_idx << " " << rec_idx.at(min_idx).first + 1 << " " << min << endl;

                            for (int i = 0; i < rec_idx.size(); i++) {
                                if (rec_idx.at(i).second == pkt_id) {
                                    kernel_model->insertRow(0);
                                    kernel_model->setData(kernel_model->index(0, 0), rec_idx.at(i).first + 1);
                                    kernel_model->setData(kernel_model->index(0, 1), rcd[rec_idx.at(i).first].getTime());
                                    kernel_model->setData(kernel_model->index(0, 2), rcd[rec_idx.at(i).first].getFunction());
                                    kernel_model->setData(kernel_model->index(0, 3), rcd[rec_idx.at(i).first].getCaller());
                                }
                            }
                        }
                    } else {
                        QMessageBox::warning(parent, tr("Analyzer"),
                                             tr("sniffer2kernel hash is still empty"), QMessageBox::Close);
                    }
                }
                break;

            default:
                break;
            }
        }
    }
}

void LogMatcher::showKernelIndex(const QModelIndex & index)
{
    QModelIndex index0 = kernel_model->index(index.row(), 0);
    int idx = kernel_model->data(index0).toInt() - 1;
    qDebug() << "kernel record:" << idx;
    fflush(stderr);

    QList< Key > rcd_key;
    if (rcd[idx].isIPrecord()) {
        rcd_key = rcd[idx].getKey();

        if (rcd_key.size() > 1) {
            int count = 0;
            QMenu * contextMenu = new QMenu(parent);
            Q_CHECK_PTR (contextMenu);

            //QList< QString > str_ls;
            for (int i = 0; i < rcd_key.size(); i++) {
                cout << rcd_key.at(i) << endl;
                QList< unsigned int > rec_idx = kernel2sniffer.values(rcd_key.at(i));

                if (rec_idx.isEmpty()) {
                    cout << "This key is not mapping to sniffer" << endl;
                    fflush(stdout);
                }

                for (int i = 0; i < rec_idx.size(); i++) {
                    count++;
                    contextMenu->addAction(QString::number(rec_idx.at(i)), this , SLOT(null()));
                    qDebug() << "mapping sniffer:" << rec_idx.at(i);
                    fflush(stderr);
                }
            }

            if (count == 0)
                contextMenu->addAction("This Record is not mapping to sniffer", this , SLOT(null()));

            contextMenu->popup(QCursor::pos());
            contextMenu->exec();
            delete contextMenu;
            contextMenu = 0;            
        } else {
            cout << rcd_key.at(0) << endl;
            QList< unsigned int > rec_idx = kernel2sniffer.values(rcd_key.at(0));

            if (rec_idx.isEmpty()) {
                cout << "This key is not mapping to sniffer" << endl;
                fflush(stdout);
                return;
            }

            for (int i = 0; i < rec_idx.size(); i++) {
                qDebug() << "mapping sniffer:" << rec_idx.at(i) + 1;
                fflush(stderr);
            }

            emit changeSnifferBox(snifferSortFilter::NO);
            emit changeSnifferText(QString::number(rec_idx.at(0) + 1));                        
        }
    } else {
        cout << "Not an IP record." << endl;
        fflush(stdout);
    }
}

void LogMatcher::showEventTime(const QModelIndex & index)
{
    QModelIndex index0 = event_model->index(index.row(), 0);
    QString idx = event_model->data(index0).toString();
    QStringList list = idx.split(".");
    QTime time = QTime::fromString(list.at(0), "mm:ss");
    QString msec = list.at(1);
    qreal event_time = (qreal)time.minute() * 60 + (qreal)time.second() + (qreal)msec.toLong() / 1000000;
    qreal sniffer_time;

    //event_time -= DEVIATION;

    /*printf("%s.%06ld\n", time.toString("mm:ss").toStdString().c_str(), msec.toLong());
    printf("%02d:%02d:%02d.%06ld\n", time.hour(), time.minute(), time.second(), msec.toLong());
    printf("qreal: %.6f\n", event_time);
    fflush(stdout);*/

    if (pkt_counter != 0) {
        if(sniffer_model->rowCount(QModelIndex()) != 0)
            removeSnifferEntry();

        // if the time of a sniffer log is between range of event time +- X time, show it
        if (wired) {
            for(int i = (int)pkt_counter - 1; i >= 0; --i) {
                struct tm *ts;
                ts = localtime(&pkt_ts[i].tv_sec);
                sniffer_time = (qreal)ts->tm_min * 60 + (qreal)ts->tm_sec + (qreal)pkt_ts[i].tv_usec / 1000000;

                if (sniffer_time < (event_time + EVENTRANGE) && sniffer_time > (event_time - EVENTRANGE))
                    add_sniffer_single_wired_data(i);
            }
        } else {
            for(int i = (int)pkt_counter - 1; i >= 0; --i) {
                struct tm *ts;
                ts = localtime(&pkt_ts[i].tv_sec);
                sniffer_time = (qreal)ts->tm_min * 60 + (qreal)ts->tm_sec + (qreal)pkt_ts[i].tv_usec / 1000000;

                if (sniffer_time < (event_time + EVENTRANGE) && sniffer_time > (event_time - EVENTRANGE))
                    add_sniffer_single_wireless_data(i);
            }
        }
    } else qDebug() << "[Event] sniffer data is empty";
}

void LogMatcher::showDhcpTime(const QModelIndex & index)
{
    QModelIndex index0 = dhcp_model->index(index.row(), 0);
    QString idx = dhcp_model->data(index0).toString();
    QStringList list = idx.split(".");
    QTime time = QTime::fromString(list.at(0), "mm:ss");
    QString msec = list.at(1);
    qreal event_time = (qreal)time.minute() * 60 + (qreal)time.second() + (qreal)msec.toLong() / 1000000;
    qreal sniffer_time;

    //event_time -= DEVIATION;

    /*printf("%s.%06ld\n", time.toString("mm:ss").toStdString().c_str(), msec.toLong());
    printf("%02d:%02d:%02d.%06ld\n", time.hour(), time.minute(), time.second(), msec.toLong());
    printf("qreal: %.6f\n", event_time);
    fflush(stdout);*/

    if (pkt_counter != 0) {
        if(sniffer_model->rowCount(QModelIndex()) != 0)
            removeSnifferEntry();

        // if the time of a sniffer log is between range of event time +- X time, show it
        if (wired) {
            for(int i = (int)pkt_counter - 1; i >= 0; --i) {
                struct tm *ts;
                ts = localtime(&pkt_ts[i].tv_sec);
                sniffer_time = (qreal)ts->tm_min * 60 + (qreal)ts->tm_sec + (qreal)pkt_ts[i].tv_usec / 1000000;

                if (sniffer_time < (event_time + EVENTRANGE) && sniffer_time > (event_time - EVENTRANGE))
                    add_sniffer_single_wired_data(i);
            }
        } else {
            for(int i = (int)pkt_counter - 1; i >= 0; --i) {
                struct tm *ts;
                ts = localtime(&pkt_ts[i].tv_sec);
                sniffer_time = (qreal)ts->tm_min * 60 + (qreal)ts->tm_sec + (qreal)pkt_ts[i].tv_usec / 1000000;

                if (sniffer_time < (event_time + EVENTRANGE) && sniffer_time > (event_time - EVENTRANGE))
                    add_sniffer_single_wireless_data(i);
            }
        }
    } else qDebug() << "[Event] sniffer data is empty";
}

void LogMatcher::textFilterChanged(const QString &text)
{
    QRegExp regExp(text);
    proxyModel->setFilterRegExp(regExp);
}

void LogMatcher::ComboBoxIndexChanged(int index)
{
    for(int i = 0; i < 4; i++){
        proxyModel->flag[i] = false;
    }

    switch(index)
    {
    case snifferSortFilter::SRCIP:
        proxyModel->flag[snifferSortFilter::SRCIP] = true;
        break;
    case snifferSortFilter::DSTIP:
        proxyModel->flag[snifferSortFilter::DSTIP] = true;
        break;
    case snifferSortFilter::PROTO:
        proxyModel->flag[snifferSortFilter::PROTO] = true;
        break;
    case snifferSortFilter::NO:
        proxyModel->flag[snifferSortFilter::NO] = true;
        break;
    }

    proxyModel->resetFilter();
}

void LogMatcher::kernelFilterGo()
{
    //qDebug() << "kernelFilterIndex:" << kernelFilterIndex;
    //qDebug() << "kernel function name:" << kernelFilterText;

    int tmp = (int)rcd_counter;
    if (tmp < 0){
        qDebug("pkt_counter to int failed\n");
        return;
    }

    if(kernel_model->rowCount(QModelIndex()) != 0)
        removeKernelEntry();

    QProgressDialog progress("Filtering kernel data...", "Cancel", 0, rcd_counter, parent);
    progress.setWindowModality(Qt::WindowModal);
    progress.show();
    int i = 0, j = 0;
    int deltCnt = rcd_counter / 20; //devide the rcd_counter to 20 parts
    int count = 0;

    switch (kernelFilterIndex) {
    case 0:
        // find Callee
        for(int idx = (int)rcd_counter - 1; idx >= 0; --idx)
        {
            i++;
            j++;
            if (j == deltCnt) {
                //once reach every 5% of the kernel log data
                //we show the progression to avoiding slowdown problem
                progress.setValue(i);
                j = 0;
            }

            if (rcd[idx].getFunction().contains(kernelFilterText, Qt::CaseInsensitive))
            {
                kernel_model->insertRow(0);
                kernel_model->setData(kernel_model->index(0, 0), idx + 1);
                kernel_model->setData(kernel_model->index(0, 1), rcd[idx].getTime());
                kernel_model->setData(kernel_model->index(0, 2), rcd[idx].getFunction());
                kernel_model->setData(kernel_model->index(0, 3), rcd[idx].getCaller());
                count++;
            }
        }
        break;
    case 1:
        // find Caller
        for(int idx = (int)rcd_counter - 1; idx >= 0; --idx)
        {
            i++;
            j++;
            if (j == deltCnt) {
                progress.setValue(i);
                j = 0;
            }

            if (rcd[idx].getCaller().contains(kernelFilterText, Qt::CaseInsensitive))
            {
                kernel_model->insertRow(0);
                kernel_model->setData(kernel_model->index(0, 0), idx + 1);
                kernel_model->setData(kernel_model->index(0, 1), rcd[idx].getTime());
                kernel_model->setData(kernel_model->index(0, 2), rcd[idx].getFunction());
                kernel_model->setData(kernel_model->index(0, 3), rcd[idx].getCaller());
                count++;
            }
        }
        break;
    }

    if (count == 0) {
        QMessageBox::warning(parent, tr("Analyzer"),
                             tr("No record is found.\n"), QMessageBox::Close);
    }
}
