#include "pixitem.h"

pixItem::pixItem(const QPixmap &pix)
    : QGraphicsObject(), icon(pix)
{

}

void pixItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    if (delay == NULL)
        painter->drawPixmap(QPointF(), icon);
    else {
        painter->setPen(Qt::red);
        painter->drawText(QPointF(), delay);
    }
}

QRectF pixItem::boundingRect() const
{
    return QRectF( QPointF(0, 0), icon.size());
}

void pixItem::getDelayTime(qreal delaytime)
{
    delay = QString::number(delaytime);
    //qDebug() << "[pixItem] Delay time" << delay;
}

textItem::textItem(const QPixmap &pix)
    : QGraphicsObject(), icon(pix)
{

}

void textItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    if (text == NULL)
        painter->drawPixmap(QPointF(), icon);
    else {
        painter->setPen(Qt::black);
        painter->drawText(QPointF(), text);
    }
}

QRectF textItem::boundingRect() const
{
    return QRectF( QPointF(0, 0), icon.size());
}
