#ifndef LOGMATCHER_H
#define LOGMATCHER_H

#include <QtCore>
#include <QMultiHash>
#include <QProgressDialog>
#include <time.h>
#include <sys/time.h>
#include <pcap.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <net/ethernet.h>
#include <netinet/ether.h>
#include <netinet/if_ether.h>
#include <stdlib.h>
#include "kernelLog.h"
#include "hashkey.h"
#include "snifferSortFilter.h"
#include "wlanreader.h"

#define DEVIATION 136.480322
#define EVENTRANGE 0.1

class LogMatcher: public QObject
{
    Q_OBJECT

public:
    LogMatcher(QWidget *);

    // indexes of handover procedure
    int retry_idx;
    int reAssoReq_idx;
    int probeResp_idx;
    int authResp_idx;
    int assoResp_idx;

    // data members for showing the matching data
    snifferSortFilter * proxyModel;
    QTreeView * sourceView;
    QTreeView * kernelView;
    QTreeView * eventView;
    QTreeView * dhcpView;
    QAbstractItemModel * sniffer_model;
    QAbstractItemModel * kernel_model;    
    QAbstractItemModel * event_model;
    QAbstractItemModel * dhcp_model;

    // funcitons used for processing the data
    void setSnifferModel() { proxyModel->setSourceModel(sniffer_model); }
    void Load_Sniffer_Data(const QString &, QWidget *);
    void add_sniffer_data();
    void Load_Kernel_Data(const QString &, QWidget *);
    void add_Kernel_data();
    void add_pkt2kernel_data();
    void Load_Event_Data(const QString &, QWidget *);
    void add_event_data();

    // functions used for get private data
    bool isWired() { return wired; }

    u_char * getPkt(int idx) { return packet[idx]; }
    unsigned int getSnifferLogSize() { return pkt_counter; }
    struct timeval getSnifferTime(int idx) { return pkt_ts[idx]; }

    KernelLog * getKernelLog(quint64 idx) { return &rcd[idx]; }
    quint64 getKernelLogSize() { return rcd_counter; }

    QString getEvent(int idx) { return event[idx]; }
    unsigned int getEventSize() { return evt_counter; }
    qreal getEventTime(int idx) { return (qreal)ev_ts[idx].tm_min * 60 +
                                  (qreal)ev_ts[idx].tm_sec + (qreal)ev_ts_val[idx].tv_usec / 1000000; }

    QMultiHash< Key, QPair< quint64, quint32 > > * getSniffer2Kernel() { return &sniffer2kernel; }
    QPair< struct timeval, struct timeval > getTimeRange() { return qMakePair(pkt_ts[0], pkt_ts[pkt_counter - 1]); }
    QList< QPair<quint64, quint32> > * getARPls() { return &arp_ls; }
    struct timeval * getPktTime(int idx) { return &pkt_ts[idx]; }


public slots:
    void showIndex(const QModelIndex & index);
    void showKernelIndex(const QModelIndex & index);
    void showEventTime(const QModelIndex & index);
    void showDhcpTime(const QModelIndex & index);
    void textFilterChanged(const QString &);
    void ComboBoxIndexChanged(int);
    void kernelComboBoxIndexChanged(int index) { kernelFilterIndex = index; }
    void kernelTextFilterChanged(const QString &text) { kernelFilterText = QString(text); }
    void kernelFilterGo();
    void null() {  }

signals:
    void changeSnifferBox(int);
    void changeSnifferText(const QString &);

private:    
    QWidget * parent;    

    ////sniffer log/////
    bool wired;
    int radio_header_len;    
    u_char ** packet;
    struct timeval * pkt_ts;
    unsigned int * pkt_len;
    unsigned int pkt_counter;
    ////////////////////

    /////kernel log/////
    int kernelFilterIndex;
    QString kernelFilterText;
    KernelLog * rcd;
    quint64 rcd_counter;
    ////////////////////    

    /////Event log/////
    struct tm * ev_ts;
    struct timeval * ev_ts_val;
    QString * event;
    unsigned int evt_counter;
    ////////////////////

    QHash< Key, unsigned int > kernel2sniffer;
    QMultiHash< Key, QPair< quint64, quint32 > > sniffer2kernel;
    QList< QPair<quint64, quint32> > arp_ls;
    bool * match_idx;
    QString mac_addr;

    QAbstractItemModel * createSnifferModel();
    QAbstractItemModel * createKernelModel();
    QAbstractItemModel * createEventModel();
    QAbstractItemModel * createDhcpModel();

    void add_sniffer_single_wired_data(int);
    void add_sniffer_single_wireless_data(int);
    void ins_sniffer_data(uint16_t);
    void removeSnifferEntry();
    void removeKernelEntry();
};

#endif // LOGMATCHER_H
