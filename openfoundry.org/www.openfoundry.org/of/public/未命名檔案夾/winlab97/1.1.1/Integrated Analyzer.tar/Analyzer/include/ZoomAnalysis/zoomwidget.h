#ifndef ZOOMWIDGET_H
#define ZOOMWIDGET_H

#include <QtGui>
#include "LogMatcher.h"
#include "TimeAnalysis.h"
#include "pixitem.h"

QT_FORWARD_DECLARE_CLASS(QToolButton)

class ZoomWidget : public QGraphicsView
{
    Q_OBJECT

public:
    ZoomWidget(QWidget *parent = 0);
//    void itemMoved();
    void setLogMatcher(LogMatcher * logmatcher) { this->logmatcher = logmatcher; }
    void setTimeAnalyzer(TimeAnalysis * timeAnalyzer) { this->timeAnalyzer = timeAnalyzer; }
    void updateTime();

protected:
    void resizeEvent(QResizeEvent * event);
//    void keyPressEvent(QKeyEvent *event);
//    void timerEvent(QTimerEvent *event);
//    void wheelEvent(QWheelEvent *event);
//    void drawBackground(QPainter *painter, const QRectF &rect);

//    void scaleView(qreal scaleFactor);

private slots:
    void myUpdate() { fitInView(scene()->sceneRect(), Qt::KeepAspectRatio); }

private:
    LogMatcher * logmatcher;
    TimeAnalysis * timeAnalyzer;

    pixItem * handoffdelay;
    pixItem * l2hdelay;
    pixItem * l3hdelay;
    pixItem * l2hddelay;
    pixItem * probdelay;
    pixItem * authdelay;
    pixItem * assodelay;
    pixItem * l3hddelay;
    pixItem * dhcpdelay;
    pixItem * ipchdelay;
};

#endif // ZOOMWIDGET_H
