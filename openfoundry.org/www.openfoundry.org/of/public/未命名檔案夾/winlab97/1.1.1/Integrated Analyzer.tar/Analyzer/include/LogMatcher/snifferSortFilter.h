#ifndef SNIFFERSORTFILTER_H
#define SNIFFERSORTFILTER_H

#include <QSortFilterProxyModel>

class snifferSortFilter : public QSortFilterProxyModel
{
    Q_OBJECT

public:
    bool flag[4];
    enum {SRCIP, DSTIP, PROTO, NO};
    snifferSortFilter(QObject *parent = 0);
    void resetFilter(){ invalidateFilter(); }

protected:
    bool filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const;
    bool lessThan(const QModelIndex &left, const QModelIndex &right) const;
};

#endif // SNIFFERSORTFILTER_H
